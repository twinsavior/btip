#!/usr/bin/env python3
"""Live eyes for an iPad (or iPhone): an AirPlay receiver (UxPlay) on the Mac, frames into our own process.

  python3 eyes.py serve            # run the receiver; the device mirrors to "iPad Eyes"
  python3 eyes.py see [--out f]    # latest frame: path, size, age, fps
  python3 eyes.py find TEXT        # OCR the latest frame; matches as screen fractions
  python3 eyes.py tap DEV TEXT     # find TEXT, bt.py tap it, confirm from the frames that follow

`serve` writes ~/.cache/ipad-eyes/latest.jpg (atomic rename) and latest.json on every frame.
Frame age = now - receive time of the newest frame. AirPlay sends frames only when the screen
changes, so on a still screen the newest frame is current but its age grows; `stream` in
latest.json says whether the device is still connected.
"""
import collections, json, os, struct, subprocess, sys, time, threading, re, difflib

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.expanduser("~/.cache/ipad-eyes")
UXPLAY = os.environ.get("EYES_UXPLAY") or os.path.join(CACHE, "src/UxPlay/build/uxplay")
# The one install's receiver: a 7.7 MB folder (UxPlay + the 6 GStreamer plugins it needs + their libraries), fetched
# the first time a screen device is set, never before. bundle_eyes.py in btip/install builds it.
EYES_DIR = os.environ.get("BTIP_EYES_DIR") or (os.path.join(os.environ["BTIP_DIR"], "eyes") if os.environ.get("BTIP_DIR") else None)
EYES_SRC = os.environ.get("BTIP_EYES_SRC") or "https://twinsavior.github.io/btip/btip-eyes-1-arm64.tar.gz"
EYES_SHA = os.environ.get("BTIP_EYES_SHA", "bcb226d9ee0a4a5b0443b2cc3e5504125d7d6d25d2c150bdc3c07d621fd16f29")        # build.sh writes the published tarball's checksum here


def receiver():
    """(uxplay path, env, extra args). An explicit EYES_UXPLAY wins; then the installed folder (fetched now if missing);
    then a UxPlay built in the repo setup."""
    if os.environ.get("EYES_UXPLAY") or not EYES_DIR: return UXPLAY, {}, []
    exe = os.path.join(EYES_DIR, "bin", "uxplay")
    if not os.path.exists(exe): fetch_receiver()
    lib = os.path.join(EYES_DIR, "lib", "gstreamer-1.0")
    env = {"GST_PLUGIN_SYSTEM_PATH": lib, "GST_PLUGIN_PATH": "", "GST_PLUGIN_SCANNER": os.path.join(EYES_DIR, "libexec", "gst-plugin-scanner"),
           "GST_REGISTRY": os.path.join(EYES_DIR, "registry.bin"), "BTIP_EYES_VIDEO_ONLY": "1"}
    return exe, env, ["-a", "-vd", "vtdec"]        # video only: the device keeps its own sound; Apple's hardware H.264 decoder


def fetch_receiver():
    import hashlib, shutil, tarfile, tempfile, urllib.request
    t0 = time.time(); parent = os.path.dirname(EYES_DIR.rstrip("/")); os.makedirs(parent, exist_ok=True)
    tmp = tempfile.mkdtemp(dir=parent, prefix=".eyes-")
    try:
        f = os.path.join(tmp, "eyes.tgz")
        if EYES_SRC.startswith("/"): shutil.copy(EYES_SRC, f)
        else:
            with urllib.request.urlopen(EYES_SRC, timeout=60) as r, open(f, "wb") as o: shutil.copyfileobj(r, o)
        if EYES_SHA and hashlib.sha256(open(f, "rb").read()).hexdigest() != EYES_SHA: raise SystemExit("ERR the screen receiver download did not match its checksum. Next: try again; if it repeats, tell the btip maintainers")
        with tarfile.open(f) as t: t.extractall(tmp, filter="data")
        if os.path.exists(EYES_DIR): shutil.rmtree(EYES_DIR)
        os.replace(os.path.join(tmp, "eyes"), EYES_DIR)
        print("%s FETCHED  screen receiver (%d KB) in %.1f s into %s" % (time.strftime("%H:%M:%S"), os.path.getsize(f) // 1024, time.time() - t0, EYES_DIR), flush=True)
    finally: shutil.rmtree(tmp, ignore_errors=True)
OCR = os.path.join(CACHE, "bin_ocr")
LATEST, META = os.path.join(CACHE, "latest.jpg"), os.path.join(CACHE, "latest.json")
BT = os.path.join(os.path.dirname(HERE), "classic", "bt.py")
NAME, PORT = "iPad Eyes", 47000


def jpeg_size(b):
    i = 2
    while i < len(b) - 9:
        if b[i] != 0xFF: return None
        m, ln = b[i + 1], int.from_bytes(b[i + 2:i + 4], "big")
        if m in (0xC0, 0xC1, 0xC2):
            return int.from_bytes(b[i + 7:i + 9], "big"), int.from_bytes(b[i + 5:i + 7], "big")
        i += 2 + ln
    return None


PW, PH = 80, 116  # probe size; multiples of 4 so GStreamer adds no row padding (82 wide came back sheared)
PROBE_LOG, PROBE_LAST = os.path.join(CACHE, "probe.log"), os.path.join(CACHE, "probe.bin")


def probe_reader(fd):
    """Every frame as PW x PH gray bytes. probe.bin = frame + 2 doubles: Mac receive time, and the iPad's own
    timestamp for that frame (from UxPlay's arrive.log, the newest packet that arrived before this frame;
    decode takes ~3 ms and frames come 33 ms apart). The iPad timestamp has no Wi-Fi jitter."""
    n, size = 0, PW * PH
    arr = os.path.join(CACHE, "arrive.log")
    open(arr, "a").close()
    af = open(arr); af.seek(0, 2)
    pend, last_pts, queue = "", 0.0, collections.deque()
    with os.fdopen(fd, "rb", buffering=0) as f, open(PROBE_LOG, "a") as lg:
        buf = b""
        while True:
            chunk = f.read(size - len(buf))
            if not chunk: break
            buf += chunk
            if len(buf) < size: continue
            now = time.time(); n += 1
            pend += af.read()
            *lines, pend = pend.split("\n")
            for ln in lines:
                p = ln.split()
                if len(p) == 3: queue.append((float(p[0]), float(p[2])))
            # frames decode in arrival order, a few ms after their packet: match first in, first out.
            # Wi-Fi delivers bursts (3 packets at once after a 100 ms gap), so "newest packet" would mislabel them.
            while queue and now - queue[0][0] > 0.05: queue.popleft()  # a packet whose frame never came out
            if queue and queue[0][0] <= now: last_pts = queue.popleft()[1]
            lg.write("%.6f %d %.1f %.6f\n" % (now, n, sum(buf) / size, last_pts)); lg.flush()
            with open(PROBE_LAST + ".tmp", "wb") as o: o.write(buf + struct.pack("dd", now, last_pts))
            os.replace(PROBE_LAST + ".tmp", PROBE_LAST)
            buf = b""


H264_SOCK, H264_META = os.path.join(CACHE, "h264.sock"), os.path.join(CACHE, "h264.json")
H264_GOP, H264_KBPS = int(os.environ.get("EYES_H264_GOP", "60")), int(os.environ.get("EYES_H264_KBPS", "2500"))


def h264_server(fd):
    """The encoder's Annex B bytes, cut into access units, to every client of h264.sock. A client first gets the
    group since the last keyframe (SPS, PPS, IDR and what followed, at most H264_GOP frames), so it decodes at
    once; then each new unit as it arrives. Framing per unit: 4-byte big-endian length, 1 flag byte (bit 0 = key),
    8-byte double receive time, then the bytes. A client that falls 60 units behind is cut back to the next keyframe.
    h264.json has the live numbers: frames and kbit per second, keyframe interval, group size."""
    import socket, struct, collections
    lock = threading.Lock(); clients = []; group = []; stats = {"units": 0, "bytes": 0, "keys": 0, "t_key": 0.0, "key_gaps": collections.deque(maxlen=10), "win": collections.deque()}

    def frame(au, key, t): return struct.pack(">IBd", len(au), 1 if key else 0, t) + au

    def serve_client(c):
        q = collections.deque(); ev = threading.Event()
        with lock:
            for f in group: q.append(f)
            clients.append((q, ev)); n_clients = len(clients)
        try:
            while True:
                if not q:
                    ev.wait(2.0); ev.clear()
                    if not q: c.sendall(struct.pack(">IBd", 0, 0, time.time())); continue      # keepalive: a zero-length unit
                c.sendall(q.popleft())
        except OSError: pass
        finally:
            with lock:
                clients[:] = [x for x in clients if x[0] is not q]
            c.close()

    def accept():
        try: os.unlink(H264_SOCK)
        except FileNotFoundError: pass
        srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); srv.bind(H264_SOCK); srv.listen(8)
        while True:
            c, _ = srv.accept(); threading.Thread(target=serve_client, args=(c,), daemon=True).start()
    threading.Thread(target=accept, daemon=True).start()

    buf = b""; pending = []; t_meta = 0.0
    with os.fdopen(fd, "rb", buffering=0) as f:
        while True:
            chunk = f.read(1 << 18)
            if not chunk: break
            buf += chunk
            # every NAL between start codes; the last one may be incomplete, so keep it
            starts = [m.start() for m in re.finditer(b"\x00\x00\x01", buf)]
            if len(starts) < 2: continue
            units = []
            for i in range(len(starts) - 1):
                a = starts[i] - 1 if starts[i] > 0 and buf[starts[i] - 1] == 0 else starts[i]
                b = starts[i + 1] - 1 if buf[starts[i + 1] - 1] == 0 else starts[i + 1]
                units.append(buf[a:b])
            buf = buf[starts[-1] - 1 if buf[starts[-1] - 1] == 0 else starts[-1]:]
            now = time.time()
            for u in units:
                i = u.find(b"\x00\x01") + 2; typ = u[i] & 0x1F
                if typ in (1, 5):                 # a slice ends an access unit: the parameter sets and SEI before it ride along
                    au = b"".join(pending) + u; pending = []; key = typ == 5
                    fr = frame(au, key, now)
                    with lock:
                        if key:
                            if stats["t_key"]: stats["key_gaps"].append(round(now - stats["t_key"], 2))
                            stats["t_key"] = now; stats["keys"] += 1; group[:] = [fr]
                        else: group.append(fr)
                        stats["units"] += 1; stats["bytes"] += len(au); stats["win"].append((now, len(au)))
                        while stats["win"] and now - stats["win"][0][0] > 2.0: stats["win"].popleft()
                        for q, ev in clients:
                            if len(q) > 60:
                                if not key: continue
                                q.clear()
                            q.append(fr); ev.set()
                else: pending.append(u)
            if now - t_meta > 1.0:
                t_meta = now
                with lock:
                    meta = {"t": now, "fps_2s": round(len(stats["win"]) / 2.0, 1), "kbps_2s": round(sum(n for _, n in stats["win"]) * 8 / 2000.0, 1),
                            "units": stats["units"], "keys": stats["keys"], "key_gap_s": list(stats["key_gaps"]), "group_units": len(group),
                            "group_bytes": sum(len(x) for x in group), "clients": len(clients), "gop": H264_GOP, "kbps_target": H264_KBPS}
                with open(H264_META + ".tmp", "w") as o: json.dump(meta, o)
                os.replace(H264_META + ".tmp", H264_META)


def serve(fps=30, res="1640x2360"):
    os.makedirs(CACHE, exist_ok=True)
    r, w = os.pipe()
    pr, pw = os.pipe()  # probe: PW x PH GRAY8 raw per frame, no decode needed on our side
    sync = os.environ.get("EYES_SYNC", "false")
    # UxPlay names the first word of -vs and appends " sync=false" to the end, so the chain starts with a plain
    # queue and the last sink takes UxPlay's sync setting.
    hr, hw = os.pipe()  # video: H.264 (Annex B, one access unit per buffer) from Apple's hardware encoder, for browsers
    sink = ("queue ! tee name=t t. ! queue ! jpegenc quality=90 ! fdsink fd=%d sync=%s "
            "t. ! queue ! videoconvertscale ! video/x-raw,format=GRAY8,width=%d,height=%d ! fdsink fd=%d sync=%s "
            "t. ! queue leaky=downstream max-size-buffers=2 ! vtenc_h264 realtime=true allow-frame-reordering=false max-keyframe-interval=%d bitrate=%d "
            "! h264parse config-interval=-1 ! video/x-h264,stream-format=byte-stream,alignment=au ! fdsink fd=%d"
            % (w, sync, PW, PH, pw, sync, H264_GOP, H264_KBPS, hw))
    exe, renv, rargs = receiver()
    cmd = [exe, "-n", NAME, "-nh", "-p", str(PORT)] + rargs + ["-vsync", "no", "-fps", str(fps), "-s", res, "-vs", sink, "-nc", "no"] + os.environ.get("EYES_UXARGS", "").split()
    log = open(os.path.join(CACHE, "uxplay.log"), "a")
    log.write("\n=== %s %s\n" % (time.strftime("%F %T"), " ".join(cmd))); log.flush()
    env = dict(os.environ, EYES_ARRIVE=os.path.join(CACHE, "arrive.log"), **renv)
    p = subprocess.Popen(cmd, pass_fds=(w, pw, hw), stdout=log, stderr=subprocess.STDOUT, env=env)
    os.close(w); os.close(pw); os.close(hw)
    threading.Thread(target=probe_reader, args=(pr,), daemon=True).start()
    threading.Thread(target=h264_server, args=(hr,), daemon=True).start()
    state = {"seq": 0, "t": 0.0, "times": [], "stream": False}

    def watch_log():  # connection state from UxPlay's own log lines
        path = os.path.join(CACHE, "uxplay.log")
        with open(path) as f:
            f.seek(0, 2)
            while p.poll() is None:
                line = f.readline()
                if not line: time.sleep(0.1); continue
                if re.search(r"Begin streaming|connection request|Accepted .* connection|raop_rtp_mirror starting", line): state["stream"] = True
                if re.search(r"Teardown|connection closed|Stop streaming|client stopped", line, re.I): state["stream"] = False
    threading.Thread(target=watch_log, daemon=True).start()

    buf = b""
    with os.fdopen(r, "rb", buffering=0) as f:
        while True:
            chunk = f.read(1 << 20)
            if not chunk: break
            buf += chunk
            while True:
                s = buf.find(b"\xff\xd8")
                if s < 0: buf = b""; break
                e = buf.find(b"\xff\xd9", s + 2)
                if e < 0: buf = buf[s:]; break
                jpg, buf = buf[s:e + 2], buf[e + 2:]
                now = time.time()
                state["seq"] += 1; state["t"] = now; state["stream"] = True
                state["times"] = [t for t in state["times"] if now - t < 2.0] + [now]
                size = jpeg_size(jpg) or (0, 0)
                tmp = LATEST + ".tmp"
                with open(tmp, "wb") as o: o.write(jpg)
                os.replace(tmp, LATEST)
                if state["seq"] % 1 == 0:
                    # keep the newest 300 frames' receive times for latency checks
                    meta = {"seq": state["seq"], "t_recv": now, "width": size[0], "height": size[1],
                            "fps_2s": round(len(state["times"]) / 2.0, 1), "stream": state["stream"], "pid": os.getpid()}
                    with open(META + ".tmp", "w") as o: json.dump(meta, o)
                    os.replace(META + ".tmp", META)
                if os.environ.get("EYES_KEEP"):  # optional frame archive for grading
                    d = os.path.join(CACHE, "frames"); os.makedirs(d, exist_ok=True)
                    with open(os.path.join(d, "%.3f.jpg" % now), "wb") as o: o.write(jpg)
    p.wait()


def see():
    m = json.load(open(META))
    m["age_s"] = round(time.time() - m["t_recv"], 3)
    m["path"] = LATEST
    return m


def ocr(path):
    if not os.path.exists(OCR):
        subprocess.check_call(["swiftc", "-O", os.path.join(os.path.dirname(HERE), "tools", "ocr.swift"), "-o", OCR])
    return json.loads(subprocess.check_output([OCR, path, "--json"]))


def snapshot():
    """Copy the newest frame so OCR reads one consistent image; returns (path, meta)."""
    m = see()
    path = os.path.join(CACHE, "snap_%d.jpg" % m["seq"])
    with open(LATEST, "rb") as i, open(path, "wb") as o: o.write(i.read())
    return path, m


def find(text, exact=False):
    path, m = snapshot()
    o = ocr(path)
    W, H = o["width"], o["height"]
    want = text.lower().strip()
    hits = []
    for t in o["texts"]:
        got = t["text"].lower().strip()
        if exact: score = 1.0 if got == want else 0.0
        elif got == want: score = 1.0
        elif re.search(r"(^|\W)" + re.escape(want) + r"($|\W)", got): score = 0.75 + 0.2 * len(want) / max(len(got), 1)
        else: score = difflib.SequenceMatcher(None, want, got).ratio() * 0.8
        if score >= 0.6:
            hits.append({"text": t["text"], "score": round(score, 3), "x": round(t["cx"] / W, 4), "y": round(t["cy"] / H, 4),
                         "box": [t["x"], t["y"], t["w"], t["h"]], "conf": round(t["conf"], 2)})
    hits.sort(key=lambda h: -h["score"])
    return {"frame_seq": m["seq"], "frame_age_s": m["age_s"], "frame": [W, H], "hits": hits, "snap": path}


def wait_change(after_seq, timeout=4.0, after_t=None):
    """First frame newer than after_seq (or received after after_t); returns its meta or None."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            m = json.load(open(META))
            if (m["t_recv"] > after_t) if after_t else (m["seq"] > after_seq): return m
        except Exception: pass
        time.sleep(0.02)
    return None


def confirm(expect, after_seq, timeout=6.0):
    """OCR each new frame after after_seq until `expect` shows; returns (meta, seconds) or (None, None)."""
    t0, last = time.time(), after_seq
    while time.time() - t0 < timeout:
        m = wait_change(last, timeout=max(0.05, timeout - (time.time() - t0)))
        if not m:
            # still screen: read the newest frame once more (the change may already be in it)
            m = see()
            if m["seq"] == last and last != after_seq: time.sleep(0.05); continue
        last = m["seq"]
        f = find(expect)
        if f["hits"] and f["hits"][0]["score"] >= 0.75: return f, time.time() - t0
    return None, None


def tap_text(dev, text, expect=None, dy_pt=0.0, exact=False, timeout=6.0):
    f = find(text, exact)
    rec = {"target": text, "expect": expect, "t": time.strftime("%H:%M:%S"), "found_frame_seq": f["frame_seq"],
           "found_frame_age_s": f["frame_age_s"]}
    if not f["hits"] or f["hits"][0]["score"] < 0.75:
        rec.update(ok=False, why="target not on screen", seen=[h["text"] for h in f["hits"]][:5]); log(rec); return rec
    h = f["hits"][0]
    x, y = h["x"], h["y"] + dy_pt / (f["frame"][1] / 2.0)  # frame px = 2 x points on this iPad
    seq0 = see()["seq"]; t0 = time.time()
    subprocess.check_call([sys.executable, BT, "tap", dev, "%.4f" % x, "%.4f" % y], stdout=subprocess.DEVNULL)
    t_tap = time.time()
    m = wait_change(seq0, 3.0)
    rec.update(hit=h["text"], x=round(x, 4), y=round(y, 4), tap_call_s=round(t_tap - t0, 3),
               first_new_frame_after_tap_s=round(m["t_recv"] - t_tap, 3) if m else None)
    if expect:
        c, secs = confirm(expect, seq0, timeout)
        rec.update(ok=c is not None, confirmed_s=round(secs, 3) if secs else None,
                   confirm_frame_seq=c["frame_seq"] if c else None, confirm_frame_age_s=c["frame_age_s"] if c else None,
                   confirm_text=c["hits"][0]["text"] if c else None)
    else:
        rec["ok"] = m is not None
    log(rec); return rec


# Control Center spots on an iPad Air 11 in portrait, read from live frames on 2026-11-05.
CC_OPEN, CC_MIRROR_TILE, CC_FIRST_RECEIVER = (0.93, 0.006), (0.712, 0.246), (0.6787, 0.2919)


def restart(dev, wait_s=20.0):
    """Start mirroring to this receiver with no person: open Control Center, Screen Mirroring, first row.
    Blind by necessity (no frames until it works). The first row is this receiver while its name sorts first."""
    seq0 = see()["seq"] if os.path.exists(META) else 0
    t0 = time.time()
    # Known start: Home Screen. Home closes an open Control Center or app (a blind tap would toggle it instead).
    home(dev, 2)
    for (x, y), pause in ((CC_OPEN, 1.2), (CC_MIRROR_TILE, 1.5), (CC_FIRST_RECEIVER, 0.1)):
        subprocess.check_call([sys.executable, BT, "tap", dev, str(x), str(y)], stdout=subprocess.DEVNULL)
        time.sleep(pause)
    m = wait_change(seq0, wait_s, after_t=t0 + 4.0)  # by time: a new serve restarts the frame count
    rec = {"verb": "restart", "ok": m is not None, "first_frame_s": round(m["t_recv"] - t0, 3) if m else None}
    if m:  # close the menu by sight
        time.sleep(1.0)
        f = find("Stop Mirroring")
        rec["menu_seen"] = bool(f["hits"])
        rec["receiver_checked"] = bool(find("iPad Eyes")["hits"])
        home(dev, 2)  # 1st Home closes the menu, 2nd closes Control Center (Escape does neither)
        rec["control_center_closed"] = not find("Focus")["hits"]
    log(rec); return rec


def home(dev, n=1):
    for _ in range(n):
        subprocess.check_call([sys.executable, BT, "media", dev, "home"], stdout=subprocess.DEVNULL); time.sleep(1.0)


def stop(dev):
    """Stop mirroring, by sight: Control Center, Screen Mirroring, the 'Stop Mirroring' row."""
    home(dev, 2)
    tries = 0
    for tries in (1, 2):  # the Control Center tap missed once in 8 (2026-11-05); check by sight, retry once
        subprocess.check_call([sys.executable, BT, "tap", dev, str(CC_OPEN[0]), str(CC_OPEN[1])], stdout=subprocess.DEVNULL); time.sleep(1.2)
        if find("Focus")["hits"]: break
        home(dev, 1)
    subprocess.check_call([sys.executable, BT, "tap", dev, str(CC_MIRROR_TILE[0]), str(CC_MIRROR_TILE[1])], stdout=subprocess.DEVNULL); time.sleep(1.5)
    r = tap_text(dev, "Stop Mirroring", exact=True)
    r["cc_tries"] = tries
    time.sleep(1.0); home(dev, 2)
    out = {"verb": "stop", "ok": r["ok"], "found_frame_age_s": r["found_frame_age_s"], "cc_tries": tries}
    log(out); return out


def log(rec):
    with open(os.path.join(CACHE, "taps.jsonl"), "a") as o: o.write(json.dumps(rec) + "\n")


def main(a):
    if not a or a[0] in ("-h", "--help"): print(__doc__); return 0
    v = a[0]
    if v == "serve": serve(); return 0
    if v == "stop": r = stop(a[1]); print(json.dumps(r)); return 0 if r["ok"] else 2
    if v == "restart": r = restart(a[1]); print(json.dumps(r)); return 0 if r["ok"] else 2
    if v == "see": print(json.dumps(see())); return 0
    if v == "find": print(json.dumps(find(" ".join(a[1:])))); return 0
    if v == "tap":
        # tap DEV TEXT [--expect TEXT2] [--dy POINTS] [--exact] [--timeout S]
        args, opt = [], {"--expect": None, "--dy": "0", "--timeout": "6"}
        it = iter(a[1:]); exact = False
        for x in it:
            if x in opt: opt[x] = next(it)
            elif x == "--exact": exact = True
            else: args.append(x)
        r = tap_text(args[0], " ".join(args[1:]), opt["--expect"], float(opt["--dy"]), exact, float(opt["--timeout"]))
        print(json.dumps(r)); return 0 if r["ok"] else 2
    print(__doc__); return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
