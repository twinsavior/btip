#!/usr/bin/env python3
"""btip far: any Bluetooth LE program runs against a far home, unchanged.

  btip away run SCRIPT [args]       run a Python program that uses bleak; its radio is the home's
  btip away run -m MODULE [args]    the same for a module
  import far; far.install()         the same from your own code, before the program makes a BleakClient

bleak is the library most Python gadget drivers are written on. This file is a bleak backend: scan, connect, read,
write and notifications go to the home, which checks the owner's switch and logs each call. So a driver someone wrote
for a gadget whose maker quit works from anywhere, with no change to the driver.

What a program sees: devices near the home (ids are the home's ids), each device's services and characteristics,
values, notifications. Not carried yet: descriptors, pairing prompts (the home's own computer pairs when a device asks).
--home NAME before `run` picks a home when more than one is stored."""
import asyncio, json, os, runpy, sys, threading, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import away
from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak.backends.client import BaseBleakClient
from bleak.backends.scanner import AdvertisementData, BaseBleakScanner
from bleak.backends.service import BleakGATTService, BleakGATTServiceCollection
from bleak.exc import BleakError

HOME = {"name": None, "h": None}
SCAN_S = 2.0        # one listen at the home; a scanner repeats it until stopped


async def call(verb, **args):
    """One verb at the home. A refusal comes back as BleakError with the home's own words, which name the next step."""
    if HOME["h"] is None: HOME["name"], HOME["h"] = away.pick(HOME["name"]); await asyncio.to_thread(away.up, HOME["name"], HOME["h"])
    try: return await asyncio.to_thread(away.request, HOME["h"], "POST", "/v1/" + verb, args)
    except away.Blocked as e: raise BleakError(str(e)) from None
    except OSError as e: raise BleakError("the far home did not answer (%s). Next: btip away up" % e) from None


class FarClient(BaseBleakClient):
    def __init__(self, address_or_ble_device, **kw):
        super().__init__(address_or_ble_device, **kw); self._up = False; self._subs = {}; self._name = None; self._mtu = 23

    async def connect(self, pair=False, **kw):
        t = await call("ble_services", device=self.address); col = BleakGATTServiceCollection()
        self._name, self._mtu = t["device"], int(t.get("mtu") or 23)
        for i, s in enumerate(t["services"]):
            svc = BleakGATTService(None, s["chars"][0]["handle"] - 1 if s["chars"] else 60000 + i, s["uuid"]); col.add_service(svc)
            for c in s["chars"]: col.add_characteristic(BleakGATTCharacteristic(None, c["handle"], c["uuid"], c["can"], lambda: self._mtu - 3, svc))
        self.services = col; self._up = True

    async def disconnect(self):
        was = self._up; self._up = False
        for h in list(self._subs): await self._close(h)
        if was:
            try: await call("ble_drop", device=self.address)
            except BleakError: pass
            if self._disconnected_callback: self._disconnected_callback()

    is_connected = property(lambda self: self._up); mtu_size = property(lambda self: self._mtu); name = property(lambda self: self._name or self.address)

    async def pair(self, *a, **k): pass        # the home's computer pairs by itself when the device asks
    async def unpair(self): raise BleakError("unpair is the owner's to do, at the home")

    async def read_gatt_char(self, characteristic, **kw):
        return bytearray.fromhex((await call("ble_read", device=self.address, char=characteristic.handle))["hex"])

    async def write_gatt_char(self, characteristic, data, response):
        await call("ble_write", device=self.address, char=characteristic.handle, hex=bytes(data).hex(), response=bool(response))

    async def read_gatt_descriptor(self, descriptor, **kw): raise BleakError("descriptors are not carried to a far home yet")
    async def write_gatt_descriptor(self, descriptor, data): raise BleakError("descriptors are not carried to a far home yet")

    async def start_notify(self, characteristic, callback, **kw):
        h = HOME["h"] or (await call("status") and HOME["h"]); loop = asyncio.get_running_loop(); ready = loop.create_future()
        url = "http://127.0.0.1:%d/v1/ble_stream?%s" % (h["port"], urllib.parse.urlencode({"device": self.address, "char": characteristic.handle}))
        try: r = await asyncio.to_thread(urllib.request.urlopen, urllib.request.Request(url, headers={"Authorization": "Bearer " + h["token"]}), None, 60)
        except urllib.error.HTTPError as e: raise BleakError(json.loads(e.read() or b"{}").get("error") or "HTTP %d" % e.code) from None
        def pump():
            try:
                for line in r:
                    m = json.loads(line)
                    if m.get("subscribed"): loop.call_soon_threadsafe(lambda via=m["via"]: ready.done() or ready.set_result(via))
                    elif "hex" in m: loop.call_soon_threadsafe(callback, bytearray.fromhex(m["hex"]))
            except Exception: pass
            if self._subs.get(characteristic.handle) is r and not loop.is_closed():        # the stream ended and nobody stopped it: the link is gone
                loop.call_soon_threadsafe(lambda: asyncio.ensure_future(self.disconnect()))
        self._subs[characteristic.handle] = r; threading.Thread(target=pump, daemon=True).start()
        await asyncio.wait_for(ready, 50)

    async def _close(self, handle):
        r = self._subs.pop(handle, None)
        if r is not None:
            try: r.fp.raw._sock.shutdown(2)        # wakes the reader thread at once; close() alone waits for the next line
            except Exception: pass
            try: await asyncio.wait_for(asyncio.to_thread(r.close), 3)
            except Exception: pass

    async def stop_notify(self, characteristic): await self._close(characteristic.handle)


class FarScanner(BaseBleakScanner):
    def __init__(self, detection_callback=None, service_uuids=None, scanning_mode="active", **kw):
        super().__init__(detection_callback, service_uuids); self._task = None

    async def _listen(self):
        while True:
            for d in (await call("ble_scan", seconds=SCAN_S))["devices"]:
                if not self.is_allowed_uuid(d["services"]): continue
                adv = AdvertisementData(d["name"] or None, {int(k): bytes.fromhex(v) for k, v in d.get("maker_data", {}).items()},
                                        {k: bytes.fromhex(v) for k, v in d.get("service_data", {}).items()}, d["services"], None, d["rssi"], ())
                self.call_detection_callbacks(self.create_or_update_device(d["id"], d["id"], d["name"] or None, None, adv), adv)

    async def start(self):
        self.seen_devices = {}; self._task = asyncio.ensure_future(self._listen())

    async def stop(self):
        if self._task: self._task.cancel(); self._task = None


def install(home=None):
    """Point bleak at the far home. Every BleakClient and BleakScanner made after this uses it."""
    import bleak, bleak.backends.client as bc, bleak.backends.scanner as bs
    HOME["name"] = home or os.environ.get("BTIP_HOME") or None
    for mod in (bleak, bc): mod.get_platform_client_backend_type = lambda: (FarClient, "btip-far")
    for mod in (bleak, bs): mod.get_platform_scanner_backend_type = lambda: (FarScanner, "btip-far")


def run(argv, home=None):
    if not argv: print(__doc__); return 1
    install(home)
    if argv[0] == "-m": sys.argv = argv[1:]; runpy.run_module(argv[1], run_name="__main__", alter_sys=True)
    else: sys.argv = argv; sys.path.insert(0, os.path.dirname(os.path.abspath(argv[0]))); runpy.run_path(argv[0], run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
