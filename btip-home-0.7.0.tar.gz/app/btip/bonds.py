#!/usr/bin/env python3
"""bonds.py: the devices this home's computer is already paired with, and what those pairings allow (macOS).

The OS holds the keys and the profile list of every paired device, and any process may read that list and
act through it. So a paired device needs no new pairing before a far operator can use it: the owner flips
one switch. Sound goes to and from one named device; the system's default output is never moved.

  bonds.py list                    paired devices: kind, battery, what each offers
  bonds.py connect NAME | disconnect NAME
  bonds.py noise NAME [off|cancel|transparency|adaptive]
  bonds.py speak NAME "text"       text to speech through that device
  bonds.py play NAME FILE          a sound file through that device
  bonds.py listen NAME SECONDS OUT.m4a     record that device's microphone"""
import json, os, re, shutil, subprocess, sys, time

KINDS = {1: "computer or tablet", 2: "phone", 4: "headphones or speaker", 5: "keyboard, mouse or controller"}
NOISE = {"off": 1, "cancel": 2, "transparency": 3, "adaptive": 4}
_cls = None


class Blocked(Exception):
    """A refusal or failure. The message names the next step."""


def _device_class():
    global _cls
    if _cls is None:
        if sys.platform != "darwin": raise Blocked("reuse of the computer's own pairings is built for macOS only. Next: on Linux use `btip lend`, which hands over the whole radio")
        import objc
        objc.loadBundle("IOBluetooth", {}, bundle_path="/System/Library/Frameworks/IOBluetooth.framework")
        _cls = objc.lookUpClass("IOBluetoothDevice")
    return _cls


def _num(d, sel):
    try: return int(getattr(d, sel)()) if d.respondsToSelector_(sel) else 0
    except Exception: return 0


def norm(name): return re.sub(r"\s+", " ", str(name).replace("’", "'")).strip().lower()


def _row(d):
    try: services = [str(r.getServiceName()) for r in (d.services() or []) if r.getServiceName()]
    except Exception: services = []
    batt = {k: v for k, v in (("left", _num(d, "batteryPercentLeft")), ("right", _num(d, "batteryPercentRight")),
                              ("case", _num(d, "batteryPercentCase")), ("level", _num(d, "batteryPercentSingle"))) if v}
    addr = str(d.addressString() or "").lower()
    return {"name": str(d.name() or addr), "addr": addr, "kind": KINDS.get(_num(d, "deviceClassMajor")), "connected": bool(d.isConnected()),
            "battery": batt, "services": services, "audio_out": "Audio Sink" in services, "mic": "Handsfree" in services,
            "noise_control": bool(_num(d, "isANCSupported")) and d.respondsToSelector_("setListeningMode:")}


def paired():
    """Every device in the computer's pairing list. Costs about 0.1 s and touches no radio."""
    rows, seen = [], set()
    for d in _device_class().pairedDevices() or []:
        r = _row(d)
        if r["addr"] in seen: continue
        seen.add(r["addr"]); rows.append(r)
    return rows


def find(name):
    want = norm(name); hits = [d for d in _device_class().pairedDevices() or [] if norm(d.name() or "") == want or str(d.addressString() or "").lower() == want.replace(":", "-")]
    if not hits: raise Blocked("'%s' is not paired with this computer. Next: pair it once in System Settings > Bluetooth at home" % name)
    hits.sort(key=lambda d: -len(d.services() or []))        # a name can have a second, service-less entry (its LE identity)
    return hits[0]


def connect(name, wait=12):
    d = find(name); t0 = time.time()
    if not d.isConnected():
        rc = d.openConnection()
        if rc != 0: raise Blocked("'%s' did not answer a connect (code 0x%x). It may be out of range, in its case, or held by another device. Next: bring it near the home computer, then retry" % (name, rc & 0xFFFFFFFF))
    while time.time() - t0 < wait and not d.isConnected(): time.sleep(0.2)
    return {"device": str(d.name()), "connected": bool(d.isConnected()), "s": round(time.time() - t0, 1)}


def disconnect(name):
    d = find(name)
    if d.isConnected(): d.closeConnection()
    return {"device": str(d.name()), "connected": False}


def noise(name, mode=None):
    d = find(name)
    if not _num(d, "isANCSupported"): raise Blocked("'%s' has no noise control" % name)
    if not d.isConnected(): raise Blocked("'%s' is not connected to the home computer. Next: call connect first" % name)
    words = {v: k for k, v in NOISE.items()}
    if mode is not None:
        if mode not in NOISE: raise Blocked("mode must be one of: %s" % ", ".join(NOISE))
        d.setListeningMode_(NOISE[mode]); time.sleep(0.6)
    now = _num(d, "listeningMode")
    return {"device": str(d.name()), "mode": words.get(now, "unknown (%d)" % now)}


# ----------------------------------------------------------------------------- sound to and from one named device
def _ffmpeg():
    exe = shutil.which("ffmpeg")
    if not exe: raise Blocked("sound needs ffmpeg at home. Next: brew install ffmpeg")
    return exe


def audio_devices():
    """CoreAudio's devices as ffmpeg numbers them: {'in': {name: index}, 'out': [(index, name, uid)]}."""
    out = {"in": {}, "out": []}
    r = subprocess.run([_ffmpeg(), "-hide_banner", "-f", "avfoundation", "-list_devices", "true", "-i", ""], capture_output=True, text=True)
    sect = None
    for line in r.stderr.splitlines():
        if "video devices" in line: sect = None
        elif "audio devices" in line: sect = "in"
        m = re.search(r"\[(\d+)\] (.+)$", line)
        if m and sect: out["in"][m.group(2).strip()] = int(m.group(1))
    r = subprocess.run([_ffmpeg(), "-hide_banner", "-f", "lavfi", "-i", "anullsrc", "-t", "0.01", "-f", "audiotoolbox", "-list_devices", "true", "-"], capture_output=True, text=True)
    for line in r.stderr.splitlines():
        m = re.search(r"\[(\d+)\]\s+(.+?),\s(.+)$", line)
        if m: out["out"].append((int(m.group(1)), m.group(2).strip(), m.group(3).strip()))
    return out


def _audio_index(name, way, wait=8):
    """The ffmpeg index of one device's sound output or input. A Bluetooth device's CoreAudio id carries its address."""
    end = time.time() + wait; want = norm(name)
    try: addr = str(find(name).addressString()).lower()
    except Blocked: addr = "\0"
    while True:
        a = audio_devices()
        if way == "in":
            for n, i in a["in"].items():
                if norm(n) == want: return i
        else:
            for i, n, uid in a["out"]:
                if (norm(n) == want or addr in uid.lower()) and not uid.lower().endswith(":input"): return i
        if time.time() > end: raise Blocked("'%s' is connected but offers no sound %s right now. Next: check it is out of its case and not playing from another device, then retry" % (name, "output" if way == "out" else "input"))
        time.sleep(0.5)


def play(name, path, connect_first=True):
    if connect_first: connect(name)
    i = _audio_index(name, "out"); t0 = time.time()
    r = subprocess.run([_ffmpeg(), "-hide_banner", "-loglevel", "error", "-i", path, "-f", "audiotoolbox", "-audio_device_index", str(i), "-"], capture_output=True, text=True, timeout=120)
    if r.returncode: raise Blocked("could not play through '%s': %s" % (name, r.stderr.strip()[-160:]))
    return {"device": name, "played_s": round(time.time() - t0, 1)}


def speak(name, text, connect_first=True):
    """Text to speech at home, played through one device. The system's default output does not move."""
    import tempfile
    if connect_first: connect(name)
    t0 = time.time(); fd, wav = tempfile.mkstemp(suffix=".aiff"); os.close(fd)
    try:
        r = subprocess.run(["say", "-o", wav, text[:600]], capture_output=True, text=True, timeout=60)
        if r.returncode: raise Blocked("text to speech failed at home: %s" % r.stderr.strip()[-160:])
        play(name, wav, connect_first=False)
    finally: os.unlink(wav)
    return {"device": name, "spoke_chars": len(text[:600]), "s": round(time.time() - t0, 1)}


def listen(name, seconds, out_path, connect_first=True):
    if connect_first: connect(name)
    i = _audio_index(name, "in"); seconds = min(float(seconds), 30.0)
    r = subprocess.run([_ffmpeg(), "-hide_banner", "-loglevel", "error", "-y", "-f", "avfoundation", "-i", ":%d" % i, "-t", "%.1f" % seconds, "-ac", "1", "-c:a", "aac", "-b:a", "48k", out_path],
                       capture_output=True, text=True, timeout=seconds + 30)
    if r.returncode: raise Blocked("could not record from '%s': %s" % (name, r.stderr.strip()[-160:]))
    return {"device": name, "seconds": seconds, "bytes": os.path.getsize(out_path)}


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if not a or a[0] == "list": out = paired()
        elif a[0] == "connect": out = connect(a[1])
        elif a[0] == "disconnect": out = disconnect(a[1])
        elif a[0] == "noise": out = noise(a[1], a[2] if len(a) > 2 else None)
        elif a[0] == "speak": out = speak(a[1], a[2])
        elif a[0] == "play": out = play(a[1], a[2])
        elif a[0] == "listen": out = listen(a[1], a[2], a[3])
        elif a[0] == "audio": out = audio_devices()
        else: print(__doc__); sys.exit(1)
        print(json.dumps(out, indent=1))
    except Blocked as e: print(json.dumps({"ok": False, "error": str(e)})); sys.exit(2)
