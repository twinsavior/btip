#!/usr/bin/env python3
"""btip present --radio mac: the far device appears next to you through this Mac's own Bluetooth (CoreBluetooth).

Nothing to buy and nothing to plug in. A phone or computer near this Mac sees the far device's name and
services, connects, and reads, writes and subscribes as it would to the real thing; each request goes to the
real device through the home, which checks the owner's switch and logs it.

Limits macOS sets (measured 2026-11-06, macOS 26.5.2): the connectable advert carries a name and service ids
only. Maker data and service data are dropped, raw advert bytes are refused, and the private key
kCBAdvDataNonAppleMfgData goes out in a separate non-connectable advert from another address. The address is
the Mac's own. The Generic Access and Generic Attribute services are the Mac's own; a service macOS refuses to
publish is skipped and named. Lines start with a fixed word (MIRROR, READ, WRITE, SUB, ERR)."""
import threading, time

import objc
from Foundation import NSArray, NSData, NSDictionary, NSObject
from PyObjCTools import AppHelper

objc.loadBundle("CoreBluetooth", globals(), bundle_path="/System/Library/Frameworks/CoreBluetooth.framework")
CBPeripheralManager = objc.lookUpClass("CBPeripheralManager"); CBMutableService = objc.lookUpClass("CBMutableService")
CBMutableCharacteristic = objc.lookUpClass("CBMutableCharacteristic"); CBUUID = objc.lookUpClass("CBUUID")
PROPS = {"read": 0x02, "write-without-response": 0x04, "write": 0x08, "notify": 0x10, "indicate": 0x20}
OK, UNLIKELY = 0, 0x0E        # CBATTErrorSuccess, CBATTErrorUnlikelyError
SKIP = ("00001800-0000-1000-8000-00805f9b34fb", "00001801-0000-1000-8000-00805f9b34fb")
STATE = {0: "unknown", 1: "resetting", 2: "unsupported", 3: "not allowed", 4: "off", 5: "on"}


def cbuuid(u):
    u = u.lower()
    return CBUUID.UUIDWithString_(u[4:8] if u.startswith("0000") and u.endswith("-0000-1000-8000-00805f9b34fb") else u)


def room(ids):
    """Bytes left for the name in a legacy advert: 31, less flags (3), the service id list and the name's own 2 bytes.
    Measured 2026-11-06 (macOS 26.5.2): 8 characters fit beside one 128-bit id, and bluetoothd cuts or drops a longer name."""
    short = sum(1 for u in ids if len(u.UUIDString()) == 4); long_ = len(ids) - short
    return 31 - 3 - (2 + 2 * short if short else 0) - (2 + 16 * long_ if long_ else 0) - 2


def fit(services, advertised, name):
    """The service ids to advertise and the name to use. Prefer the ids the far device advertises itself (so an app
    that filters on them finds the copy), else the first published service; one id only, so the name has room."""
    pub = [s.UUID() for s in services]
    want = [u.lower() for u in advertised]
    ids = [u for u in pub if str(u.UUIDString()).lower() in want or cbuuid_str(u) in want][:1] or pub[:1]
    b, r = name.encode(), max(room(ids), 0)
    if len(b) <= r: return ids, name
    return ids, b[:r].decode("utf8", "ignore").rstrip()


def cbuuid_str(u):
    s = str(u.UUIDString()).lower()
    return "0000%s-0000-1000-8000-00805f9b34fb" % s if len(s) == 4 else s


class Delegate(NSObject):
    def initWithMirror_(self, m):
        self = objc.super(Delegate, self).init(); self.m = m; return self

    def peripheralManagerDidUpdateState_(self, pm):
        st = int(pm.state()); self.m.log("RADIO", "this Mac's Bluetooth is %s" % STATE.get(st, st))
        if st == 5: self.m.publish(pm)
        elif st in (2, 3, 4): self.m.fail("this Mac's Bluetooth is %s. Next: turn Bluetooth on, or allow this app in System Settings > Privacy & Security > Bluetooth" % STATE[st])

    def peripheralManager_didAddService_error_(self, pm, svc, err):
        self.m.added(svc, err)

    def peripheralManagerDidStartAdvertising_error_(self, pm, err):
        self.m.advertising(err)

    def peripheralManager_didReceiveReadRequest_(self, pm, req):
        self.m.read(pm, req)

    def peripheralManager_didReceiveWriteRequests_(self, pm, reqs):
        self.m.write(pm, list(reqs))

    def peripheralManager_central_didSubscribeToCharacteristic_(self, pm, central, ch):
        self.m.subscribe(pm, ch, True)

    def peripheralManager_central_didUnsubscribeFromCharacteristic_(self, pm, central, ch):
        self.m.subscribe(pm, ch, False)

    def peripheralManagerIsReadyToUpdateSubscribers_(self, pm):
        self.m.flush(pm)


class MacMirror:
    """`mirror` is present.Mirror (its far() reaches the home, its stream yields notifications)."""

    def __init__(self, mirror, table, name, log):
        self.mi, self.table, self.name, self.log = mirror, table, name, log
        self.by_uuid, self.cache, self.pending, self.subs, self.waiting, self.stats = {}, {}, 0, {}, [], {"read": [], "write": [], "notify": 0}
        self.ready = threading.Event(); self.error = None

    def fail(self, text): self.error = text; self.log("ERR", text); self.ready.set()

    def publish(self, pm):
        self.services = []
        for s in self.table["services"]:
            if s["uuid"].lower() in SKIP: continue
            chars = []
            for ch in s["chars"]:
                props = sum(PROPS.get(c, 0) for c in ch["can"]); perms = (0x01 if "read" in ch["can"] else 0) | (0x02 if props & 0x0C else 0)
                c = CBMutableCharacteristic.alloc().initWithType_properties_value_permissions_(cbuuid(ch["uuid"]), props, None, perms)
                chars.append(c); self.by_uuid.setdefault(str(c.UUID()).lower(), []).append((c, ch["handle"]))
            svc = CBMutableService.alloc().initWithType_primary_(cbuuid(s["uuid"]), True); svc.setCharacteristics_(chars)
            self.pending += 1; self.services.append(svc); pm.addService_(svc)
        self.pm = pm
        if not self.pending: self.start_adv()

    def added(self, svc, err):
        self.pending -= 1
        if err is not None:        # and keep it out of the advert: a service id there costs room the name needs
            self.log("SKIP", "macOS would not publish service %s: %s" % (svc.UUID(), err.localizedDescription()))
            self.services = [s for s in self.services if s is not svc]
        if self.pending == 0: self.start_adv()

    def start_adv(self):
        ids, self.adv_name = fit(self.services, (self.table.get("advert") or {}).get("services") or [], self.name)
        if self.adv_name != self.name:
            self.log("NAME", "'%s' doesn't fit beside service id %s in the Mac's 31-byte advert (room for %d bytes), so the copy is called '%s'. Pick another with --name" % (self.name, ids[0].UUIDString() if ids else "-", room(ids), self.adv_name))
        name = self.adv_name
        # A real NSDictionary, not a Python dict: macOS sends the advert request to bluetoothd over XPC, and PyObjC's
        # dict proxy arrives empty there ("no name", no service ids), so nothing of ours went on air (2026-11-06).
        self.pm.startAdvertising_(NSDictionary.dictionaryWithDictionary_({"kCBAdvDataLocalName": name, "kCBAdvDataServiceUUIDs": NSArray.arrayWithArray_(ids)}))

    def advertising(self, err):
        if err is not None: return self.fail("macOS would not advertise: %s" % err.localizedDescription())
        n = sum(len(v) for v in self.by_uuid.values())
        self.log("MIRROR", "'%s' is advertising from this Mac: %d characteristics from the far device" % (self.adv_name, n)); self.ready.set()

    def handle_of(self, ch):
        hits = self.by_uuid.get(str(ch.UUID()).lower(), [])
        return next((h for c, h in hits if c is ch or c.isEqual_(ch)), hits[0][1] if hits else None)

    def read(self, pm, req):
        h = self.handle_of(req.characteristic()); off = int(req.offset())
        if off and h in self.cache:        # the rest of a long value: answer from the copy of the first read
            req.setValue_(NSData.dataWithBytes_length_(self.cache[h][off:], len(self.cache[h]) - off)); return pm.respondToRequest_withResult_(req, OK)
        def go():
            t = time.time()
            try: v = bytes.fromhex(self.mi.rq("ble_read", {"device": self.mi.device, "char": h})["hex"]); res = OK
            except Exception as e: v = b""; res = UNLIKELY; self.log("ERR", "read %s: %s" % (h, e))
            self.cache[h] = v; ms = round((time.time() - t) * 1000); self.stats["read"].append(ms)
            if res == OK: self.log("READ", "handle %s, %d bytes, %d ms through the home: %s" % (h, len(v), ms, v[:20].hex()))
            def answer():
                if res == OK: req.setValue_(NSData.dataWithBytes_length_(v, len(v)))
                pm.respondToRequest_withResult_(req, res)
            AppHelper.callAfter(answer)
        threading.Thread(target=go, daemon=True).start()

    def write(self, pm, reqs):
        def go():
            res = OK
            for r in reqs:
                h = self.handle_of(r.characteristic()); data = bytes(r.value() or b""); t = time.time()
                if not (int(r.characteristic().properties()) & 0x0C):        # a read-only grant: the table had no write property; refuse here, before the home (CBATTErrorWriteNotPermitted = 3)
                    res = 3; self.log("REFUSED", "write handle %s: this value is read-only here" % h); continue
                try: self.mi.rq("ble_write", {"device": self.mi.device, "char": h, "hex": data.hex()}); ms = round((time.time() - t) * 1000); self.stats["write"].append(ms); self.log("WRITE", "handle %s, %d bytes, %d ms through the home" % (h, len(data), ms))
                except Exception as e: res = UNLIKELY; self.log("ERR", "write %s: %s" % (h, e))
            AppHelper.callAfter(lambda: pm.respondToRequest_withResult_(reqs[0], res))
        threading.Thread(target=go, daemon=True).start()

    def subscribe(self, pm, ch, on):
        h = self.handle_of(ch)
        if on and h not in self.subs and self.mi.stream:
            stop = threading.Event(); self.subs[h] = stop; self.log("SUB", "handle %s on" % h)
            def pump():
                try:
                    for v in self.mi.stream(self.mi.device, h, stop):
                        if stop.is_set(): break
                        AppHelper.callAfter(self.send, pm, ch, v)
                except Exception as e: self.log("ERR", "stream %s: %s" % (h, e))
            threading.Thread(target=pump, daemon=True).start()
        elif not on and h in self.subs: self.subs.pop(h).set(); self.log("SUB", "handle %s off" % h)

    def send(self, pm, ch, v):
        if pm.updateValue_forCharacteristic_onSubscribedCentrals_(NSData.dataWithBytes_length_(v, len(v)), ch, None): self.stats["notify"] += 1
        else: self.waiting.append((ch, v))        # the radio's queue is full: send again when macOS says it is ready

    def flush(self, pm):
        while self.waiting:
            ch, v = self.waiting[0]
            if not pm.updateValue_forCharacteristic_onSubscribedCentrals_(NSData.dataWithBytes_length_(v, len(v)), ch, None): return
            self.waiting.pop(0); self.stats["notify"] += 1


def run(mirror, table, name, log, seconds=None):
    """Start the copy on this Mac's radio and keep it until Ctrl-C (or `seconds`)."""
    m = MacMirror(mirror, table, name, log)
    d = Delegate.alloc().initWithMirror_(m); pm = CBPeripheralManager.alloc().initWithDelegate_queue_options_(d, None, None)
    m.keep = (d, pm)
    if seconds: AppHelper.callLater(seconds, AppHelper.stopEventLoop)
    AppHelper.runConsoleEventLoop(installInterrupt=True)
    pm.stopAdvertising(); return m
