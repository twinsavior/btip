#!/usr/bin/env python3
"""btip away: reach a home from anywhere. One short code the first time, none after.

  btip away enroll CODE            once: store the home's permanent address and your token (the code comes from `btip home invite`)
  btip away add NAME < link.txt   or store a link from the owner's page (Make a link), read from stdin
  btip away call VERB [JSON]       one verb, JSON out. Example: btip away call tap_text '{"text":"Settings","expect":"General"}'
  btip away verbs                  what the home offers
  btip away see FILE.jpg           save the device screen as it is now
  btip away open                   the live page in your browser (screen, tap, type, BLE)
  btip away mcp                    the same verbs as an MCP server over stdio, for an agent
  btip away run SCRIPT [args]      run any Python program that uses bleak (most gadget drivers do); its radio is the home's
  btip away up | down | homes      open or close the tunnel by hand; list stored homes

Every command opens the tunnel by itself when it is down. Both ends dial out; nothing is forwarded.
--home NAME picks a home when more than one is stored."""
import base64, json, os, re, socket, subprocess, sys, time, urllib.error, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
CONF = os.environ.get("BTIP_AWAY_CONF") or os.path.expanduser("~/.config/btip/away.json"); CACHE = os.path.expanduser("~/.cache/btip")
APPID = "twinsavior.github.io/btip/home/1"; MAILBOX = "ws://relay.magic-wormhole.io:4000/v1"


class Blocked(Exception):
    """A refusal or failure. The message names the next step."""


def load():
    try: return json.load(open(CONF))
    except FileNotFoundError: return {"homes": {}}


def save(cfg):
    os.makedirs(os.path.dirname(CONF), exist_ok=True)
    fd = os.open(CONF + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f: json.dump(cfg, f, indent=1)
    os.replace(CONF + ".tmp", CONF)


def pick(name=None):
    homes = load()["homes"]
    if not homes: raise Blocked("no home is stored on this machine. Next: at home run `btip home invite`, then here `btip away enroll CODE`")
    if name is None and len(homes) > 1: raise Blocked("more than one home is stored (%s). Next: add --home NAME" % ", ".join(homes))
    name = name or next(iter(homes))
    if name not in homes: raise Blocked("no stored home named '%s'. Stored: %s" % (name, ", ".join(homes)))
    return name, homes[name]


def enroll(code, as_name=None):
    from twisted.internet import defer, reactor
    import wormhole
    out = {}

    @defer.inlineCallbacks
    def main():
        w = wormhole.create(APPID, MAILBOX, reactor); w.set_code(code)
        w.send_message(json.dumps({"name": socket.gethostname().split(".")[0]}).encode())
        out.update(json.loads((yield w.get_message()))); yield w.close()
    def end(f=None):
        if hasattr(f, "getErrorMessage"): out["err"] = "the code did not match" if f.check(wormhole.errors.WrongPasswordError) else (f.getErrorMessage() or repr(f.value))
        reactor.stop()
    main().addBoth(end); reactor.run()
    if "ticket" not in out: raise Blocked("%s. Next: at home run `btip home invite` again and use the new code" % out.get("err", "the home sent no address"))
    cfg = load(); name = as_name or out.get("home") or "home"; used = {h["port"] for h in cfg["homes"].values()}
    cfg["homes"][name] = {"ticket": out["ticket"], "token": out["token"], "port": cfg["homes"].get(name, {}).get("port") or next(p for p in range(9101, 9200) if p not in used)}
    save(cfg); return name


# ----------------------------------------------------------------------------- the tunnel
def pidfile(name): return os.path.join(CACHE, "away_%s.pid" % re.sub(r"\W", "_", name))


def tunnel_pid(name):
    try: pid = int(open(pidfile(name)).read())
    except Exception: return None
    try: os.kill(pid, 0); return pid
    except OSError: return None


def answers(h, timeout=4):
    try: return request(h, "GET", "/v1/status", timeout=timeout).get("ok") is not None
    except Blocked as e: return "token" in str(e)        # the home answered, with a refusal
    except Exception: return False


def up(name, h, wait=40):
    """Open the tunnel if it is down. Returns seconds until the home answered."""
    t0 = time.time()
    if tunnel_pid(name) and answers(h): return 0.0
    down(name)
    import btip
    exe = btip.find_dumbpipe()
    if not exe: raise Blocked("the iroh transport is missing. Next: btip get-iroh")
    os.makedirs(CACHE, exist_ok=True); log = open(os.path.join(CACHE, "away_tunnel.log"), "a")
    p = subprocess.Popen([exe, "connect-tcp", "--addr", "127.0.0.1:%d" % h["port"], h["ticket"]], stdout=log, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, start_new_session=True, env={"PATH": os.environ.get("PATH", "")})
    open(pidfile(name), "w").write(str(p.pid))
    while time.time() - t0 < wait:
        if p.poll() is not None: raise Blocked("the tunnel process exited. Next: read %s" % log.name)
        if answers(h, timeout=6): return round(time.time() - t0, 1)
        time.sleep(0.5)
    raise Blocked("the home did not answer in %d s. Next: check that `btip home serve` is running there and that machine is awake" % wait)


def down(name):
    pid = tunnel_pid(name)
    if pid:
        try: os.kill(pid, 15)
        except OSError: pass
    try: os.unlink(pidfile(name))
    except OSError: pass
    return bool(pid)


def request(h, method, path, body=None, timeout=120, raw=False):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (h["port"], path), method=method, data=None if body is None else json.dumps(body).encode(),
                                 headers={"Authorization": "Bearer " + h["token"]})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(); return (data, dict(r.headers)) if raw else json.loads(data)
    except urllib.error.HTTPError as e:
        try: msg = json.loads(e.read()).get("error", "")
        except Exception: msg = "HTTP %d" % e.code
        raise Blocked(msg)


def call(verb, args=None, home=None):
    name, h = pick(home); up(name, h)
    return request(h, "POST", "/v1/" + verb, args or {})


def see(path=None, w=0, home=None):
    name, h = pick(home); up(name, h)
    data, hd = request(h, "GET", "/v1/frame.jpg?w=%d" % w, raw=True)
    if path: open(path, "wb").write(data)
    return data, {"frame_age_s": float(hd.get("X-Frame-Age", -1)), "bytes": len(data), "path": path}


# ----------------------------------------------------------------------------- MCP over stdio (no SDK)
def mcp(home=None):
    name, h = pick(home); tools = None
    def out(mid, **kw): sys.stdout.write(json.dumps(dict({"jsonrpc": "2.0", "id": mid}, **kw)) + "\n"); sys.stdout.flush()
    for line in sys.stdin:
        if not line.strip(): continue
        m = json.loads(line); meth, mid = m.get("method"), m.get("id")
        if mid is None: continue
        try:
            if meth == "initialize":
                out(mid, result={"protocolVersion": m["params"].get("protocolVersion", "2025-06-18"), "capabilities": {"tools": {}}, "serverInfo": {"name": "btip-" + name, "version": "0.2"},
                                 "instructions": "A far home: a real iPad you can see and drive over Bluetooth, and the BLE devices near it. Call status, then wake. Prefer read_screen and tap_text (they run at the home, so lag does not matter) over see + tap."})
            elif meth == "tools/list":
                up(name, h); tools = request(h, "GET", "/v1/verbs")["verbs"]; out(mid, result={"tools": tools})
            elif meth == "tools/call":
                tool, args = m["params"]["name"], m["params"].get("arguments", {})
                try:
                    if tool == "see":
                        data, info = see(w=int(args.get("w", 600)), home=name)
                        content = [{"type": "text", "text": json.dumps(info)}, {"type": "image", "mimeType": "image/jpeg", "data": base64.b64encode(data).decode()}]
                    else: content = [{"type": "text", "text": json.dumps(call(tool, args, name))}]
                    out(mid, result={"content": content})
                except Blocked as e: out(mid, result={"content": [{"type": "text", "text": "Refused: %s" % e}], "isError": True})
            elif meth == "ping": out(mid, result={})
            else: out(mid, error={"code": -32601, "message": "unknown method " + str(meth)})
        except Exception as e: out(mid, error={"code": -32000, "message": str(e) or repr(e)})


def cli(argv=None):
    a = list(sys.argv[1:] if argv is None else argv); home = None
    if "--home" in a: i = a.index("--home"); home = a[i + 1]; del a[i:i + 2]
    c = a[0] if a else "help"
    try:
        if c == "enroll": r = {"ok": True, "home": enroll(a[1], a[2] if len(a) > 2 else None), "next": "btip away call status"}
        elif c == "add":        # a link from the owner's page, read from stdin (it holds a key, so never from argv)
            import urllib.parse
            link = sys.stdin.readline().strip(); q = urllib.parse.parse_qs(link.split("#", 1)[-1])
            if not q.get("ticket") or not q.get("t"): raise Blocked("that is not a btip link (it ends in #ticket=...&t=...). Next: ask the home's owner for a link from their page")
            cfg = load(); name = a[1]; used = {h["port"] for n, h in cfg["homes"].items() if n != name}
            cfg["homes"][name] = {"ticket": q["ticket"][0], "token": q["t"][0], "port": cfg["homes"].get(name, {}).get("port") or next(p for p in range(9101, 9200) if p not in used)}
            save(cfg); r = {"ok": True, "home": name, "next": "btip away --home %s call status" % name}
        elif c == "call": r = call(a[1], json.loads(a[2]) if len(a) > 2 else {}, home)
        elif c == "verbs": name, h = pick(home); up(name, h); r = request(h, "GET", "/v1/verbs")
        elif c == "see": r = see(a[1], int(a[2]) if len(a) > 2 else 0, home)[1]
        elif c == "up": name, h = pick(home); r = {"ok": True, "home": name, "ready_s": up(name, h), "url": "http://127.0.0.1:%d/" % h["port"]}
        elif c == "down": name, h = pick(home); r = {"ok": True, "closed": down(name)}
        elif c == "open":
            name, h = pick(home); up(name, h); import webbrowser
            webbrowser.open("http://127.0.0.1:%d/?t=%s" % (h["port"], h["token"])); r = {"ok": True, "url": "http://127.0.0.1:%d/" % h["port"]}
        elif c == "homes": r = {"ok": True, "homes": {n: {"port": h["port"], "tunnel_up": bool(tunnel_pid(n))} for n, h in load()["homes"].items()}}
        elif c == "mcp": return mcp(home)
        elif c == "run": import far; return far.run(a[1:], home)
        else: print(__doc__); return 0
    except Blocked as e: r = {"ok": False, "error": str(e)}
    except (IndexError, ValueError): print(__doc__); return 1
    print(json.dumps(r, indent=1)); return 0 if r.get("ok", True) else 2


if __name__ == "__main__":
    sys.exit(cli())
