#!/usr/bin/env python3
"""btip present: a far Bluetooth LE device appears next to you as a real one.

  btip present DEVICE [--home NAME]                 on a Mac: this Mac's own Bluetooth, nothing to plug in
  btip present DEVICE --radio hci-socket:0          Linux, or any raw HCI radio (Bumble)

This machine's radio advertises with the far device's name, services and maker data. A phone or computer
near you connects to it as it would to the real thing: its own app, unchanged. Every read, write and
subscription is carried to the real device through `btip away`, so the device's owner must have switched
it on at home, and the home logs each call.

The radio must be one this process owns (raw HCI): Linux `hci-socket:0` as root, a USB dongle
(`usb:0`), or a far radio from `btip join` (`tcp-client:127.0.0.1:9001`). Needs bumble.
Lines start with a fixed word (MIRROR, READ, WRITE, SUB, ERR)."""
import asyncio, json, os, sys, threading, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
CONF = os.path.expanduser("~/.config/btip/present.json")
BASE = "-0000-1000-8000-00805f9b34fb"
SKIP = ("00001800" + BASE, "00001801" + BASE)        # the mirror's own stack serves these two (device name, service changed)
STATIC = ("0000180a" + BASE,)                         # Device Information does not change: one far read, then the copy


def say(word, text=""): print("%s %-7s %s" % (time.strftime("%H:%M:%S"), word, text), flush=True)


class Mirror:
    """One far device, served on a local Bumble host. `rq(verb, args)` reaches the home; `stream(device, char)` yields its notifications."""

    def __init__(self, device, rq, stream=None, log=say, name=None):
        self.device, self.rq, self.stream, self.log, self.name = device, rq, stream, log, name
        self.cache, self.stats, self.subs = {}, [], {}

    async def far(self, verb, **args):
        t = time.time()
        try: return await asyncio.to_thread(self.rq, verb, dict(args, device=self.device))
        finally: self.stats.append((verb, round((time.time() - t) * 1000)))

    def advert(self, table):
        """Advertising bytes that copy the far device: flags, service ids, maker data, name. Overflow goes to the scan response."""
        from bumble.core import AdvertisingData, UUID
        a = table.get("advert") or {}; name = (self.name or a.get("name") or table["device"]).encode()[:29]; parts = [(AdvertisingData.FLAGS, b"\x06")]
        short = [u for u in a.get("services", []) if u.endswith(BASE) and u.startswith("0000")]; long_ = [u for u in a.get("services", []) if u not in short]
        if short: parts.append((AdvertisingData.COMPLETE_LIST_OF_16_BIT_SERVICE_CLASS_UUIDS, b"".join(bytes(UUID(u[4:8])) for u in short)))
        if long_: parts.append((AdvertisingData.COMPLETE_LIST_OF_128_BIT_SERVICE_CLASS_UUIDS, b"".join(bytes(UUID(u)) for u in long_[:1])))
        for cid, hx in (a.get("maker_data") or {}).items(): parts.append((AdvertisingData.MANUFACTURER_SPECIFIC_DATA, int(cid).to_bytes(2, "little") + bytes.fromhex(hx)))
        size = lambda ps: sum(2 + len(v) for _, v in ps); named = (AdvertisingData.COMPLETE_LOCAL_NAME, name); scan = []
        while size(parts) > 31: scan.append(parts.pop())
        if size(parts) + 2 + len(name) <= 31: parts.append(named)
        else: scan.insert(0, named)
        while size(scan) > 31: scan.pop()
        return bytes(AdvertisingData(parts)), bytes(AdvertisingData(scan)), name.decode(errors="replace")

    def services(self, table):
        from bumble.gatt import Service, Characteristic, CharacteristicValue
        from bumble.att import ATT_Error, ATT_UNLIKELY_ERROR_ERROR, ATT_WRITE_NOT_PERMITTED_ERROR
        P = Characteristic.Properties
        bits = {"read": P.READ, "write": P.WRITE, "write-without-response": P.WRITE_WITHOUT_RESPONSE, "notify": P.NOTIFY, "indicate": P.INDICATE}
        out = []; self.by_handle = {}
        for s in table["services"]:
            if s["uuid"] in SKIP: continue
            chars = []
            for ch in s["chars"]:
                props = P(0); perms = 0
                for c in ch["can"]: props |= bits.get(c, P(0))
                if "read" in ch["can"]: perms |= Characteristic.READABLE
                if props & (P.WRITE | P.WRITE_WITHOUT_RESPONSE): perms |= Characteristic.WRITEABLE
                far_handle, static = ch["handle"], s["uuid"] in STATIC

                async def read(conn, h=far_handle, u=ch["uuid"], static=static):
                    if static and h in self.cache: self.log("READ", "%s copy (%d bytes)" % (u[:8], len(self.cache[h]))); return self.cache[h]
                    t = time.time()
                    try: v = bytes.fromhex((await self.far("ble_read", char=h))["hex"])
                    except Exception as e: self.log("ERR", "read %s: %s" % (u[:8], e)); raise ATT_Error(ATT_UNLIKELY_ERROR_ERROR)
                    self.cache[h] = v; self.log("READ", "%s %d bytes, %d ms through the home" % (u[:8], len(v), (time.time() - t) * 1000)); return v

                async def write(conn, value, h=far_handle, u=ch["uuid"], writable=bool(props & (P.WRITE | P.WRITE_WITHOUT_RESPONSE))):
                    if not writable:        # a read-only grant: the table has no write property, and the copy refuses the write before the home sees it (Bumble's server forwards it otherwise, measured 2026-11-06)
                        self.log("REFUSED", "write %s: this value is read-only here" % u[:8]); raise ATT_Error(ATT_WRITE_NOT_PERMITTED_ERROR)
                    t = time.time()
                    try: await self.far("ble_write", char=h, hex=bytes(value).hex())
                    except Exception as e: self.log("ERR", "write %s: %s" % (u[:8], e)); raise ATT_Error(ATT_UNLIKELY_ERROR_ERROR)
                    self.log("WRITE", "%s %d bytes, %d ms through the home" % (u[:8], len(value), (time.time() - t) * 1000))

                c = Characteristic(ch["uuid"], props, perms, CharacteristicValue(read=read, write=write)); c.far_handle = far_handle; chars.append(c)
            out.append(Service(s["uuid"], chars))
        return out

    def on_subscription(self, dev, loop):
        """When a near client subscribes, open the far stream; when the last one leaves, close it."""
        def changed(connection, characteristic, notify, indicate):
            h = getattr(characteristic, "far_handle", None)
            if h is None or not self.stream: return
            if (notify or indicate) and h not in self.subs:
                stop = threading.Event(); self.subs[h] = stop; self.log("SUB", "%s on" % str(characteristic.uuid)[:8])
                def pump():
                    try:
                        for value in self.stream(self.device, h, stop):
                            if stop.is_set(): break
                            asyncio.run_coroutine_threadsafe(dev.notify_subscribers(characteristic, value), loop)
                    except Exception as e: self.log("ERR", "stream %s: %s" % (h, e))
                threading.Thread(target=pump, daemon=True).start()
            elif not (notify or indicate) and h in self.subs: self.subs.pop(h).set(); self.log("SUB", "%s off" % str(characteristic.uuid)[:8])
        dev.on("characteristic_subscription", changed)

    async def start(self, host, address):
        """Build the copy on `host` and advertise it. Returns the Bumble device."""
        from bumble.device import Device
        table = await self.far("ble_services"); adv, scan, name = self.advert(table)
        dev = Device(name=name, address=address, host=host); dev.add_services(self.services(table))
        dev.advertising_data, dev.scan_response_data = adv, scan; self.on_subscription(dev, asyncio.get_running_loop())
        await dev.power_on(); await dev.start_advertising(auto_restart=True)
        n = sum(len(s.characteristics) for s in dev.gatt_server.attributes if hasattr(s, "characteristics"))
        self.log("MIRROR", "'%s' is advertising here as %s: %d characteristics from the far device (table fetched in %d ms)" % (name, dev.random_address, n, self.stats[0][1]))
        return dev


def home_stream(h):
    """Notifications of one far characteristic through the tunnel, as bytes."""
    def stream(device, char, stop):
        req = urllib.request.Request("http://127.0.0.1:%d/v1/ble_stream?device=%s&char=%s" % (h["port"], urllib.request.quote(str(device)), char), headers={"Authorization": "Bearer " + h["token"]})
        with urllib.request.urlopen(req, timeout=30) as r:
            for line in r:
                if stop.is_set(): return
                m = json.loads(line)
                if "hex" in m: yield bytes.fromhex(m["hex"])
    return stream


async def run(o):
    import away
    name, h = away.pick(o.home); secs = away.up(name, h); say("HOME", "'%s' answered in %.1f s" % (name, secs))
    m = Mirror(o.device, lambda verb, args: away.request(h, "POST", "/v1/" + verb, args), home_stream(h), name=o.name)
    if o.radio == "mac":        # this Mac's own Bluetooth: nothing to buy or plug in
        import present_mac
        t = time.time(); table = m.rq("ble_services", {"device": o.device}); say("TABLE", "%d services from the far device in %d ms" % (len(table["services"]), (time.time() - t) * 1000))
        if not table.get("ok", True): raise RuntimeError(table.get("error"))
        name = (o.name or (table.get("advert") or {}).get("name") or table["device"])[:28]
        mm = present_mac.run(m, table, name, say, o.seconds)
        say("STATS", json.dumps({"reads": len(mm.stats["read"]), "read_ms_median": sorted(mm.stats["read"])[len(mm.stats["read"]) // 2] if mm.stats["read"] else None, "writes": len(mm.stats["write"]), "notifications": mm.stats["notify"]}))
        return
    from bumble.transport import open_transport
    from bumble.host import Host
    from bumble.hci import Address
    try: conf = json.load(open(CONF))
    except Exception: conf = {}
    if o.device not in conf:        # one stable address per mirrored device, so a phone finds the same thing again
        conf[o.device] = str(Address.generate_static_address()); os.makedirs(os.path.dirname(CONF), exist_ok=True); json.dump(conf, open(CONF, "w"))
    async with await open_transport(o.radio) as t:
        dev = await m.start(Host(t.source, t.sink), Address(conf[o.device]))
        dev.on("connection", lambda c: say("NEAR", "a device near you connected: %s" % c.peer_address))
        await asyncio.get_running_loop().create_future()


def cli(argv=None):
    import argparse
    ap = argparse.ArgumentParser(prog="btip present", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("device", help="the far device's name, as `btip away call devices` lists it"); ap.add_argument("--home")
    ap.add_argument("--radio", default="mac" if sys.platform == "darwin" else "hci-socket:0", help="mac: this Mac's own Bluetooth (default on a Mac). Or a raw HCI radio for Bumble: hci-socket:0, usb:0, tcp-client:HOST:PORT")
    ap.add_argument("--seconds", type=float, help="stop after this many seconds (tests)")
    ap.add_argument("--name", help="advertise under this name instead of the far device's own (useful when the real device is also in range, as in a test at home)")
    o = ap.parse_args(argv)
    try: asyncio.run(run(o))
    except KeyboardInterrupt: say("STOP", "the copy is gone; the far device is untouched")
    except Exception as e: say("ERR", "%s" % (str(e) or repr(e))); sys.exit(1)


if __name__ == "__main__":
    cli()
