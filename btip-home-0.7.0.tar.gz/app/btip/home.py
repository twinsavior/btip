#!/usr/bin/env python3
"""btip home: this Mac as a standing presence. Everything within its Bluetooth range, reachable from anywhere.

  btip home serve --device bt:AA-BB-CC-DD-EE-FF    hands (Bluetooth keyboard + pointer), eyes (AirPlay), BLE, one local port
  btip home invite [NAME]                          print a short code once; `btip away enroll CODE` stores the identity
  btip home devices                                every Bluetooth device near or paired with this computer, and its switch
  btip home approve DEVICE | unapprove DEVICE      the owner's switch: far ends may use only devices that are on
  btip home list | revoke NAME | owner NAME        who may connect; which far end may flip switches from its page

`serve` listens on 127.0.0.1 only. An iroh endpoint with a stored key carries that one port, so the address
never changes and both ends dial out. Every request needs a token that was handed over by a short code.
The far side sends intentions ("tap the text Settings, expect General"); find, tap and confirm run here,
next to the radio, so tunnel lag does not matter. Lines start with a fixed word (READY, CODE, ERR, ...)."""
import asyncio, base64, hmac, io, json, os, queue, re, secrets, signal, subprocess, sys, threading, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path[:0] = [os.path.join(ROOT, "classic"), os.path.join(ROOT, "eyes"), HERE]
CONF = os.path.join(os.environ.get("BTIP_CONF_DIR") or os.path.expanduser("~/.config/btip"), "home.json")
CACHE = os.environ.get("BTIP_CACHE_DIR") or os.path.expanduser("~/.cache/btip")
PAGE_URL = os.environ.get("BTIP_PAGE") or "https://twinsavior.github.io/btip/"      # the far page; the ticket and token ride in the fragment
LOG = os.path.join(CACHE, "home_log.jsonl"); KNOWN = os.path.join(CACHE, "devices.json"); APPID = "twinsavior.github.io/btip/home/1"
MAILBOX = "ws://relay.magic-wormhole.io:4000/v1"
HOLD = 0.08          # a zero-length press moved the pointer and did not click (iPadOS, 2026-11-05)


def say(word, text=""): print("%s %-8s %s" % (time.strftime("%H:%M:%S"), word, text), flush=True)


class Blocked(Exception):
    """A refusal or failure. The message names the next step."""


def load():
    try: return json.load(open(CONF))
    except FileNotFoundError: return {"secret": secrets.token_hex(32), "tokens": {}, "approved": {}}


def dkey(name):
    """One device, one key: its name as a person reads it. A device with two radios (classic and LE) is one line."""
    return re.sub(r"\s+", " ", str(name).replace("\u2019", "'")).strip().lower()


def knows(device, home=None):
    """A name the home has met: paired with this computer, seen on the radio, learned before (devices.json), or already switched on.
    A typed name that matches none of these is not a device, and a switch for it would sit in the owner's menu forever."""
    k = dkey(device); cfg = load()
    if k in cfg.get("approved", {}): return True
    try:
        if k in json.load(open(KNOWN)): return True
    except Exception: pass
    if home is not None:
        try:
            if any(dkey(b["name"]) == k for b in home.paired()): return True
        except Exception: pass
        return any(dkey(n) == k for _, n in getattr(home.ble, "seen", {}).values() if n)
    try:
        import bonds
        return any(dkey(b["name"]) == k for b in bonds.paired())
    except Exception: return False


def switch(device, on, who="home", home=None):
    """The owner's switch. Far ends may use a device only while it is on. Every flip is logged. Only a device the home has met can be switched on."""
    cfg = load(); ap = cfg.setdefault("approved", {}); k = dkey(device)
    if on and never(device): raise Blocked("'%s' is refused: %s" % (k, never(device)))
    if on and not knows(device, home): raise Blocked("no device named '%s' at this home: not paired, not seen on the radio, not met before. Next: devices lists what is paired or near; the name must match a line there" % device)
    if on: ap[k] = {"name": str(device), "t": time.strftime("%F %T")}
    else: ap.pop(k, None)
    save(cfg); os.makedirs(CACHE, exist_ok=True)
    with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": who, "verb": "approve" if on else "unapprove", "args": {"device": str(device)}, "ok": True}) + "\n")
    return {"device": str(device), "on": bool(on)}


def save(cfg):
    os.makedirs(os.path.dirname(CONF), exist_ok=True)
    fd = os.open(CONF + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f: json.dump(cfg, f, indent=1)
    os.replace(CONF + ".tmp", CONF)


def dumbpipe():
    import btip
    exe = btip.find_dumbpipe()
    if not exe: raise Blocked("the iroh transport is missing. Next: btip get-iroh")
    return exe


def ticket(cfg):
    """The permanent address: the endpoint id that belongs to the stored key."""
    out = subprocess.run([dumbpipe(), "generate-ticket"], env={"IROH_SECRET": cfg["secret"], "PATH": os.environ.get("PATH", "")},
                         capture_output=True, text=True, timeout=20)
    m = re.search(r"endpoint[a-z0-9]{40,}", out.stdout + out.stderr)
    if not m: raise Blocked("dumbpipe gave no ticket. Next: run `%s generate-ticket` by hand and read its error" % dumbpipe())
    return m.group(0)


PERMISSION = {0: "not asked yet", 1: "blocked by a profile on this computer", 2: "denied", 3: "allowed"}


def bt_permission():
    """macOS's Bluetooth permission for this app, read without asking: 0 not asked, 1 restricted, 2 denied, 3 allowed."""
    try:
        import objc
        objc.loadBundle("CoreBluetooth", {}, bundle_path="/System/Library/Frameworks/CoreBluetooth.framework")
        return int(objc.lookUpClass("CBManager").authorization())
    except Exception: return None


def mint(name, role=None, only=None, hours=None, mode=None):
    """A fresh token for one far end (a re-mint under the same name replaces the old one). Returns the token.
    only: the device keys this far end may reach (None = every device the owner switched on). hours: the link stops working after this.
    mode: "read" lets this far end look and listen but change nothing (the default for a shared link); "full" lets it act."""
    cfg = load(); tok = secrets.token_urlsafe(24); name = re.sub(r"[^\w .'-]", "_", str(name)).strip()[:40] or "friend"
    cfg["tokens"] = {k: v for k, v in cfg["tokens"].items() if v["name"] != name}
    info = {"name": name, "created": time.strftime("%F %T")}
    if role: info["role"] = role
    if only is not None: info["only"] = sorted({dkey(d) for d in only})
    if hours: info["expires"] = int(time.time() + float(hours) * 3600)
    if mode in ("read", "full"): info["mode"] = mode
    cfg["tokens"][tok] = info; save(cfg)
    with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": "home", "verb": "mint", "args": {"name": name, "role": role or "operator", "mode": info.get("mode", "full")}, "ok": True}) + "\n")
    return tok


def far_link(tk, tok): return PAGE_URL + "#" + urllib.parse.urlencode({"ticket": tk, "t": tok})


# ----------------------------------------------------------------------------- BLE (CoreBluetooth through bleak)
MAKERS = {76: "Apple", 6: "Microsoft", 117: "Samsung", 224: "Google", 89: "Nordic", 301: "Sony", 135: "Garmin", 343: "Xiaomi", 2409: "SwitchBot"}
LOST = re.compile(r"disconnect|not connected|connection (was )?(lost|closed|failed)|peer removed", re.I)        # the link is gone, not the request
FACTS = {"2a00": "Name", "2a29": "Maker", "2a24": "Model", "2a25": "Serial number", "2a26": "Firmware", "2a27": "Hardware", "2a28": "Software", "2a19": "Battery"}


# Never carried, whatever the switch says. Being near one of these is itself the key, so a far relay would defeat it; or it guards a home.
NEVER_WORDS = re.compile(r"\b(locks?|padlock|smartlock|doorlock|deadbolt|garage|key ?fob|car ?key|alarm(?! ?clock)|schlage|kwikset|kevo|nuki|ultraloq|lockly|simplisafe|tesla)\b", re.I)
NEVER_MAKERS = {302: "ASSA ABLOY, a lock maker", 315: "Allegion (Schlage), a lock maker", 465: "August, a lock maker", 555: "Tesla", 1713: "SimpliSafe, an alarm maker",
                2168: "Chamberlain, a garage door maker", 3038: "Yale, a lock maker"}        # Bluetooth SIG company ids, checked 2026-11-06 against NordicSemiconductor/bluetooth-numbers-database
NEVER_SERVICES = {"00000211-b2d1-43f0-9b88-960cebf8b91e": "a Tesla car"}        # teslamotors/vehicle-command, pkg/connector/ble/ble.go


def never(name, adv=None):
    """Why btip never carries this device, or None. By its name, and by maker id or service once the home has heard its advert."""
    m = NEVER_WORDS.search(str(name or "")); adv = adv or {}
    what = "its name says '%s'" % m.group(0).lower() if m else None
    what = what or next(("its maker is %s" % v for k, v in NEVER_MAKERS.items() if str(k) in adv.get("maker_data", {})), None)
    what = what or next(("it is %s" % v for k, v in NEVER_SERVICES.items() if k in [u.lower() for u in adv.get("services", [])]), None)
    return what and "%s. btip never carries a lock, a key, a garage door, a car or an alarm: being near it is what makes it safe. It stays off, and no switch changes that" % what


class Ble:
    def __init__(self):
        self.loop = asyncio.new_event_loop(); threading.Thread(target=self.loop.run_forever, daemon=True).start()
        self.seen, self.clients, self.adv, self.hold = {}, {}, {}, {}

    def run(self, coro, timeout):
        try: return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)
        except ImportError: raise Blocked("BLE needs the bleak package. Next: pip install bleak")
        except asyncio.TimeoutError: raise Blocked("the BLE device did not answer in time. Next: ble_scan to check it is in range, then retry")
        except Blocked: raise
        except Exception as e: raise Blocked("BLE: %s. Next: ble_scan, then retry" % (str(e) or repr(e))[:160])

    async def scan(self, seconds):
        from bleak import BleakScanner
        found = await BleakScanner.discover(timeout=seconds, return_adv=True); rows = []
        for ident, (d, adv) in found.items():
            name = d.name or adv.local_name or ""; self.seen[ident.upper()] = (d, name)
            a = self.adv[ident.upper()] = {"name": adv.local_name or name, "services": list(adv.service_uuids), "maker_data": {str(k): bytes(v).hex() for k, v in adv.manufacturer_data.items()},
                                           "service_data": {k: bytes(v).hex() for k, v in adv.service_data.items()}, "rssi": adv.rssi, "t": time.time()}
            maker = next((MAKERS[k] for k in adv.manufacturer_data if k in MAKERS), None)
            rows.append(dict({"id": ident, "name": name, "maker": maker, "rssi": adv.rssi, "services": list(adv.service_uuids)}, **{f: a[f] for f in ("maker_data", "service_data") if a[f]}))
        for key, (c, _) in self.clients.items():        # a device stops advertising while the home holds a link to it: it is still here
            if getattr(c, "is_connected", False) and not any(r["id"].upper() == key for r in rows):
                a = self.adv.get(key, {})
                rows.append(dict({"id": key, "name": self.seen[key][1], "maker": None, "rssi": a.get("rssi", -99), "services": a.get("services", []), "linked": True},
                                 **{f: a[f] for f in ("maker_data", "service_data") if a.get(f)}))
        for key, a in self.adv.items():        # a weak device is not heard in every listen: one heard in the last 30 s is still listed, with its age
            age = time.time() - a.get("t", 0)
            if 1 < age <= 30 and key in self.seen and not any(r["id"].upper() == key for r in rows):
                rows.append(dict({"id": key, "name": self.seen[key][1], "maker": None, "rssi": a["rssi"], "services": a["services"], "heard_s_ago": round(age)},
                                 **{f: a[f] for f in ("maker_data", "service_data") if a.get(f)}))
        return sorted(rows, key=lambda r: -r["rssi"])

    async def client(self, device):
        from bleak import BleakClient, BleakScanner
        key = None
        for ident, (d, name) in self.seen.items():
            if device.upper() == ident or (name and device == name): key = ident
        if key is None:
            d = await BleakScanner.find_device_by_name(device, timeout=8) or await BleakScanner.find_device_by_address(device, timeout=4)
            if d is None: raise Blocked("no BLE device named '%s' in range. Next: ble_scan and use a name or id from it" % device)
            key = d.address.upper(); self.seen[key] = (d, d.name or "")
        c = self.clients.get(key, (None, 0))[0]
        if c is None or not c.is_connected:
            c = BleakClient(self.seen[key][0], timeout=15)
            try: await c.connect()
            except Exception:        # the device object from an old scan can go stale: find it again by its id, once
                d = await BleakScanner.find_device_by_address(key, timeout=8)
                if d is None: raise
                self.seen[key] = (d, self.seen[key][1] or d.name or ""); c = BleakClient(d, timeout=15); await c.connect()
        self.clients[key] = (c, time.time()); return c, self.seen[key][1], key

    async def again(self, device, op):
        """op(client, name, key) once; if the link turns out to be gone (devices drop it, and bleak can still say
        connected), connect again and run it once more. The answer says when that happened."""
        c, name, key = await self.client(device)
        try: return await op(c, name, key)
        except Exception as e:
            if not LOST.search(str(e) or repr(e)): raise
            self.clients.pop(key, None)
            try: await c.disconnect()
            except Exception: pass
            c, name, key = await self.client(device)
            out = await op(c, name, key); out["reconnected"] = True; return out

    async def reap(self):
        for key, (c, used) in list(self.clients.items()):
            if time.time() - used > 90 and not self.hold.get(key):
                del self.clients[key]
                try: await c.disconnect()
                except Exception: pass

    async def info(self, device):
        """What a person wants to know about a device: its standard readable facts, by name."""
        c, name, key = await self.client(device); out = {"device": name or key, "facts": {}, "private_values": 0, "writable": 0, "locked_values": 0}
        for s_ in c.services:
            for ch in s_.characteristics:
                label = FACTS.get(ch.uuid[4:8]) if ch.uuid.endswith("-0000-1000-8000-00805f9b34fb") else None
                if "write" in ch.properties or "write-without-response" in ch.properties: out["writable"] += 1
                if "read" not in ch.properties: continue
                if not label: out["private_values"] += 1; continue
                try: v = bytes(await asyncio.wait_for(c.read_gatt_char(ch), 5))
                except Exception as e:
                    if re.search("authenti|encrypt|authoriz", str(e), re.I): out["locked_values"] += 1
                    continue
                if label == "Battery": out["facts"][label] = "%d%%" % v[0] if v else None
                elif v and all(32 <= b < 127 for b in v) and len(v) > 1: out["facts"][label] = v.decode()
        return out

    async def services(self, device):
        async def op(c, name, key):
            if key not in self.adv: await self.scan(3)        # the advert is part of the answer: listen for it once
            return {"device": name or key, "id": key, "mtu": getattr(c, "mtu_size", 23), "advert": self.adv.get(key, {"name": name}),
                    "services": [{"uuid": s.uuid, "chars": [{"uuid": ch.uuid, "handle": ch.handle, "can": list(ch.properties)} for ch in s.characteristics]} for s in c.services]}
        return await self.again(device, op)

    async def subscribe(self, device, char, put, every=1.0):
        """Values of one characteristic into `put`, as they change. A value that notifies or indicates is subscribed;
        a value that is only readable is read every `every` s and passed on when it changes (many gadgets keep a live
        reading that they never notify). Returns (the coroutine function that stops it, "notify" or "read")."""
        c, name, key = await self.client(device); ch = c.services.get_characteristic(char)
        if ch is None: raise Blocked("'%s' has no characteristic %s. Next: services to list them" % (name or key, char))
        self.hold[key] = self.hold.get(key, 0) + 1; props = set(ch.properties)
        if props & {"notify", "indicate"}:
            await c.start_notify(ch, lambda _, v: put(bytes(v)))
            async def stop():
                self.hold[key] -= 1
                try: await c.stop_notify(ch)
                except Exception: pass
            return stop, "notify"
        if "read" not in props: self.hold[key] -= 1; raise Blocked("%s on '%s' can be neither read nor subscribed (it can: %s)" % (char, name or key, ", ".join(sorted(props))))
        async def poll():
            last = None
            while True:
                try: v = bytes(await asyncio.wait_for(c.read_gatt_char(ch), 5))
                except asyncio.CancelledError: raise
                except Exception: await asyncio.sleep(every); continue
                if v != last: put(v); last = v
                await asyncio.sleep(every)
        task = asyncio.ensure_future(poll())
        async def stop():
            self.hold[key] -= 1; task.cancel()
        return stop, "read"

    async def read(self, device, char):
        async def op(c, name, key):
            v = bytes(await c.read_gatt_char(char))
            return {"device": name or key, "char": char, "hex": v.hex(), "text": v.decode("utf8") if v and all(32 <= b < 127 for b in v) else None}
        return await self.again(device, op)

    async def write(self, device, char, data, response=None):
        async def op(c, name, key):
            await (c.write_gatt_char(char, bytes.fromhex(data)) if response is None else c.write_gatt_char(char, bytes.fromhex(data), response=bool(response)))
            return {"device": name or key, "char": char, "wrote_bytes": len(data) // 2}
        return await self.again(device, op)

    async def drop(self, device):
        """End the home's link to a device, if it holds one."""
        for key, (c, _) in list(self.clients.items()):
            if device.upper() == key or (self.seen.get(key, (None, ""))[1] and dkey(device) == dkey(self.seen[key][1])):
                if self.hold.get(key): raise Blocked("'%s' is being listened to by a stream right now. Next: close the stream, then retry" % device)
                del self.clients[key]
                try: await c.disconnect()
                except Exception: pass
                return {"device": self.seen.get(key, (None, ""))[1] or key, "linked": False, "was_linked": True}
        return {"device": device, "linked": False, "was_linked": False}

    async def notify(self, device, char, seconds):
        c, name, key = await self.client(device); got = []
        await c.start_notify(char, lambda _, v: got.append({"t": round(time.time(), 3), "hex": bytes(v).hex()}))
        await asyncio.sleep(seconds); await c.stop_notify(char); return {"device": name or key, "char": char, "values": got}


# ----------------------------------------------------------------------------- the home: hands + eyes + BLE
# What a read-only link may do: look and listen. Every verb not named here changes something, so it is refused under a read-only link
# (new verbs are refused until someone puts them here on purpose). `noise` is a read only when no mode is sent.
READ_VERBS = {"devices", "status", "ble_scan", "ble_info", "ble_services", "ble_read", "ble_notify", "ble_drop", "read_screen"}
WRITE_PROPS = {"write", "write-without-response", "authenticated-signed-writes", "reliable-write"}


class Home:
    scope = threading.local()        # per request thread: the devices this far end may reach (None = every device that is on), and its mode
    def __init__(self, cfg, o):
        import bonds
        try: import bt, eyes
        except ImportError:        # installed without the repo's classic/ and eyes/ folders: Bluetooth devices work, a screen device does not
            if o.device: raise Blocked("a screen device needs the repo checkout (its classic/ and eyes/ folders). Next: run btip from a clone, or start without --device")
            bt = eyes = None
        self.bt, self.eyes, self.bonds, self.cfg, self.o = bt, eyes, bonds, cfg, o
        self.dev = o.device; self.ble = Ble(); self.lock = threading.RLock(); self.t0 = time.time(); self.procs = []
        self.small = (None, b""); self._screen_key = None; self._screen_t = 0.0; self._lift = None

    @property
    def screen_key(self):
        """The screen device's key: its paired name. Bluetooth may not answer in the first seconds after start, so an
        unresolved key (the raw address) is looked up again, at most every 5 s, until the name comes."""
        if not self.dev: return None
        if self._screen_key is None or self._screen_key == dkey(self.dev):
            if time.time() - self._screen_t > 5.0:
                self._screen_t = time.time(); addr = self.dev.split(":", 1)[-1].lower().replace(":", "-")
                try: self._screen_key = next((dkey(b["name"]) for b in self.paired() if b["addr"] == addr), dkey(self.dev))
                except Exception: self._screen_key = self._screen_key or dkey(self.dev)
            elif self._screen_key is None: self._screen_key = dkey(self.dev)
        return self._screen_key

    @screen_key.setter
    def screen_key(self, v): self._screen_key = v; self._screen_t = time.time()

    # ---- helpers
    def paired(self, wait=3.0):
        """The computer's pairing list, or [] when it can't be read in `wait` s (no radio, or macOS still asking for permission)."""
        if bt_permission() not in (3, None): return []
        box = []
        def read():
            try: box.append(self.bonds.paired())
            except Exception: box.append([])        # not macOS, or the pairing list could not be read: the scan still works
        t = threading.Thread(target=read, daemon=True); t.start(); t.join(wait)
        return box[0] if box else []

    def key_of(self, device):
        d = str(device)
        for ident, (_, name) in self.ble.seen.items():
            if d.upper() == ident: return dkey(name) if name else d.lower()
        return dkey(d)

    def never_why(self, device):
        d = str(device); adv = None
        for ident, (_, name) in self.ble.seen.items():
            if d.upper() == ident or (name and dkey(name) == dkey(d)): adv = getattr(self.ble, "adv", {}).get(ident); d = name or d; break
        return never(d, adv)

    def need(self, device):
        """Far ends reach only devices the owner switched on, and never a lock, a key, a car or an alarm."""
        k = self.key_of(device); why = self.never_why(device)
        if why: raise Blocked("'%s' is refused: %s" % (k, why))
        if k not in load().get("approved", {}):
            raise Blocked("'%s' is switched off for far ends. Its owner turns it on at home: btip home approve '%s' (or the switch on the owner's page)" % (k, k))
        only = getattr(self.scope, "only", None)
        if only is not None and k not in only:
            raise Blocked("'%s' is not shared with you. Its owner can add it to your link on their page (People)" % k)
        return k

    def read_only(self): return getattr(self.scope, "mode", None) == "read"

    def may_change(self, verb, args):
        """A read-only link looks and listens; it changes nothing. Checked before any verb runs, with the owner's next step."""
        if not self.read_only() or verb in READ_VERBS or (verb == "noise" and not args.get("mode")): return
        raise Blocked("your link is read-only, so '%s' is refused. Its owner can give you full access on their page (People), or you can read: %s" % (verb, ", ".join(sorted(READ_VERBS))))

    def known(self):
        try: return json.load(open(KNOWN))
        except Exception: return {}

    def learn(self, k, **facts):
        kn = self.known(); kn[k] = dict(kn.get(k, {}), t=time.strftime("%F %T"), **facts)
        with open(KNOWN + ".tmp", "w") as f: json.dump(kn, f, indent=1)
        os.replace(KNOWN + ".tmp", KNOWN)

    def pair_verb(self, fn, device, *a):
        self.need(device)
        try: return fn(device, *a)
        except self.bonds.Blocked as e: raise Blocked(str(e))

    def hands(self, fn, *a):
        if not self.dev: raise Blocked("this home has no screen device. At home, restart with: btip home serve --device bt:AA-BB-CC-DD-EE-FF")
        self.need(self.screen_key)
        try: return fn(self.dev, *a)
        except self.bt.Blocked as e: raise Blocked(str(e))

    def meta(self):
        try: m = self.eyes.see()
        except Exception: return None
        return m if m["t_recv"] >= self.t0 else None       # a frame from before this start says nothing about now

    def frame_or_block(self):
        m = self.meta()
        if not m: raise Blocked("no frames from the device yet. Next: call wake (it links Bluetooth and starts screen mirroring)")
        return m

    def live(self):
        """Is mirroring running? A still screen sends no frames, so move the pointer and look for a new frame."""
        m = self.meta()
        if not m: return False
        self.hands(self.bt.move, 0.5, 0.5); self.hands(self.bt.move, 0.53, 0.5)
        return self.eyes.wait_change(m["seq"], 2.5) is not None

    def mirror_start(self):
        e = self.eyes; m = self.meta(); seq0 = m["seq"] if m else 0; t0 = time.time()
        for _ in range(2): self.hands(self.bt.media, "home"); time.sleep(1.0)     # known start: Home Screen
        for (x, y), pause in ((e.CC_OPEN, 1.2), (e.CC_MIRROR_TILE, 1.5), (e.CC_FIRST_RECEIVER, 0.1)):
            self.hands(self.bt.tap, x, y, HOLD); time.sleep(pause)
        got = e.wait_change(seq0, 20.0, after_t=t0 + 4.0)
        if got:
            time.sleep(1.0)
            for _ in range(2): self.hands(self.bt.media, "home"); time.sleep(1.0)
        return {"mirroring": got is not None, "first_frame_s": round(got["t_recv"] - t0, 1) if got else None}

    def texts(self):
        path, m = self.eyes.snapshot(); o = self.eyes.ocr(path); W, H = o["width"], o["height"]
        try: os.unlink(path)
        except OSError: pass
        return m, [{"text": t["text"], "x": round(t["cx"] / W, 4), "y": round(t["cy"] / H, 4)} for t in o["texts"]]

    def find(self, text):
        f = self.eyes.find(text)
        try: os.unlink(f["snap"])
        except OSError: pass
        return f

    def jpeg(self, w):
        m = self.frame_or_block()
        if self.small[0] == (m["seq"], w): return m, self.small[1]
        raw = open(self.eyes.LATEST, "rb").read()
        if w and w < m["width"]:
            try:
                from PIL import Image
                im = Image.open(io.BytesIO(raw)); im = im.resize((w, round(im.height * w / im.width))); b = io.BytesIO(); im.save(b, "JPEG", quality=60); raw = b.getvalue()
            except ImportError: pass
        self.small = ((m["seq"], w), raw); return m, raw

    # ---- verbs (the far side calls these by name)
    def status(self):
        """What this home has and how it is now: Bluetooth link, mirroring, frame age, BLE mode. Costs nothing; call it first."""
        st = self.bt.status() if self.dev else {}; m = self.meta()
        return {"home": self.o.name, "device": self.dev, "link": bool(st.get("link")), "frames": bool(m),
                "frame_age_s": round(m["age_s"], 1) if m else None, "frame": [m["width"], m["height"]] if m else None,
                "ble": self.o.ble, "approved": sorted(load().get("approved", {})), "up_s": int(time.time() - self.t0),
                "bluetooth_permission": PERMISSION.get(bt_permission(), "unknown"),
                "note": "frames arrive only when the screen changes, so age grows on a still screen. link=false or frames=false: call wake"}

    def wake(self):
        """Make the device ready with no person there: link Bluetooth (2 to 14 s), then start screen mirroring if it is off (about 7 to 18 s). Safe to call any time."""
        self.hands(self.bt.connect); out = {"link": True}
        if not self.live(): out.update(self.mirror_start())
        else: out["mirroring"] = True
        if not out["mirroring"]: raise Blocked("Bluetooth is linked but mirroring did not start. The device may be locked with a passcode, or 'iPad Eyes' is not the first receiver in its list. Next: a person unlocks it once, then call wake")
        return out

    def rest(self):
        """Drop the Bluetooth link so the device shows its own keyboard again. Mirroring stays as it is."""
        self.hands(self.bt.disconnect); return {"link": False}

    def read_screen(self, text=None, wait_s=0):
        """Read the text on the device screen now (OCR, runs at home). With text: matches with x,y fractions; wait_s keeps looking that long. Without: every text block."""
        self.frame_or_block(); end = time.time() + float(wait_s)
        while True:
            if not text:
                m, tx = self.texts(); return {"frame_age_s": m["age_s"], "texts": tx}
            f = self.find(text); hits = [h for h in f["hits"] if h["score"] >= 0.75]
            if hits or time.time() >= end: return {"frame_age_s": f["frame_age_s"], "found": bool(hits), "hits": [{k: h[k] for k in ("text", "x", "y", "score")} for h in hits[:5]]}
            time.sleep(0.3)

    def tap(self, x, y, hold_s=HOLD):
        """Tap at x,y (fractions of the screen, 0..1 from the left and top). hold_s 0.8 is a long press."""
        self.hands(self.bt.tap, x, y, max(float(hold_s), HOLD)); return {"x": x, "y": y}

    def tap_text(self, text, expect=None, dy_pt=0, timeout_s=6):
        """Find text on the live screen, tap it, and confirm that `expect` shows afterwards. All of it runs at home. Home Screen icons: dy_pt -45 (the label sits under the icon)."""
        self.frame_or_block(); end = time.time() + 2.5
        while True:        # the screen may still be moving from the last action: look for up to 2.5 s
            f = self.find(text)
            if (f["hits"] and f["hits"][0]["score"] >= 0.75) or time.time() > end: break
            time.sleep(0.25)
        if not f["hits"] or f["hits"][0]["score"] < 0.75:
            m, tx = self.texts(); raise Blocked("'%s' is not on the screen. On it now: %s. Next: read_screen, or key home" % (text, ", ".join(t["text"] for t in tx[:12])))
        h = f["hits"][0]; x, y = h["x"], min(1.0, max(0.0, h["y"] + float(dy_pt) / self.o.points_h)); seq0 = self.meta()["seq"]
        self.hands(self.bt.tap, x, y, HOLD); out = {"tapped": h["text"], "x": x, "y": round(y, 4)}
        if expect:
            c, secs = self.eyes.confirm(expect, seq0, float(timeout_s)); out.update(confirmed=c is not None, confirm_s=round(secs, 2) if secs else None)
            if c:
                try: os.unlink(c["snap"])
                except OSError: pass
        return out

    def type(self, text):
        """Type text into whatever has focus on the device. Passcodes, one-time codes and card numbers are refused: a person types those."""
        return self.hands(self.bt.type_text, text)

    def key(self, keys):
        """Press keys, in order. Combos like cmd+space, enter, escape, cmd+tab, backspace; device keys: home, search, volup, voldown, mute, play, next, prev."""
        done = []
        for k in keys if isinstance(keys, list) else str(keys).split():
            if k in self.bt.MEDIA: self.hands(self.bt.media, k)
            else: self.hands(self.bt.key, k)
            done.append(k)
        return {"pressed": done}

    def touch(self, events):
        """A finger path as it happened: events [{p: down|move|up, x, y, t}], x and y fractions of the screen, t in ms from the first event.
        The home replays it on the pointer at once with the gaps as sent (each at most 60 ms, a call at most 1.5 s); a move keeps the finger down.
        Send one call per round trip while the finger moves, and end with up. A finger left down is lifted by the home after 1.5 s."""
        out = self.hands(self.bt.touch, events)
        last = events[-1] if events else {}
        if self._lift: self._lift.cancel(); self._lift = None
        if last.get("p") != "up":
            x, y = last.get("x", 0.5), last.get("y", 0.5)
            def lift():
                try:
                    with self.lock: self.hands(self.bt.touch, [{"p": "up", "x": x, "y": y, "t": 0}])
                except Exception: pass
            self._lift = threading.Timer(1.5, lift); self._lift.daemon = True; self._lift.start()
        return out

    def scroll(self, dy, dx=0):
        """Scroll by wheel notches. Negative dy moves the content up (reads further down). 5 notches is about 60 pt, 10 about 430 pt."""
        self.hands(self.bt.scroll, int(dy), int(dx)); return {"dy": dy, "dx": dx}

    def drag(self, x1, y1, x2, y2):
        """Press at x1,y1, move to x2,y2, release (fractions). Swipes, sliders, reordering."""
        self.hands(self.bt.drag, x1, y1, x2, y2); return {}

    def devices(self, seconds=4):
        """Every Bluetooth device near this home or paired with its computer: state in plain words, what can be done with it, and whether its owner switched it on. Call this first. seconds=0 skips the radio scan."""
        rows, unnamed = {}, 0
        def row(name): return rows.setdefault(dkey(name), {"key": dkey(name), "name": name, "paired": False, "near": False})
        for b in self.paired():
            r = row(b["name"]); r["paired"] = True; r["connected"] = bool(r.get("connected") or b["connected"])
            if b["kind"]: r["kind"] = b["kind"]
            if b["battery"]: r["battery"] = b["battery"]
            for f in ("audio_out", "mic", "noise_control"): r[f] = bool(r.get(f) or b[f])
        perm = bt_permission()
        if self.o.ble != "off" and float(seconds) > 0 and perm in (3, None):
            for d in self.ble.run(self.ble.scan(float(seconds)), float(seconds) + 15):
                if not d["name"]: unnamed += 1; continue
                r = row(d["name"]); r["near"] = True; r["rssi"] = max(d["rssi"], r.get("rssi", -200)); r["ble_id"] = d["id"]
                if d["maker"]: r["maker"] = d["maker"]
        ap, kn = load().get("approved", {}), self.known(); only = getattr(self.scope, "only", None); far = getattr(self.scope, "far", False)
        for k, v in ap.items():        # a device that is on stays in the list when it is out of range
            if k not in rows: rows[k] = {"key": k, "name": v.get("name", k), "paired": False, "near": False}
        for k in (only or []):        # a device shared with this far end is in its list even when its switch is off or it is out of range
            if k not in rows: rows[k] = {"key": k, "name": k, "paired": False, "near": False}
        for k, r in rows.items():
            r["approved"] = k in ap and (only is None or k in only); r["screen"] = k == self.screen_key; r["state"], r["can"] = self.words(r, kn.get(k, {}))
            why = self.never_why(r.get("ble_id") or r["name"]) or never(r["name"])
            if why: r["approved"] = False; r["never"] = True; r["state"] = "Never shared: " + why.split(". ")[0]; r["can"] = ["nothing: btip does not carry this kind of device"]
            if kn.get(k, {}).get("facts"): r["facts"] = kn[k]["facts"]
            if far and self.read_only(): r["can"] = [c for c in r["can"] if c.startswith(("read", "see", "listen"))] or ["read its values"]; r["access"] = "read-only"
        if far: rows = {k: r for k, r in rows.items() if (k in only if only is not None else k in ap)}        # a far end sees the devices it was given, and nothing else
        order = sorted(rows.values(), key=lambda r: (not r["approved"], not r["screen"], not r["paired"], -r.get("rssi", -200)))
        out = {"devices": order, "unnamed_near": unnamed if not far else 0, "bluetooth_permission": PERMISSION.get(perm, "unknown")}
        if far: out["access"] = "read-only" if self.read_only() else "full"
        return out

    def words(self, r, kn):
        """A device's state and uses, in words a person reads. Only uses that have a verb here are listed."""
        st, can = [], []
        if r["paired"]: st.append("Paired with the home computer" + (", connected now" if r.get("connected") else ""))
        g = kn.get("gatt")
        if g == "open": st.append("Answers without pairing")
        elif g == "private": st.append("Connects without pairing and speaks its maker's own format")
        elif g == "silent": st.append("Did not accept a connection on the last try")
        elif r["near"] and not r["paired"]: st.append("In range, not tried yet")
        if kn.get("locked_values"): st.append("%d of its values need pairing at home" % kn["locked_values"])
        if r["screen"]: can += ["see its screen", "tap and type on it"]
        if r.get("audio_out"): can.append("speak or play sound through it")
        if r.get("mic"): can.append("listen through its microphone")
        if r.get("noise_control"): can.append("set its noise control")
        if r["near"]: can.append("read its values")
        if kn.get("writable"): can.append("write %d of its values" % kn["writable"])
        if not can: can.append("nothing yet: no verb here speaks to this kind of device")
        return ". ".join(st), can

    def connect(self, device):
        """Connect the home computer to a device it is already paired with (headphones, a speaker, a keyboard). No new pairing is needed."""
        return self.pair_verb(self.bonds.connect, device)

    def disconnect(self, device):
        """Drop the home computer's connection to a paired device, so its owner's other devices can take it."""
        return self.pair_verb(self.bonds.disconnect, device)

    def noise(self, device, mode=None):
        """Read or set noise control on paired headphones: off, cancel, transparency, adaptive. Without mode: read it."""
        return self.pair_verb(self.bonds.noise, device, mode)

    def speak(self, device, text):
        """Say text out loud through a paired speaker or headphones at home (text to speech runs at home). The home computer's own speakers do not play it."""
        return self.pair_verb(self.bonds.speak, device, text)

    def play(self, device, audio_b64):
        """Play a sound file (base64; any format ffmpeg reads, 2 MB at most) through a paired speaker or headphones at home."""
        raw = base64.b64decode(audio_b64)
        if len(raw) > 2 << 20: raise Blocked("the sound is over 2 MB. Next: send a shorter clip")
        path = os.path.join(CACHE, "play_%d" % os.getpid())
        with open(path, "wb") as f: f.write(raw)
        try: return self.pair_verb(self.bonds.play, device, path)
        finally: os.unlink(path)

    def listen(self, device, seconds=5):
        """Record the microphone of a paired headset at home for some seconds (30 at most) and return the sound as base64 AAC."""
        path = os.path.join(CACHE, "listen_%d.m4a" % os.getpid())
        try:
            out = self.pair_verb(self.bonds.listen, device, seconds, path)
            out.update(mime="audio/mp4", audio_b64=base64.b64encode(open(path, "rb").read()).decode()); return out
        finally:
            if os.path.exists(path): os.unlink(path)

    def ble_scan(self, seconds=6):
        """List Bluetooth LE devices in range of this home: id, name, signal, advertised services. A far end is shown only the devices it may reach."""
        self.ble_on(); rows = self.ble.run(self.ble.scan(float(seconds)), float(seconds) + 15)
        if getattr(self.scope, "far", False):        # the owner's other devices are not the far end's to see, not even by name
            only = getattr(self.scope, "only", None); allowed = set(only) if only is not None else set(load().get("approved", {}))
            rows = [r for r in rows if (dkey(r["name"]) if r["name"] else r["id"].lower()) in allowed]
        return {"devices": rows}

    def ble_info(self, device):
        """Connect to a BLE device (name or id from ble_scan) and return its standard facts in plain words: maker, model, serial number, firmware, battery. Also counts its private values."""
        k = self.need(device); self.ble_on()
        try: out = self.ble.run(self.ble.info(device), 60)
        except Blocked as e:
            self.learn(k, gatt="silent", last_error=str(e)[:120]); raise
        self.learn(k, gatt="open" if out["facts"] or not out["private_values"] else "private", **{f: out[f] for f in ("facts", "private_values", "writable", "locked_values")})
        if self.read_only(): out["access"] = "read-only"
        return out

    def ble_services(self, device):
        """Connect to a BLE device (name or id from ble_scan; about 5 s the first time) and list its services and characteristics (uuid, handle, what each can do), plus what it advertises. A handle (a number) works wherever a characteristic uuid does."""
        self.need(device); self.ble_on(); out = self.ble.run(self.ble.services(device), 45)
        if self.read_only():        # the table you get describes your grant: a read-only link sees a device with nothing to write to
            for s_ in out["services"]:
                for ch in s_["chars"]: ch["can"] = [c for c in ch["can"] if c not in WRITE_PROPS]
            out["access"] = "read-only"
        return out

    def ble_read(self, device, char):
        """Read one characteristic (uuid) of a BLE device. Returns hex, and text when it is printable."""
        self.need(device); self.ble_on(); return self.ble.run(self.ble.read(device, char), 45)

    def ble_write(self, device, char, hex, response=None):
        """Write hex bytes to a characteristic of a BLE device the owner switched on. response: true waits for the device's answer, false does not; leave it out and the home picks what the characteristic supports."""
        self.need(device); self.ble_on(); return self.ble.run(self.ble.write(device, char, hex, response), 45)

    def ble_drop(self, device):
        """End the home's link to a BLE device. Many gadgets take one link at a time and stop advertising while linked, so call this when you are done and the owner's phone can reach it again. The home also drops a link after 90 s without use."""
        self.need(device); return self.ble.run(self.ble.drop(device), 20)

    def ble_notify(self, device, char, seconds=5):
        """Listen to a notifying characteristic for some seconds and return the values that arrived."""
        self.need(device); self.ble_on(); return self.ble.run(self.ble.notify(device, char, float(seconds)), float(seconds) + 40)

    def ble_on(self):
        if self.o.ble == "off": raise Blocked("BLE is off at this home. At home, restart with: btip home serve --ble read")
        self.ble.run(self.ble.reap(), 10)

    VERBS = ["devices", "connect", "disconnect", "noise", "speak", "play", "listen", "status", "wake", "rest", "read_screen", "tap", "tap_text", "type", "key", "scroll", "drag", "touch",
             "ble_scan", "ble_info", "ble_services", "ble_read", "ble_write", "ble_notify", "ble_drop"]

    def describe(self):
        import inspect; out = []
        for v in self.VERBS:
            fn = getattr(self, v); props, req = {}, []
            for p in inspect.signature(fn).parameters.values():
                kind = "number" if isinstance(p.default, (int, float)) or p.name in ("x", "y", "x1", "y1", "x2", "y2", "dy") else "string"
                props[p.name] = {"type": ["string", "array"] if p.name == "keys" else "array" if p.name == "events" else "boolean" if p.name == "response" else kind}
                if p.default is inspect.Parameter.empty: req.append(p.name)
            out.append({"name": v, "description": fn.__doc__, "inputSchema": {"type": "object", "properties": props, "required": req}})
        out.append({"name": "see", "description": "The device screen now, as an image (GET /v1/frame.jpg?w=600), with its age. Prefer read_screen and tap_text: they cost less and run at home.",
                    "inputSchema": {"type": "object", "properties": {"w": {"type": "number"}}, "required": []}})
        return out

    def call(self, who, verb, args):
        if verb not in self.VERBS: raise Blocked("no verb '%s'. Verbs: %s, see" % (verb, " ".join(self.VERBS)))
        t = time.time(); rec = {"t": time.strftime("%F %T"), "who": who, "verb": verb, "args": {k: (v if len(str(v)) < 80 else str(v)[:40] + "... (%d chars)" % len(str(v))) for k, v in args.items()}}
        try:
            self.may_change(verb, args if isinstance(args, dict) else {})
            with self.lock: out = getattr(self, verb)(**args)
            rec["ok"] = True; return out
        except TypeError as e: rec["ok"] = False; rec["err"] = str(e); raise Blocked("bad arguments for %s: %s. Next: GET /v1/verbs for the schema" % (verb, e))
        except Blocked as e: rec["ok"] = False; rec["err"] = str(e); raise
        finally:
            rec["s"] = round(time.time() - t, 2)
            with open(LOG, "a") as f: f.write(json.dumps(rec) + "\n")


def touched(home, device=None, limit=30):
    """Who did what, from the home log: the last `limit` calls by far ends, newest first, for one device or for all.
    Each line: when, who, what they did in plain words, and whether it went through. The owner's page shows it under a device."""
    k = dkey(device) if device else None; rows = []; readers = {}
    try: lines = open(LOG).read().splitlines()
    except OSError: lines = []
    for line in reversed(lines):
        try: r = json.loads(line)
        except ValueError: continue
        if r.get("who") in ("home", "migration") or r.get("verb") in ("status", "mint", "approve", "unapprove", "share", "pause", "resume", "revoke", "devices", "ble_scan"): continue
        d = r.get("args", {}).get("device"); dk = home.key_of(d) if d else (home.screen_key if r.get("verb") in ("wake", "rest", "read_screen", "tap", "tap_text", "type", "key", "scroll", "drag") else None)
        if k and dk != k: continue
        if len(rows) < limit:
            rows.append({"t": r["t"], "who": r["who"], "did": r["verb"].replace("ble_", "").replace("_", " "), "device": dk, "ok": bool(r.get("ok")),
                         "change": r["verb"] not in READ_VERBS and not (r["verb"] == "noise" and not r.get("args", {}).get("mode")), "why": (r.get("err") or "").split(". ")[0] or None})
        who = readers.setdefault(r["who"], {"who": r["who"], "calls": 0, "changes": 0, "refused": 0, "last": r["t"]}); who["calls"] += 1
        if not r.get("ok"): who["refused"] += 1
        if r["verb"] not in READ_VERBS: who["changes"] += 1
    return {"device": k, "recent": rows, "people": sorted(readers.values(), key=lambda p: p["last"], reverse=True)}


# ----------------------------------------------------------------------------- HTTP: one port for a browser, a CLI and MCP
PAGE = open(os.path.join(HERE, "home.html"), "rb").read() if os.path.exists(os.path.join(HERE, "home.html")) else b"<h1>btip home</h1>"


def handler(home):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def who(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query); tok = (q.get("t") or [""])[0]; self.owner = False
            a = self.headers.get("Authorization", "")
            if a.startswith("Bearer "): tok = a[7:]
            m = re.search(r"(?:^|;\s*)btip=([^;]+)", self.headers.get("Cookie", ""))
            from_cookie = not tok and bool(m)
            if from_cookie: tok = m.group(1)
            # A cookie rides along on any request the browser makes, so another page could use it. On localhost the
            # port is not a site boundary (127.0.0.1:A and :B are "same site"), so SameSite would not stop a page on
            # another local port. The browser still marks such a request cross-origin: a cookie-only call is honoured
            # only when it is same-origin (the home's own page) or has no browser mark (a tool, which sends its own token).
            sfs = self.headers.get("Sec-Fetch-Site", "")
            if from_cookie and sfs not in ("", "same-origin", "none"):
                self.why = "a page from somewhere else tried to use this home with your sign-in, and was refused. Open the home's own page to act on it."; return None, None
            cfg = load(); self.why = None
            for known, info in cfg["tokens"].items():       # read each time: a revoke, a pause or an expiry applies at once
                if tok and hmac.compare_digest(tok, known):
                    self.owner = info.get("role") == "owner"
                    if not self.owner and info.get("expires") and time.time() > info["expires"]:
                        self.why = "this link expired on %s. Next: ask the owner for a new link" % time.strftime("%Y-%m-%d %H:%M", time.localtime(info["expires"])); return None, None
                    if not self.owner and cfg.get("paused"):
                        self.why = "the owner paused all links for now. Next: ask them to resume"; return None, None
                    home.scope.only = None if self.owner else info.get("only"); home.scope.far = not self.owner
                    home.scope.mode = None if self.owner else info.get("mode"); home.scope.until = info.get("expires")
                    return info["name"], tok
            return None, None

        def status(self, who):
            """The home's state plus who is asking: the owner sees the pause switch; a far end sees its access and what is shared with it."""
            st = dict(home.call(who, "status", {}), ok=True, owner=self.owner, paused=bool(load().get("paused")) if self.owner else None, who=who)
            if not self.owner: st["access"] = "read-only" if home.read_only() else "full"; st["shared"] = getattr(home.scope, "only", None); st["until"] = getattr(home.scope, "until", None)
            return st

        def send(self, code, body, ctype="application/json", extra=()):
            if not isinstance(body, bytes): body = json.dumps(body).encode()
            self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in extra: self.send_header(k, v)
            self.end_headers(); self.wfile.write(body)

        def do_GET(self):
            u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query); who, tok = self.who()
            if not who: return self.send(401, {"ok": False, "error": self.why or "this link is not known to the home (it was removed, or never made). Next: ask the owner for a new link"})
            try:
                if u.path == "/":
                    if "t" in q: return self.send(302, b"", extra=(("Location", "/"), ("Set-Cookie", "btip=%s; HttpOnly; SameSite=Lax; Path=/" % tok)))
                    return self.send(200, PAGE, "text/html; charset=utf-8")
                if u.path == "/v1/verbs": return self.send(200, {"ok": True, "verbs": home.describe()})
                if u.path == "/v1/status": return self.send(200, self.status(who))
                w = int((q.get("w") or ["0"])[0])
                if u.path == "/v1/frame.jpg":
                    m, raw = home.jpeg(w); return self.send(200, raw, "image/jpeg", (("X-Frame-Age", "%.2f" % (time.time() - m["t_recv"])), ("X-Frame-Seq", str(m["seq"]))))
                if u.path == "/v1/stream": return self.stream(w or 600, float((q.get("fps") or ["10"])[0]))
                if u.path == "/v1/h264": return self.h264()
                if u.path == "/v1/ble_stream": return self.ble_stream(who, (q.get("device") or [""])[0], (q.get("char") or [""])[0])
                self.send(404, {"ok": False, "error": "no such path. Next: GET /v1/verbs"})
            except Blocked as e: self.send(409, {"ok": False, "error": str(e)})
            except (BrokenPipeError, ConnectionResetError): pass

        def stream(self, w, fps):
            """Webcam-style MJPEG: any browser shows it in an <img>. A frame goes out when the screen changes, and every 2 s as a keepalive."""
            self.send_response(200); self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=f"); self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close"); self.end_headers(); last, sent = None, 0.0; self.close_connection = True; nudged = time.time()
            while True:
                if time.time() - nudged > 45 and not home.read_only():        # someone is watching: a Shift press now and then keeps the tablet from auto-locking (it types nothing). A read-only link presses nothing
                    nudged = time.time()
                    try:
                        with home.lock: home.hands(home.bt.key, "shift")
                    except Exception: pass
                try: m, raw = home.jpeg(w)
                except Blocked: time.sleep(1.0); continue
                if m["seq"] != last or time.time() - sent > 2.0:
                    self.wfile.write(b"--f\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n" % len(raw) + raw + b"\r\n"); self.wfile.flush(); last, sent = m["seq"], time.time()
                time.sleep(1.0 / fps)

        def h264(self):
            """The screen as H.264 video from the receiver's hardware encoder: a new viewer gets the group since the last keyframe first, then each
            access unit as it is encoded. Framing per unit: 4-byte length, 1 flag byte (bit 0 = key), 8-byte receive time, bytes. A zero-length unit every 2 s is a keepalive."""
            import socket
            path = getattr(home.eyes, "H264_SOCK", None); c = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try: c.connect(path)
            except OSError: c.close(); raise Blocked("no video yet: the screen receiver is not running or nothing is mirroring. Next: call wake")
            self.send_response(200); self.send_header("Content-Type", "application/octet-stream"); self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close"); self.end_headers(); self.close_connection = True; nudged = time.time()
            try:
                while True:
                    if time.time() - nudged > 45 and not home.read_only():
                        nudged = time.time()
                        try:
                            with home.lock: home.hands(home.bt.key, "shift")
                        except Exception: pass
                    b = c.recv(1 << 16)
                    if not b: break
                    self.wfile.write(b); self.wfile.flush()
            finally: c.close()

        def ble_stream(self, who, device, char):
            """One characteristic's values as they change: one JSON line each, an empty object every 5 s as a keepalive.
            The first line says how: "notify" (the device sends them) or "read" (the home reads it each second)."""
            char = int(char) if char.isdigit() else char; home.need(device); home.ble_on(); q_ = queue.Queue()
            with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": who, "verb": "ble_stream", "args": {"device": device, "char": char}, "ok": True}) + "\n")
            try: stop, via = home.ble.run(home.ble.subscribe(device, char, q_.put), 45)
            except Blocked as e: return self.send(409, {"ok": False, "error": str(e)})
            self.send_response(200); self.send_header("Content-Type", "application/x-ndjson"); self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close"); self.end_headers(); self.close_connection = True
            try:
                self.wfile.write(json.dumps({"subscribed": True, "via": via}).encode() + b"\n"); self.wfile.flush()
                while True:
                    try: line = json.dumps({"t": round(time.time(), 3), "hex": q_.get(timeout=5).hex()})
                    except queue.Empty: line = "{}"
                    self.wfile.write(line.encode() + b"\n"); self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError): pass
            finally: home.ble.run(stop(), 10)

        def do_POST(self):
            who, _ = self.who(); n = int(self.headers.get("Content-Length", 0)); body = self.rfile.read(n) if n else b""
            if not who: return self.send(401, {"ok": False, "error": self.why or "this link is not known to the home (it was removed, or never made). Next: ask the owner for a new link"})
            m = re.fullmatch(r"/v1/(\w+)", urllib.parse.urlparse(self.path).path)
            if not m: return self.send(404, {"ok": False, "error": "POST /v1/<verb>. Next: GET /v1/verbs"})
            if m.group(1) in ("approve", "invite", "people", "revoke", "share", "pause", "touched"):        # the owner's controls are not verbs: only a far end the home marked as owner may use them
                if not self.owner: return self.send(403, {"ok": False, "error": "only the owner can switch devices and invite people. At home: btip home approve NAME, or btip home owner %s to give this far end the owner's controls" % who})
                a = json.loads(body or b"{}")
                if m.group(1) == "approve":
                    why = a.get("on", True) and home.never_why(a["device"])
                    if why: return self.send(409, {"ok": False, "error": "'%s' is refused: %s" % (a["device"], why)})
                    try: return self.send(200, dict(switch(a["device"], a.get("on", True), who, home), ok=True))
                    except Blocked as e: return self.send(409, {"ok": False, "error": str(e)})
                if m.group(1) == "invite":
                    name = a.get("name") or "friend"; tok = mint(name, only=a.get("devices"), hours=a.get("hours"), mode=a.get("mode") or "read")
                    return self.send(200, {"ok": True, "name": load()["tokens"][tok]["name"], "link": far_link(home.tk, tok),
                                           "note": "Anyone with this link can use the devices you switch on, until you remove them. Send it only to the person you mean."})
                if m.group(1) == "share":        # change what one far end reaches: devices (null = every device that is on) and hours (null = until removed), each only when sent
                    cfg = load(); hit = [v for v in cfg["tokens"].values() if v["name"] == a.get("name") and v.get("role") != "owner"]
                    for v in hit:
                        if "devices" in a:
                            if a["devices"] is None: v.pop("only", None)
                            else: v["only"] = sorted({dkey(d) for d in a["devices"]})
                        if "hours" in a:
                            if a["hours"]: v["expires"] = int(time.time() + float(a["hours"]) * 3600)
                            else: v.pop("expires", None)
                        if a.get("mode") in ("read", "full"): v["mode"] = a["mode"]
                    save(cfg)
                    with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": who, "verb": "share", "args": {k: a[k] for k in ("name", "devices", "hours", "mode") if k in a}, "ok": bool(hit)}) + "\n")
                    return self.send(200, {"ok": bool(hit), "error": None if hit else "no far end named '%s'" % a.get("name")})
                if m.group(1) == "pause":
                    cfg = load(); cfg["paused"] = bool(a.get("on", True)); save(cfg)
                    with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": who, "verb": "pause" if cfg["paused"] else "resume", "args": {}, "ok": True}) + "\n")
                    return self.send(200, {"ok": True, "paused": cfg["paused"]})
                if m.group(1) == "revoke":
                    cfg = load(); n = len(cfg["tokens"]); cfg["tokens"] = {k: v for k, v in cfg["tokens"].items() if v["name"] != a.get("name") or v.get("role") == "owner"}; save(cfg)
                    with open(LOG, "a") as f: f.write(json.dumps({"t": time.strftime("%F %T"), "who": who, "verb": "revoke", "args": {"name": a.get("name")}, "ok": len(cfg["tokens"]) < n}) + "\n")
                    return self.send(200, {"ok": len(cfg["tokens"]) < n, "error": None if len(cfg["tokens"]) < n else "no far end named '%s'" % a.get("name")})
                if m.group(1) == "touched": return self.send(200, dict(touched(home, a.get("device"), int(a.get("limit") or 30)), ok=True))
                last = {}
                try:
                    for line in open(LOG):
                        try: r = json.loads(line)
                        except ValueError: continue
                        last[r.get("who")] = r.get("t")
                except OSError: pass
                cfg = load()
                return self.send(200, {"ok": True, "paused": bool(cfg.get("paused")), "people": [{"name": v["name"], "owner": v.get("role") == "owner", "since": v["created"], "last_call": last.get(v["name"]), "devices": v.get("only"),
                                        "mode": v.get("mode", "full"), "expires": time.strftime("%Y-%m-%d %H:%M", time.localtime(v["expires"])) if v.get("expires") else None, "expires_t": v.get("expires"), "expired": bool(v.get("expires") and time.time() > v["expires"])} for v in cfg["tokens"].values()]})
            try: self.send(200, self.status(who) if m.group(1) == "status" else dict(home.call(who, m.group(1), json.loads(body or b"{}")) or {}, ok=True))
            except Blocked as e: self.send(409, {"ok": False, "error": str(e)})
            except ValueError: self.send(400, {"ok": False, "error": "the body must be a JSON object of arguments"})
            except Exception as e: self.send(500, {"ok": False, "error": "%r. Next: read %s at home" % (e, LOG)})

        def log_message(self, *a): pass
    return H


def serve(o):
    cfg = load(); save(cfg); os.makedirs(CACHE, exist_ok=True)
    home = Home(cfg, o); tk = home.tk = ticket(cfg)
    if "approved" not in cfg:        # first start under the approval rule: the screen device and devices that already had write access stay on, everything else is off
        for name in [home.screen_key] * bool(home.screen_key) + cfg.pop("ble_allow", []):
            if not never(name): switch(name, True, "migration")
    srv = ThreadingHTTPServer(("127.0.0.1", o.port), handler(home)); srv.daemon_threads = True

    def spawn(name, cmd, env=None, group=False):
        log = open(os.path.join(CACHE, "home_%s.log" % name), "a")
        p = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env, start_new_session=group); home.procs.append((name, p, cmd, env, group)); return p

    def keep():        # a helper that dies is started again; the address stays the same because the key is stored
        while True:
            time.sleep(3.0)
            for i, (name, p, cmd, env, group) in enumerate(home.procs):
                if p.poll() is not None and name != "awake":
                    say("RESTART", "%s exited with %s" % (name, p.returncode)); home.procs.pop(i); spawn(name, cmd, env, group); break

    spawn("tunnel", [dumbpipe(), "listen-tcp", "--host", "127.0.0.1:%d" % o.port], {"IROH_SECRET": cfg["secret"], "PATH": os.environ.get("PATH", "")})
    spawn("awake", ["caffeinate", "-i", "-w", str(os.getpid())])
    if o.device and not o.no_eyes:
        subprocess.run(["pkill", "-f", "^[^ ]*uxplay -n iPad Eyes"]); time.sleep(0.3)
        spawn("eyes", [sys.executable, os.path.join(ROOT, "eyes", "eyes.py"), "serve"], dict(os.environ, EYES_UXARGS=o.eyes_args), group=True)
    threading.Thread(target=keep, daemon=True).start()
    if bt_permission() == 0 and o.ble != "off":        # ask now, while the person who installed it is looking: a short scan raises macOS's Bluetooth prompt
        def ask():
            try: home.ble.run(home.ble.scan(3.0), 120)
            except Blocked: pass        # still waiting for the person's click; status reports it
        threading.Thread(target=ask, daemon=True).start()
        say("ASK", "macOS is asking for Bluetooth permission for this app. Click Allow")

    def bye(*_):
        say("STOP", "closing the tunnel, the receiver and the Bluetooth link")
        for name, p, _, _, group in home.procs:
            try: os.killpg(p.pid, 15) if group else p.terminate()
            except Exception: pass
        subprocess.run(["pkill", "-f", "^[^ ]*uxplay -n iPad Eyes"])
        if o.device:
            try: home.bt.stop()
            except Exception: pass
        os._exit(0)
    signal.signal(signal.SIGINT, bye); signal.signal(signal.SIGTERM, bye)
    for ip in o.bind:        # e.g. this machine's tailnet address, so a phone on the same private network can open the page
        extra = ThreadingHTTPServer((ip, o.port), handler(home)); extra.daemon_threads = True; threading.Thread(target=extra.serve_forever, daemon=True).start()
        say("ALSO", "listening on %s:%d (token still needed)" % (ip, o.port))
    say("HOME", "'%s' on 127.0.0.1:%d. Screen device: %s. BLE: %s" % (o.name, o.port, o.device or "none", o.ble))
    say("ADDRESS", "%s...%s (permanent; it is the stored key's endpoint)" % (tk[:16], tk[-6:]))
    n = len(cfg["tokens"])
    say("READY", "%d enrolled far end(s)%s. Log of every call: %s. Ctrl-C stops everything" % (n, "" if n else "; add one with `btip home invite`", LOG))
    srv.serve_forever()


def invite(o):
    """One short code hands the address and a fresh token to one far end. The code works once."""
    cfg = load(); save(cfg); tk = ticket(cfg); tok = secrets.token_urlsafe(24)
    from twisted.internet import defer, reactor, task
    import wormhole
    state = {}

    @defer.inlineCallbacks
    def main():
        w = wormhole.create(APPID, MAILBOX, reactor); w.allocate_code(2); code = yield w.get_code()
        say("CODE", code); say("", "On the far machine run:  btip away enroll %s     (waits 10 minutes)" % code)
        w.send_message(json.dumps({"btip_home": 1, "ticket": tk, "token": tok, "home": o.name}).encode())
        hello = json.loads((yield w.get_message())); name = re.sub(r"[^\w.-]", "_", o.who or hello.get("name") or "away")[:40]
        cfg2 = load(); cfg2["tokens"] = {k: v for k, v in cfg2["tokens"].items() if v["name"] != name}      # a re-invite replaces the old token
        cfg2["tokens"][tok] = {"name": name, "created": time.strftime("%F %T")}; save(cfg2); state["ok"] = name
        yield w.close()

    def done(f=None):
        if f is not None and not state.get("ok"): say("ERR", "no far end enrolled: %s. Next: run invite again for a fresh code" % (f.getErrorMessage() or "the code did not match"))
        elif state.get("ok"): say("ENROLLED", "'%s' may now reach this home. Remove it with: btip home revoke %s" % (state["ok"], state["ok"]))
        if reactor.running: reactor.stop()
    main().addBoth(lambda r: done(r if hasattr(r, "getErrorMessage") else None))
    task.deferLater(reactor, 600, lambda: state.get("ok") or (say("ERR", "nobody used the code in 10 minutes. Next: run invite again"), reactor.stop()))
    reactor.run(); sys.exit(0 if state.get("ok") else 1)


def cli(argv=None):
    import argparse
    ap = argparse.ArgumentParser(prog="btip home", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("serve"); p.add_argument("--device", help="the screen device this home drives: bt:AA-BB-CC-DD-EE-FF (paired once with classic/bt.py pair)")
    p.add_argument("--port", type=int, default=9100); p.add_argument("--name", default=os.uname().nodename.split(".")[0])
    p.add_argument("--ble", choices=["read", "off"], default="read", help="read: scan and read any BLE device in range, write only to allowed ones (default). off: no BLE")
    p.add_argument("--no-eyes", action="store_true", help="don't run the AirPlay receiver"); p.add_argument("--eyes-args", default="", help="extra UxPlay arguments, e.g. '-s 820x1180'")
    p.add_argument("--bind", action="append", default=[], metavar="IP", help="also listen on this address (a private one, e.g. this machine's tailnet IP). Default: loopback only")
    p.add_argument("--points-h", type=float, default=1180.0, help="device screen height in points (iPad Air 11 portrait: 1180)")
    p = sub.add_parser("invite"); p.add_argument("who", nargs="?"); p.add_argument("--name", default=os.uname().nodename.split(".")[0])
    p = sub.add_parser("owner-link", help="the page for the person at this computer: switches and invites. Opens on this computer only"); p.add_argument("--port", type=int, default=9100)
    p = sub.add_parser("invite-link", help="a link for one friend, for the public far page. Treat it like a key"); p.add_argument("who")
    p.add_argument("--only", action="append", metavar="DEVICE", help="reach only this device (repeat for more). Default: every device that is on"); p.add_argument("--hours", type=float, help="the link stops working after this many hours")
    p.add_argument("--mode", choices=["read", "full"], default="read", help="read (default): look and listen only. full: act on the device too")
    p = sub.add_parser("link", help="for a browser-only far end (a phone): mint a token and print the page link. Treat the link like a key"); p.add_argument("who"); p.add_argument("--host", default="127.0.0.1"); p.add_argument("--port", type=int, default=9100)
    sub.add_parser("list"); sub.add_parser("revoke").add_argument("who"); sub.add_parser("devices")
    for name in ("approve", "unapprove", "allow-ble"): sub.add_parser(name).add_argument("device")
    sub.add_parser("owner", help="let one enrolled far end flip device switches from its page").add_argument("who")
    o = ap.parse_args(argv)
    try:
        if o.cmd == "serve": serve(o)
        elif o.cmd == "invite": invite(o)
        elif o.cmd == "owner-link":
            cfg = load(); tok = next((k for k, v in cfg["tokens"].items() if v["name"] == "this computer"), None) or mint("this computer", "owner")
            print("http://127.0.0.1:%d/?t=%s" % (o.port, tok))
        elif o.cmd == "invite-link": print(far_link(ticket(load()), mint(o.who, only=o.only, hours=o.hours, mode=o.mode)))
        elif o.cmd == "link":
            cfg = load(); tok = secrets.token_urlsafe(24); cfg["tokens"] = {k: v for k, v in cfg["tokens"].items() if v["name"] != o.who}
            cfg["tokens"][tok] = {"name": o.who, "created": time.strftime("%F %T")}; save(cfg); print("http://%s:%d/?t=%s" % (o.host, o.port, tok))
        elif o.cmd == "list":
            for v in load()["tokens"].values(): print("%-20s enrolled %s  %s%s" % (v["name"], v["created"], "read-only" if v.get("mode") == "read" else "full", "  (owner: may flip device switches)" if v.get("role") == "owner" else ""))
        elif o.cmd == "revoke":
            cfg = load(); n = len(cfg["tokens"]); cfg["tokens"] = {k: v for k, v in cfg["tokens"].items() if v["name"] != o.who}; save(cfg)
            say("REVOKED" if len(cfg["tokens"]) < n else "ERR", o.who if len(cfg["tokens"]) < n else "no far end named '%s'. Next: btip home list" % o.who)
        elif o.cmd in ("approve", "allow-ble"): switch(o.device, True); say("ON", "far ends may now use '%s'. Off again: btip home unapprove '%s'" % (dkey(o.device), dkey(o.device)))
        elif o.cmd == "unapprove": switch(o.device, False); say("OFF", "far ends can no longer use '%s'" % dkey(o.device))
        elif o.cmd == "owner":
            cfg = load(); hit = [v for v in cfg["tokens"].values() if v["name"] == o.who]
            for v in hit: v["role"] = "owner"
            save(cfg); say("OWNER" if hit else "ERR", "'%s' may now flip device switches from its page" % o.who if hit else "no far end named '%s'. Next: btip home list" % o.who)
        elif o.cmd == "devices":
            import bonds; ap = load().get("approved", {})
            seen = {}
            for b in bonds.paired(): seen[dkey(b["name"])] = seen.get(dkey(b["name"])) or b["kind"] or ""
            for k, kind in seen.items(): print("%-4s %-28s paired  %s" % ("ON" if k in ap else "off", k, kind))
            for k in sorted(set(ap) - {dkey(b["name"]) for b in bonds.paired()}): print("%-4s %-28s in range (not paired)" % ("ON", k))
    except Blocked as e: say("ERR", str(e)); sys.exit(1)


if __name__ == "__main__":
    cli()
