#!/usr/bin/env python3
"""btip: lend a Bluetooth radio to someone far away. The two ends meet by a short spoken code.

  sudo btip lend [--hci 0] [--target ADDR]... [--open] [--allow-vendor]   the end that owns the radio (Linux)
  btip join CODE [--port 9001]                                            the end that drives it
  btip get-iroh                                                          fetch the optional direct-path transport

`lend` prints a code such as 7-crossover-clockwork. Read it to the other person. `join` turns the code
into a local port that speaks raw Bluetooth HCI (H4 over TCP), so any host stack can use the far radio:
  kbd.py serve tcp-client:127.0.0.1:9001        # the keyboard demo in this folder
  bumble-scan tcp-client:127.0.0.1:9001         # any Bumble app (needs `lend --open`)

Both ends dial out. No port-forward, no account, no public address. The code works once. The traffic is
encrypted end to end; the public servers that help the two ends meet only see ciphertext.

The lender stays in charge. A guard on the lender's side reads every packet the far side sends:
  - vendor commands are refused (they can rewrite firmware or the radio's address)
  - scanning the neighbourhood is refused
  - the far side may connect only to targets the lender named (--target) or that someone paired by hand
  - when the tunnel goes quiet for 3 s, or the lender presses Ctrl-C, the radio is reset and every link drops
Lines start with a fixed word (CODE, READY, PATH, REFUSED, STALL, ERR) so a script or an agent can follow."""
import argparse, ctypes, ctypes.util, hashlib, hmac, json, os, platform, re, secrets, shutil, socket, statistics, struct, sys, time

APPID = "twinsavior.github.io/btip/1"
MAILBOX = "ws://relay.magic-wormhole.io:4000/v1"
TRANSIT = "tcp:transit.magic-wormhole.io:4001"
CACHE = os.path.expanduser("~/.cache/btip")
IROH = ("v0.40.1", {   # dumbpipe release assets and their SHA-256, taken from the GitHub release on 2026-11-05
    ("linux", "x86_64"): ("linux-x86_64", "66aee1e249890ee63678dfc8f18ce3671e691673c83bbd72bf9a54c4d32da85c"),
    ("linux", "aarch64"): ("linux-aarch64", "1529c49598ac15d9413bf7f29a09c04cf2f5dc3af1b9080a1b50855a77846c47"),
    ("darwin", "arm64"): ("darwin-aarch64", "e6bd3c9a98ba22e8233ae1f8ba5e2dceb4cbf132dc4d4332589295b702902a27"),
    ("darwin", "x86_64"): ("darwin-x86_64", "eaa35e228528cbf5fc2a8a07646570f49af6ab1acd35c8f539f150a0cb5d4b0e")})


def say(word, text=""):
    print("%s %-8s %s" % (time.strftime("%H:%M:%S"), word, text), flush=True)


def die(text):
    say("ERR", text); sys.exit(1)


def addr(b):
    return ":".join("%02X" % x for x in reversed(bytes(b)))


# ----------------------------------------------------------------------------- HCI packets and the guard
HDR = {1: (4, lambda b: b[3]), 2: (5, lambda b: b[3] | b[4] << 8), 3: (4, lambda b: b[3]),
       4: (3, lambda b: b[2]), 5: (5, lambda b: (b[3] | b[4] << 8) & 0x3FFF)}


class H4:
    """Cuts a byte stream into whole HCI packets (type byte first)."""
    def __init__(self): self.buf = bytearray()

    def feed(self, data):
        self.buf += data; out = []
        while self.buf:
            h = HDR.get(self.buf[0])
            if h is None: raise ValueError("not Bluetooth HCI: packet type 0x%02x" % self.buf[0])
            if len(self.buf) < h[0]: break
            n = h[0] + h[1](self.buf)
            if len(self.buf) < n: break
            out.append(bytes(self.buf[:n])); del self.buf[:n]
        return out


class Guard:
    """Decides which commands from the far side reach the lender's radio. No I/O of its own."""
    STATUS_STYLE = {0x0401, 0x0405, 0x200D, 0x2043}                    # these are answered by Command Status, the rest by Command Complete
    TEST = {0x201D, 0x201E, 0x2033, 0x2034, 0x204F, 0x2050, 0x207B}    # LE receiver and transmitter tests

    def __init__(self, to_radio, to_host, targets, open_=False, vendor=False, note=say):
        self.to_radio, self.to_host, self.targets, self.open, self.vendor, self.note = to_radio, to_host, targets, open_, vendor, note
        self.h4 = H4(); self.refused = 0; self.links = set()      # links: open connection handles, so the lender can end them cleanly

    def verdict(self, op, p):
        """None when the command may pass, else the reason it may not."""
        if op >> 10 == 0x3F and not self.vendor: return "a vendor command (it can rewrite firmware or the radio's address). Lender: restart with --allow-vendor to permit"
        if op >> 10 == 0x06 or op in self.TEST: return "a radio test mode"
        if op == 0x0C0D: return "reading link keys stored in the radio"
        if self.open: return None
        if op in (0x0401, 0x0403) or (op in (0x200C, 0x2042) and p[:1] == b"\x01"):
            return "a scan for nearby devices. Lender: restart with --open to permit"
        peer = None
        if op == 0x0405: peer = p[0:6]
        elif op == 0x200D: peer = p[6:12] if p[4:5] == b"\x00" else b""
        elif op == 0x2043: peer = p[3:9] if p[0:1] == b"\x00" else b""
        if peer == b"": return "a connection by accept list. Lender: restart with --open to permit"
        if peer is not None and addr(peer) not in self.targets:
            return "a connection to %s, which the lender did not name and which did not pair by hand. Lender: restart with --target %s" % (addr(peer), addr(peer))
        return None

    def learn(self, peer, how):
        a = addr(peer)
        if a not in self.targets: self.targets.add(a); self.note("TARGET", "%s %s; the far side may reconnect to it" % (a, how))

    def from_host(self, data):
        for pkt in self.h4.feed(data):
            if pkt[0] == 1:
                op = pkt[1] | pkt[2] << 8; why = self.verdict(op, pkt[4:])
                if why:
                    self.refused += 1; self.note("REFUSED", "command 0x%04x: %s" % (op, why))
                    self.to_host(bytes([4, 0x0F, 4, 0x0C, 1, pkt[1], pkt[2]]) if op in self.STATUS_STYLE else bytes([4, 0x0E, 4, 1, pkt[1], pkt[2], 0x0C]))
                    continue
                if op == 0x0409: self.learn(pkt[4:10], "connected to this radio and was accepted")
            self.to_radio(pkt)

    def from_radio(self, pkt):
        if pkt[0] == 4 and len(pkt) >= 6:
            if pkt[1] == 0x03 and pkt[3] == 0: self.links.add(pkt[4] | pkt[5] << 8)                    # Connection Complete
            elif pkt[1] == 0x05 and pkt[3] == 0: self.links.discard(pkt[4] | pkt[5] << 8)              # Disconnection Complete
            elif pkt[1] == 0x3E and len(pkt) >= 15 and pkt[3] in (0x01, 0x0A) and pkt[4] == 0:         # LE Connection Complete
                self.links.add(pkt[5] | pkt[6] << 8)
                if pkt[7] == 1: self.learn(pkt[9:15], "connected to this radio (LE)")
        self.to_host(pkt)

    def hang_up(self):
        """Disconnect commands for every open link. A reset alone drops them silently, and the far device then
        keeps a held key repeating until its own timeout (measured on an iPad: 4.6 s). A disconnect tells it now."""
        return [bytes([1, 0x06, 0x04, 3, h & 0xFF, h >> 8, 0x13]) for h in sorted(self.links)]


# ----------------------------------------------------------------------------- the radio (lender)
class HciRadio:
    """The kernel's HCI user channel: this process alone owns hciN until it exits. BlueZ can't take it back meanwhile."""
    def __init__(self, dev, on_packet):
        import fcntl
        self.on_packet = on_packet
        if not sys.platform.startswith("linux"):
            die("lend needs Linux (a Pi, a laptop, a router you control). On this %s box the built-in radio can't be opened raw; that shim is not built yet. Next: run lend on a Linux box near the target" % platform.system())
        AF, HCI = 31, 1
        try:
            ctl = socket.socket(AF, socket.SOCK_RAW, HCI)
            info = bytearray(struct.pack("<H", dev) + bytes(126)); fcntl.ioctl(ctl.fileno(), 0x800448D3, info)        # HCIGETDEVINFO
            self.addr = addr(info[10:16]); self.was_up = bool(struct.unpack_from("<I", info, 16)[0] & 1)
            fcntl.ioctl(ctl.fileno(), 0x400448CA, dev)                                                                # HCIDEVDOWN
            self.sock = socket.socket(AF, socket.SOCK_RAW, HCI)
            libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True); sa = struct.pack("<HHH", AF, dev, 1)   # channel 1 = user
            if libc.bind(self.sock.fileno(), sa, len(sa)) != 0: raise OSError(ctypes.get_errno(), os.strerror(ctypes.get_errno()))
            ctl.close()
        except PermissionError: die("opening the radio needs root. Next: run the same command with sudo")
        except OSError as e:
            if e.errno == 19: die("no Bluetooth radio hci%d. Next: `ls /sys/class/bluetooth` and pass --hci N" % dev)
            die("can't take hci%d: %s. Next: stop whatever else holds it raw (btproxy, btmon -w, another lend)" % (dev, e))

    def fileno(self): return self.sock.fileno()
    def logPrefix(self): return "hci"
    def connectionLost(self, reason): pass
    def doRead(self): self.on_packet(self.sock.recv(4096))       # one read = one whole packet
    def write(self, pkt): self.sock.send(pkt)
    def start(self, reactor): reactor.addReader(self)
    def close(self): self.sock.close()


def nodelay(transport):
    try: transport.setTcpNoDelay(True)
    except Exception: pass


def find_dumbpipe(home=None):
    for p in (os.path.join(home or CACHE, "bin", "dumbpipe"), shutil.which("dumbpipe")):
        if p and os.access(p, os.X_OK): return p
    return None


def get_iroh():
    import tarfile, urllib.request
    ver, table = IROH; key = (sys.platform.rstrip("0123456789"), platform.machine())
    if key not in table: die("no dumbpipe build for %s %s. btip still works without it, over the wormhole transit path" % key)
    name, want = table[key]; url = "https://github.com/n0-computer/dumbpipe/releases/download/%s/dumbpipe-%s-%s.tar.gz" % (ver, ver, name)
    os.makedirs(CACHE + "/bin", exist_ok=True); tgz = CACHE + "/bin/dumbpipe.tgz"
    say("FETCH", url); urllib.request.urlretrieve(url, tgz)
    got = hashlib.sha256(open(tgz, "rb").read()).hexdigest()
    if got != want: os.unlink(tgz); die("checksum mismatch for %s (got %s). Nothing was installed" % (url, got))
    with tarfile.open(tgz) as t: open(CACHE + "/bin/dumbpipe", "wb").write(t.extractfile("./dumbpipe").read())
    os.chmod(CACHE + "/bin/dumbpipe", 0o755); os.unlink(tgz); say("OK", CACHE + "/bin/dumbpipe (%s, checksum matched)" % ver)


# ----------------------------------------------------------------------------- shared tunnel pieces
def wormhole_setup(o):
    """Returns (reactor, wormhole module) with Nagle turned off on Dilation's sockets: HCI is many small packets."""
    from twisted.internet import reactor
    import wormhole
    from wormhole._dilation import connection as c
    made = c.DilatedConnectionProtocol.connectionMade
    def connection_made(self): nodelay(self.transport); return made(self)
    c.DilatedConnectionProtocol.connectionMade = connection_made
    # Dilation answers every record with its own small ack packet. The public transit relay keeps Nagle on, so a
    # reply sent a few ms after that ack waits behind it (measured: 197 ms per HCI round trip on a 105 ms tunnel).
    # Hold each ack up to 0.2 s and send it in the same write as the next data record.
    from wormhole._dilation import manager as m
    send_ack, send_data, waiting = m.Manager.send_ack, m.Manager.send_data, {}
    def flush(self):
        for seq in waiting.pop(id(self), []): send_ack(self, seq)
    def late_ack(self, seq):
        if id(self) not in waiting: waiting[id(self)] = []; self._reactor.callLater(0.2, flush, self)
        waiting[id(self)].append(seq)
    def data_with_acks(self, scid, data): flush(self); return send_data(self, scid, data)
    m.Manager.send_ack, m.Manager.send_data = late_ack, data_with_acks
    return reactor, wormhole


def spawn_dumbpipe(reactor, exe, args, on_line):
    from twisted.internet import protocol
    class P(protocol.ProcessProtocol):
        buf = b""
        def childDataReceived(self, fd, data):
            self.buf += data
            while b"\n" in self.buf:
                line, self.buf = self.buf.split(b"\n", 1); line = line.decode("utf8", "replace")
                if "secret key" not in line: on_line(line)       # dumbpipe prints its key; never pass it on
        def processEnded(self, reason): on_line(None)
    return reactor.spawnProcess(P(), exe, [exe] + args, env={"PATH": os.environ.get("PATH", "")})


def dilation_path(st):
    """'direct', 'relay' or None from a Dilation status update."""
    hint = getattr(getattr(st, "peer_connection", None), "hint_description", None)
    return None if hint is None else ("relay" if "relay" in hint else "direct")


# ----------------------------------------------------------------------------- lend
def lend(o):
    radio_box = []
    radio = None if o.radio else HciRadio(o.hci, lambda pkt: radio_box[0](pkt))
    home = os.path.expanduser("~" + os.environ["SUDO_USER"]) + "/.cache/btip" if os.environ.get("SUDO_USER") else CACHE
    exe = None if o.no_iroh else find_dumbpipe(home)
    if radio and os.geteuid() == 0 and os.environ.get("SUDO_UID"):       # the radio is open: root is no longer needed
        os.setgroups([]); os.setgid(int(os.environ["SUDO_GID"])); os.setuid(int(os.environ["SUDO_UID"]))
    reactor, wormhole = wormhole_setup(o)
    from twisted.internet import defer, endpoints, protocol, task

    S = {"token": secrets.token_hex(16), "hci": None, "guard": None, "alive": 0.0, "resets": 0, "held": None, "targets": {t.upper() for t in o.target}}

    def to_radio(pkt): radio.write(pkt)
    def reset_radio(): S["resets"] += 1; to_radio(b"\x01\x03\x0c\x00")

    def release():
        held, S["held"] = S["held"], None
        for d in held or []: host_data(d)

    def on_radio(pkt):
        if S["resets"] and pkt[:2] == b"\x04\x0e" and pkt[4:6] == b"\x03\x0c":     # the answer to our own reset stays here
            S["resets"] -= 1
            if S["held"] is not None: release()
            return
        if S["hci"]: S["guard"].from_radio(pkt)
    radio_box.append(on_radio)

    def host_data(d):
        if S["held"] is not None: S["held"].append(d); return
        try: S["guard"].from_host(d)
        except ValueError as e: detach(S["hci"], str(e))

    def attach(conn):
        if S["hci"]: return False
        S["hci"], S["alive"], S["held"] = conn, time.monotonic(), []
        S["guard"] = Guard(to_radio, conn.transport.write, S["targets"], o.open, o.allow_vendor)
        reset_radio(); reactor.callLater(1.5, lambda: S["hci"] is conn and S["held"] is not None and release())
        say("DRIVING", "the far side now drives the radio. Ctrl-C ends it")
        return True

    def detach(conn, why):
        if conn is None or S["hci"] is not conn: return
        S["hci"] = None; S["held"] = None; bye = S["guard"].hang_up()
        for pkt in bye: to_radio(pkt)
        reactor.callLater(0.4 if bye else 0, lambda: S["hci"] is None and reset_radio()); conn.transport.loseConnection()
        say("RELEASED", "%s. %d link(s) ended, radio reset. %d commands refused this session" % (why, len(bye), S["guard"].refused))

    class Conn(protocol.Protocol):
        """One stream from the far side: a line 'BTIP1 <token> hci|alive', then raw bytes."""
        kind = None; buf = b""
        def connectionMade(self): nodelay(self.transport)
        def dataReceived(self, d):
            if self.kind is None:
                self.buf += d
                if b"\n" not in self.buf:
                    if len(self.buf) > 200: self.transport.loseConnection()
                    return
                line, d = self.buf.split(b"\n", 1); parts = line.decode("ascii", "replace").split()
                if len(parts) != 3 or parts[0] != "BTIP1" or not hmac.compare_digest(parts[1], S["token"]) or parts[2] not in ("hci", "alive"):
                    self.transport.loseConnection(); return
                self.kind = parts[2]
                if self.kind == "hci" and not attach(self):
                    self.kind = "extra"; self.transport.loseConnection(); return
            if not d: return
            if self.kind == "alive": S["alive"] = time.monotonic(); self.transport.write(d)
            elif self.kind == "hci": host_data(d)
        def connectionLost(self, reason=None):
            if self.kind == "hci": detach(self, "the far side closed the stream")

    def watchdog():
        if S["hci"] and time.monotonic() - S["alive"] > o.stall:
            say("STALL", "no heartbeat from the far side for %.1f s" % (time.monotonic() - S["alive"])); detach(S["hci"], "the tunnel went silent")

    @defer.inlineCallbacks
    def main():
        nonlocal radio
        factory = protocol.Factory.forProtocol(Conn)
        if o.radio:                                                          # tcp:HOST:PORT, e.g. stock btproxy or a test controller
            _, host, port = o.radio.split(":"); h4 = H4()
            class Tcp(protocol.Protocol):
                def connectionMade(self): nodelay(self.transport)
                def dataReceived(self, d):
                    for pkt in h4.feed(d): on_radio(pkt)
                def write(self, pkt): self.transport.write(pkt)
            radio = yield endpoints.TCP4ClientEndpoint(reactor, host, int(port)).connect(protocol.Factory.forProtocol(Tcp))
            radio.addr = o.radio
        else: radio.start(reactor)
        reset_radio()
        rules = "anything but vendor commands" if o.open else "no scans, no vendor commands, targets: %s" % (", ".join(sorted(S["targets"])) or "only what pairs by hand")
        say("RADIO", "%s is yours to lend. Rules: %s%s" % (radio.addr, rules, " (vendor commands allowed)" if o.allow_vendor else ""))
        ticket = None
        if exe:
            port = (yield endpoints.TCP4ServerEndpoint(reactor, 0, interface="127.0.0.1").listen(factory)).getHost().port
            got = defer.Deferred()
            def line(text):
                m = re.search(r"endpoint[a-z0-9]{40,}", text or "")
                if (m or text is None) and not got.called: got.callback(m.group(0) if m else None)
            S["dumbpipe"] = spawn_dumbpipe(reactor, exe, ["listen-tcp", "--host", "127.0.0.1:%d" % port], line)
            reactor.callLater(10, lambda: got.called or got.callback(None)); ticket = yield got
            if not ticket: say("NOTE", "dumbpipe gave no ticket in 10 s; using the wormhole transit path only")
        w = wormhole.create(APPID, o.mailbox, reactor, dilation=True)
        w.allocate_code(o.words); code = yield w.get_code()
        say("CODE", code); say("", "Read the code to the other person. They run:  btip join %s" % code)
        dw = w.dilate(transit_relay_location=o.transit, no_listen=o.relay_only)
        dw.listener_for("btip").listen(factory)
        w.send_message(json.dumps({"btip": 1, "token": S["token"], "iroh": ticket}).encode())
        hello = json.loads((yield w.get_message()))
        say("JOINED", "the other end holds the code (direct path transport: %s)" % ("offered" if ticket and hello.get("iroh") else "not on both ends"))
        task.LoopingCall(watchdog).start(0.5)

    def failed(f):
        text = "the code did not match: someone mistyped it or guessed. Next: run lend again for a fresh code" if f.check(wormhole.errors.WrongPasswordError) else f.getErrorMessage() or repr(f.value)
        say("ERR", text); S["failed"] = True; reactor.callLater(0, reactor.stop)

    def cleanup():
        try:
            if S.get("dumbpipe"): S["dumbpipe"].signalProcess("KILL")
            bye = S["guard"].hang_up() if S["hci"] and S["guard"] else []
            for pkt in bye: to_radio(pkt)
        except Exception: bye = []
        def last():
            try: to_radio(b"\x01\x03\x0c\x00")
            except Exception: pass
            say("DONE", "radio reset and handed back to this box")
        return task.deferLater(reactor, 0.4 if bye else 0, last)
    reactor.addSystemEventTrigger("before", "shutdown", cleanup)
    main().addErrback(failed)
    reactor.run()
    if S.get("failed"): sys.exit(1)


# ----------------------------------------------------------------------------- join
def join(o):
    reactor, wormhole = wormhole_setup(o)
    from twisted.internet import defer, endpoints, protocol, task
    exe = None if o.no_iroh else find_dumbpipe()
    S = {"via": None, "dw": None, "token": None, "iroh_port": None, "echo": 0.0, "rtts": [], "brain": None, "path": None, "alive": None, "ready": False}

    class Leg(protocol.Protocol):
        """One end of a two-way pipe. `header` goes out first; bytes wait in `buf` until the other end is up."""
        other = None; header = b""; buf = b""
        def connectionMade(self):
            nodelay(self.transport)
            if self.header: self.transport.write(self.header)
            if self.other and self.other.buf: self.transport.write(self.other.buf); self.other.buf = b""
        def dataReceived(self, d):
            if self.other and self.other.transport: self.other.transport.write(d)
            else: self.buf += d
        def connectionLost(self, reason=None):
            if self.other and self.other.transport: self.other.transport.loseConnection()

    def open_stream(kind, proto):
        proto.header = ("BTIP1 %s %s\n" % (S["token"], kind)).encode()
        ep = endpoints.TCP4ClientEndpoint(reactor, "127.0.0.1", S["iroh_port"]) if S["via"] == "iroh" else S["dw"].connector_for("btip")
        return ep.connect(protocol.Factory.forProtocol(lambda: proto))

    class Alive(Leg):
        """Heartbeat: 8 bytes out every 0.5 s, echoed by the lender. Feeds the lender's watchdog and times the tunnel."""
        def dataReceived(self, d):
            self.buf += d
            while len(self.buf) >= 8:
                t, self.buf = struct.unpack("!d", self.buf[:8])[0], self.buf[8:]
                S["echo"] = time.monotonic(); S["rtts"] = (S["rtts"] + [(S["echo"] - t) * 1000])[-40:]
        def connectionLost(self, reason=None):
            if S["alive"] is self: S["alive"] = None

    def beat():
        now = time.monotonic()
        if S["alive"] is None:
            if now - S.get("dialed", 0) > 2: S["dialed"] = now; a = Alive(); open_stream("alive", a).addCallbacks(lambda p: S.update(alive=a), lambda f: None)
        elif S["alive"].transport: S["alive"].transport.write(struct.pack("!d", now))
        if S["ready"] and S["brain"] and now - S["echo"] > o.stall:
            say("STALL", "no heartbeat echo for %.1f s; closing the host stack's connection. The lender resets the radio by itself" % (now - S["echo"]))
            S["brain"].transport.loseConnection()

    def report():
        if not S["rtts"]: return
        r = sorted(S["rtts"]); info = {"t": time.time(), "port": o.port, "via": S["via"], "path": S["path"], "rtt_ms": round(statistics.median(r), 1), "rtt_max_ms": round(r[-1], 1)}
        os.makedirs(CACHE, exist_ok=True); json.dump(info, open(CACHE + "/join.json", "w"))
        say("PATH", "%s%s, tunnel round trip %.0f ms median, %.0f ms worst of the last %d" % (S["via"], " " + S["path"] if S["path"] else "", info["rtt_ms"], r[-1], len(r)))

    class Brain(Leg):
        def connectionMade(self):
            if S["brain"]: self.transport.loseConnection(); return
            S["brain"] = self; far = Leg(); self.other, far.other = far, self; nodelay(self.transport)
            say("HOST", "a host stack connected; it now drives the far radio")
            open_stream("hci", far).addErrback(lambda f: (say("ERR", "can't open the stream to the far side: %s" % f.getErrorMessage()), self.transport.loseConnection()))
        def connectionLost(self, reason=None):
            if S["brain"] is self: S["brain"] = None; say("HOST", "the host stack left; the far radio resets"); Leg.connectionLost(self)

    @defer.inlineCallbacks
    def wait_echo(seconds):
        t0 = time.monotonic(); S["echo"] = 0.0
        while time.monotonic() - t0 < seconds and not S["echo"]: yield task.deferLater(reactor, 0.1, lambda: None)
        return bool(S["echo"])

    @defer.inlineCallbacks
    def main():
        w = wormhole.create(APPID, o.mailbox, reactor, dilation=True)
        w.set_code(o.code)
        w.send_message(json.dumps({"btip": 1, "iroh": bool(exe)}).encode())
        hello = json.loads((yield w.get_message())); S["token"] = hello["token"]
        say("MET", "the code matched; the two ends share a key")
        beats = task.LoopingCall(beat)
        if exe and hello.get("iroh"):
            s = socket.socket(); s.bind(("127.0.0.1", 0)); S["iroh_port"] = s.getsockname()[1]; s.close()
            S["dumbpipe"] = spawn_dumbpipe(reactor, exe, ["connect-tcp", "--addr", "127.0.0.1:%d" % S["iroh_port"], hello["iroh"]], lambda line: None)
            S["via"] = "iroh"; yield task.deferLater(reactor, 0.5, lambda: None); beats.start(0.5)
            if not (yield wait_echo(12)):
                say("NOTE", "the direct-path transport did not answer in 12 s; falling back to the wormhole transit path")
                beats.stop(); S["dumbpipe"].signalProcess("KILL"); S["via"] = None; S["alive"] = None
        if S["via"] is None:
            def status(st): S["path"] = dilation_path(st) or S["path"]
            S["dw"] = w.dilate(transit_relay_location=o.transit, no_listen=o.relay_only, on_status_update=status)
            yield S["dw"].when_dilated(); S["via"] = "wormhole"; beats.start(0.5)
            if not (yield wait_echo(20)): raise RuntimeError("the tunnel opened but the lender did not answer. Next: check that lend is still running, then start over with a fresh code")
        yield endpoints.TCP4ServerEndpoint(reactor, o.port, interface="127.0.0.1").listen(protocol.Factory.forProtocol(Brain))
        S["ready"] = True; yield task.deferLater(reactor, 1.5, lambda: None); report(); task.LoopingCall(report).start(30, now=False)
        say("READY", "tcp-client:127.0.0.1:%d   (the far radio, raw HCI. Example: kbd.py serve tcp-client:127.0.0.1:%d)" % (o.port, o.port))

    def failed(f):
        if f.check(wormhole.errors.WrongPasswordError): text = "the code did not match. Next: ask the lender to run lend again and read you the new code"
        elif f.check(wormhole.errors.KeyFormatError): text = "that is not a code. It looks like 7-crossover-clockwork"
        else: text = f.getErrorMessage() or repr(f.value)
        say("ERR", text); S["failed"] = True; reactor.callLater(0, reactor.stop)

    def cleanup():
        try:
            if S.get("dumbpipe"): S["dumbpipe"].signalProcess("KILL")
        except Exception: pass
    reactor.addSystemEventTrigger("before", "shutdown", cleanup)
    main().addErrback(failed)
    reactor.run()
    if S.get("failed"): sys.exit(1)


def cli(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] and argv[0] in ("home", "away", "present"):        # the standing presence: each lives in its own file
        import importlib
        return importlib.import_module(argv[0]).cli(argv[1:])
    ap = argparse.ArgumentParser(prog="btip", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("lend", "join"):
        p = sub.add_parser(name)
        p.add_argument("--mailbox", default=MAILBOX, help="magic-wormhole mailbox server (default: the public one)")
        p.add_argument("--transit", default=TRANSIT, help="magic-wormhole transit relay (default: the public one)")
        p.add_argument("--relay-only", action="store_true", help="wormhole path: publish no direct addresses (test the relay)")
        p.add_argument("--no-iroh", action="store_true", help="don't use dumbpipe even when it is installed")
        p.add_argument("--stall", type=float, default=3.0, help="seconds of silence before the tunnel counts as dead (default 3)")
    p = sub.choices["lend"]
    p.add_argument("--hci", type=int, default=0, help="which radio: N of hciN (default 0)")
    p.add_argument("--radio", help="tcp:HOST:PORT of an HCI socket (stock btproxy) instead of opening hciN here")
    p.add_argument("--target", action="append", default=[], metavar="ADDR", help="a device the far side may connect to (repeatable)")
    p.add_argument("--open", action="store_true", help="allow scans and connections to any device")
    p.add_argument("--allow-vendor", action="store_true", help="allow vendor commands (firmware, address)")
    p.add_argument("--words", type=int, default=2, help="words in the code (default 2)")
    p = sub.choices["join"]
    p.add_argument("code"); p.add_argument("--port", type=int, default=9001, help="local HCI port (default 9001)")
    sub.add_parser("get-iroh")
    o = ap.parse_args(argv)
    {"lend": lend, "join": join, "get-iroh": lambda o: get_iroh()}[o.cmd](o)


if __name__ == "__main__":
    cli()
