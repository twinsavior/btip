#!/usr/bin/env python3
"""bt.py: this Mac as a Bluetooth keyboard, pointer and media remote for a paired device (library + CLI).
bt_mcp.py wraps the same verbs as MCP tools. Nothing is installed on the device; it sees an ordinary
Bluetooth keyboard and mouse. The hid5 daemon holds the link; this file starts it and talks to it.

CLI:  bt.py list_devices | status | pair [SECONDS] | connect DEV | disconnect DEV | stop
      bt.py type DEV TEXT | key DEV COMBO [COMBO...] | media DEV NAME
      bt.py tap DEV X Y [HOLD_S] [l|r] | move DEV X Y | click DEV [l|r] | drag DEV X1 Y1 X2 Y2
      bt.py scroll DEV DY [DX] | nudge DEV DX DY
DEV is bt:AA-BB-CC-DD-EE-FF (list_devices prints it). X and Y are fractions of the device screen,
0..1 from the left and from the top, in the orientation the device is in now."""
import json, os, re, subprocess, sys, time, uuid

HERE = os.path.dirname(os.path.abspath(__file__))
RUN = os.environ.get("BT_RUN", os.path.expanduser("~/.cache/screens-bt"))
os.makedirs(RUN, exist_ok=True)
CMD, LOG, PID, DEVS = (os.path.join(RUN, n) for n in ("hid5.cmd", "hid5.log", "hid5.pid", "devices.json"))
SRC, BIN = os.path.join(HERE, "hid5.swift"), os.path.join(HERE, "bin_hid5")
MEDIA = ["home", "search", "volup", "voldown", "mute", "play", "next", "prev", "brightup", "brightdown"]
# The agent never types these shapes: passcodes, one-time codes, card numbers.
DENY_TYPE = re.compile(r"^\s*\d{4,8}\s*$|^(\d[ -]?){13,19}$")


class Blocked(Exception):
    """A refusal or failure. The message names the next step."""


def norm(dev):
    a = dev.split(":", 1)[1] if dev.lower().startswith("bt:") else dev
    a = a.strip().upper().replace(":", "-")
    if not re.fullmatch(r"([0-9A-F]{2}-){5}[0-9A-F]{2}", a):
        raise Blocked(f"'{dev}' is not a device id. Use bt:AA-BB-CC-DD-EE-FF from list_devices.")
    return a


def known():
    try: return json.load(open(DEVS))
    except Exception: return {}


def remember(addr, name=""):
    d = known(); d[addr] = {"name": name or d.get(addr, {}).get("name", ""), "last_ok": time.strftime("%Y-%m-%d %H:%M:%S")}
    json.dump(d, open(DEVS, "w"), indent=1)


# ---------- daemon ----------
def daemon_pid():
    try: pid = int(open(PID).read().strip())
    except Exception: return None
    out = subprocess.run(["ps", "-p", str(pid), "-o", "comm="], capture_output=True, text=True).stdout
    return pid if "hid5" in out else None


def build():
    if os.path.exists(BIN) and os.path.getmtime(BIN) >= os.path.getmtime(SRC): return
    r = subprocess.run(["swiftc", "-O", SRC, "-o", BIN], capture_output=True, text=True)
    if r.returncode != 0: raise Blocked("swiftc could not build hid5.swift. Next: run `xcode-select --install`, then retry.\n" + r.stderr[-600:])


def start(addr="", discoverable=False):
    """Start the hid5 daemon if it is not running. It keeps running after this process exits."""
    if daemon_pid(): return daemon_pid()
    build()
    env = dict(os.environ, CMD=CMD, AUTOCONNECT="0")
    if addr: env["ADDR"] = addr
    if discoverable: env["DISC"] = "1"
    pos = os.path.getsize(LOG) if os.path.exists(LOG) else 0
    p = subprocess.Popen([BIN], stdout=open(LOG, "a"), stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env, cwd=RUN, start_new_session=True)
    open(PID, "w").write(str(p.pid))
    t0 = time.time(); new = ""
    while time.time() - t0 < 10 and "ready pid" not in new and p.poll() is None:
        time.sleep(0.1)
        with open(LOG, "rb") as f:
            f.seek(pos); new = f.read().decode("utf-8", "replace")
    if "SDP publish -> REFUSED" in new: raise Blocked("bluetoothd refused the HID service record. Next: is Bluetooth on? Then read " + LOG)
    if "ready pid" not in new: raise Blocked("the hid5 daemon did not come up. Next: read " + LOG)
    return p.pid


def tail(nbytes=20000):
    try:
        with open(LOG, "rb") as f:
            f.seek(0, 2); size = f.tell(); f.seek(max(0, size - nbytes)); return f.read().decode("utf-8", "replace")
    except FileNotFoundError: return ""


def send(cmd, timeout=15.0):
    """Send one command line to the daemon and return its result text. Raises Blocked on 'err'."""
    if not daemon_pid(): raise Blocked("the hid5 daemon is not running. Next: connect bt:<addr> (or pair for a new device).")
    tag = "#" + uuid.uuid4().hex[:10]
    pos = os.path.getsize(LOG) if os.path.exists(LOG) else 0
    with open(CMD, "a") as f: f.write(f"{tag} {cmd}\n")
    t0 = time.time()
    while time.time() - t0 < timeout:
        with open(LOG, "rb") as f:
            f.seek(pos); new = f.read().decode("utf-8", "replace")
        for ln in new.splitlines():
            if f"done {tag} " in ln:
                res = ln.split(" -> ", 1)[1] if " -> " in ln else ""
                if res.startswith("err"): raise Blocked(res[4:])
                return res[3:] if res.startswith("ok ") else ("" if res == "ok" else res)
        time.sleep(0.03)
    raise Blocked(f"no answer from the daemon in {timeout:.0f} s for '{cmd[:30]}'. Next: bt.py status; if it hangs too, bt.py stop and connect again.")


def stop():
    pid = daemon_pid()
    if not pid: return {"stopped": False, "note": "no daemon was running"}
    os.kill(pid, 15)  # hid5 closes the channels, removes its service record and turns discoverable off
    for _ in range(80):
        if not daemon_pid(): return {"stopped": True}
        time.sleep(0.1)
    os.kill(pid, 9)  # stuck in a blocking Bluetooth call
    return {"stopped": True, "note": "the daemon did not exit in 8 s and was killed; its service record stays in bluetoothd until bluetoothd restarts"}


# ---------- observations ----------
def status():
    if not daemon_pid(): return {"daemon": False, "link": False, "next": "connect bt:<addr> from list_devices, or pair"}
    s = send("status"); kv = dict(p.split("=", 1) for p in s.split() if "=" in p)
    return {"daemon": True, "link": kv.get("link") == "true", "device": "bt:" + kv["addr"] if kv.get("addr") else None,
            "reports_sent": int(kv.get("sent", 0)), "queued": int(kv.get("queued", 0)), "discoverable": kv.get("disc") == "1"}


def list_devices():
    st = status(); out = []
    for addr, d in known().items():
        up = st.get("link") and st.get("device") == "bt:" + addr
        out.append({"device": "bt:" + addr, "name": d.get("name", ""), "route": "classic Bluetooth HID (keyboard, pointer, media keys)",
                    "input": bool(up), "eyes": False, "last_ok": d.get("last_ok"),
                    "note": "" if up else "call connect; the device must be awake and in range"})
    if not out: out.append({"note": "no device yet. Call pair, then on the device open Bluetooth settings, tap this Mac and accept the code on both screens."})
    return out


# ---------- link ----------
def connect(dev):
    addr = norm(dev); start(addr)
    st = status()
    if st["link"] and st["device"] != "bt:" + addr:
        raise Blocked(f"the daemon is linked to {st['device']}. One device at a time: disconnect it first.")
    for attempt in range(4):   # right after a disconnect the device refuses the first try
        try: res = send(f"connect {addr}", timeout=15); break
        except Blocked as e:
            if attempt == 3: raise
            if "no answer from the daemon" in str(e): stop(); start(addr)   # stuck inside a blocking Bluetooth call: a fresh daemon recovers
            else: time.sleep(1.5)
    name = res.replace("connected to ", "").replace("already connected", "").strip()
    remember(addr, name); return {"ok": True, "device": "bt:" + addr, "name": name or known()[addr]["name"]}


def disconnect(dev):
    norm(dev); send("close", timeout=10); return {"ok": True}


def paired_since(t0, last_s=10):
    """Devices that finished pairing with this Mac after t0, read from bluetoothd's own log:
    'Pairing has completed with result 0 on device AA:BB:CC:DD:EE:FF'. IOBluetooth gives an app no event for this."""
    out = subprocess.run(["/usr/bin/log", "show", "--last", f"{int(last_s)}s", "--style", "compact", "--info", "--debug", "--predicate",
                          'process == "bluetoothd" AND eventMessage CONTAINS "Pairing has completed with result"'],
                         capture_output=True, text=True, timeout=60).stdout
    found = []
    for ln in out.splitlines():
        m = re.match(r"(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\.\d+ .*Pairing has completed with result (\d+) on device ([0-9A-Fa-f:]{17})", ln)
        if m and m.group(2) == "0" and time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")) >= t0 - 1:
            found.append(m.group(3).upper().replace(":", "-"))
    return found


def pair(wait_s=120):
    """First contact with a new device. A person taps this Mac in the device's Bluetooth settings and accepts the code
    on both screens. When bluetoothd logs the pairing as complete, the daemon restarts and opens the HID channels itself."""
    start(discoverable=True); st = status()
    if st["link"]: raise Blocked(f"linked to {st['device']}. One device at a time: disconnect it first, then pair.")
    send("disc 1"); t0 = time.time(); addr = None
    try:
        while time.time() - t0 < wait_s and not addr:
            time.sleep(2.0); got = paired_since(t0, last_s=min(wait_s, time.time() - t0) + 5)
            addr = got[-1] if got else None
    finally:
        try: send("disc 0", timeout=5)
        except Blocked: pass
    if not addr: raise Blocked(f"no device finished pairing in {wait_s} s. Next: run pair again; on the device open Bluetooth settings, tap this Mac's name and accept the code on both screens.")
    time.sleep(2.5); stop()   # a fresh daemon: the channels the device opened during pairing can't be used
    try: return connect("bt:" + addr) | {"paired": True}
    except Blocked as e: raise Blocked(f"{addr} paired but the HID channels did not open ({e}). Next: connect bt:{addr}")


def target(dev):
    addr = norm(dev); st = status()
    if not st.get("daemon") or st.get("device") != "bt:" + addr or not st.get("link"):
        connect(dev)
    return addr


# ---------- verbs ----------
def frac(v, name):
    v = float(v)
    if not 0 <= v <= 1: raise Blocked(f"{name}={v} is outside 0..1. Coordinates are fractions of the device screen.")
    return v


def type_text(dev, text):
    if DENY_TYPE.search(text): raise Blocked("refused: this looks like a passcode, a one-time code or a card number. A person types those.")
    target(dev); line = text.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t")
    return {"ok": True, "result": send("type! " + line, timeout=15 + len(text) * 0.12)}


def key(dev, *combos):
    target(dev); return {"ok": True, "result": send("key " + " ".join(combos), timeout=15 + len(combos))}


def media(dev, name):
    if name not in MEDIA: raise Blocked(f"unknown media key '{name}'. Names: {' '.join(MEDIA)}")
    target(dev); send("media " + name); return {"ok": True}


def tap(dev, x, y, hold_s=0.0, button="l"):
    x, y = frac(x, "x"), frac(y, "y"); target(dev); r = " r" if str(button).lower().startswith("r") else ""
    send(f"abstap {x:.5f} {y:.5f} {float(hold_s):.2f}{r}", timeout=15 + float(hold_s)); return {"ok": True, "x": x, "y": y}


def move(dev, x, y):
    x, y = frac(x, "x"), frac(y, "y"); target(dev); send(f"abs {x:.5f} {y:.5f}"); return {"ok": True, "x": x, "y": y}


def click(dev, button="l"):
    target(dev); send("click " + ("r" if str(button).lower().startswith("r") else "l")); return {"ok": True}


def drag(dev, x1, y1, x2, y2):
    c = [frac(v, n) for v, n in ((x1, "x1"), (y1, "y1"), (x2, "x2"), (y2, "y2"))]; target(dev)
    send("absdrag " + " ".join(f"{v:.5f}" for v in c), timeout=20); return {"ok": True}


_touch_t = 0.0


def touch(dev, events, max_s=1.5):
    """Replay a finger path on the helper's fast socket, no done-line wait. events: [{p: down|move|up, x, y, t}],
    t in ms from the first event. A move keeps the button held (the finger stays down). Gaps are kept as sent,
    each at most 60 ms, the whole path at most max_s. Returns how many landed; the helper logs each as 'fast ...'."""
    import socket
    if not isinstance(events, list) or not events: raise Blocked("touch needs events: a list of {p, x, y, t}")
    if len(events) > 200: raise Blocked("touch takes at most 200 events per call; send a batch per round trip")
    global _touch_t
    if events[0].get("p") == "down" or time.time() - _touch_t > 5.0: target(dev)        # the link check costs ~80 ms: once per finger, not per batch
    _touch_t = time.time(); sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM); path = os.path.join(RUN, "hid5.sock")
    t_prev, t0, n = None, time.time(), 0
    for e in events:
        p = e.get("p"); x, y = frac(e.get("x", -1), "x"), frac(e.get("y", -1), "y"); t = float(e.get("t", 0) or 0)
        if p not in ("down", "move", "up"): raise Blocked("touch event p must be down, move or up (got %r)" % (p,))
        if t_prev is not None:
            gap = min(0.06, max(0.0, (t - t_prev) / 1000.0))
            if gap: time.sleep(gap)
        t_prev = t
        if time.time() - t0 > max_s: break
        sock.sendto(("%s %.5f %.5f" % ("down" if p == "move" else p, x, y)).encode(), path); n += 1
    sock.close(); return {"ok": True, "sent": n, "of": len(events)}


def scroll(dev, dy, dx=0):
    target(dev)
    if int(dy): send(f"scroll {int(dy)}", timeout=15 + abs(int(dy)) * 0.05)
    if int(dx): send(f"hscroll {int(dx)}", timeout=15 + abs(int(dx)) * 0.05)
    return {"ok": True}


def nudge(dev, dx, dy):
    """Relative pointer move in HID counts, for hosts that ignore absolute coordinates."""
    target(dev); n = max(abs(int(dx)), abs(int(dy))); send(f"move {int(dx)} {int(dy)}", timeout=15 + n * 0.005); return {"ok": True}


if __name__ == "__main__":
    a = sys.argv[1:]; c = a[0] if a else "status"
    try:
        if c == "list_devices": r = list_devices()
        elif c == "status": r = status()
        elif c == "pair": r = pair(int(a[1]) if len(a) > 1 else 120)
        elif c == "connect": r = connect(a[1])
        elif c == "disconnect": r = disconnect(a[1])
        elif c == "stop": r = stop()
        elif c == "type": r = type_text(a[1], a[2])
        elif c == "key": r = key(a[1], *a[2:])
        elif c == "media": r = media(a[1], a[2])
        elif c == "tap": r = tap(a[1], a[2], a[3], a[4] if len(a) > 4 else 0, a[5] if len(a) > 5 else "l")
        elif c == "move": r = move(a[1], a[2], a[3])
        elif c == "click": r = click(a[1], a[2] if len(a) > 2 else "l")
        elif c == "drag": r = drag(a[1], *a[2:6])
        elif c == "scroll": r = scroll(a[1], a[2], a[3] if len(a) > 3 else 0)
        elif c == "nudge": r = nudge(a[1], a[2], a[3])
        else: r = {"usage": __doc__}
    except Blocked as e: r = {"blocked": str(e)}
    except IndexError: r = {"usage": __doc__}
    print(json.dumps(r, indent=1))
