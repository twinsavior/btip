// hid5: the Mac as a classic Bluetooth keyboard + mouse + media keys for a paired device.
// One composite HID descriptor with report IDs. Every input report is 10 bytes on the wire
// (A1, id, 8 bytes), and the channel socket's send buffer holds exactly one report, so the
// iPad gets one report per L2CAP packet.
//
// Run:  ADDR=94-21-57-AD-AA-F0 ./hid5            (DISC=1 to be discoverable for first pairing)
// Talk: append lines to $CMD (default ./hid5.cmd). Optional tag: "#t1 key cmd+space".
//       Each command ends with a line "done #tag <result>" on stdout.
// Commands: connect [addr] | type TEXT | type! TEXT (allows PIN-shaped text) | key COMBO [COMBO...]
//   | media home|search|volup|voldown|mute|play|next|prev|brightup|brightdown
//   | move DX DY | corner tl|tr|bl|br | click [l|r] | dblclick | down | up | scroll N | hscroll N
//   | drag DX DY | abs X Y (0..1) | abstap X Y [HOLD_S] [r] | absdrag X1 Y1 X2 Y2 | sleep S | step N MS
//   | status | disc 0|1 | flush (drop everything queued, release buttons) | close | quit
// Text escapes in type: \n newline, \t tab, \\ backslash.
import Foundation
import IOBluetooth
setvbuf(stdout, nil, _IONBF, 0)
let env = ProcessInfo.processInfo.environment
func ts() -> String { let f = DateFormatter(); f.timeZone = TimeZone(identifier: "America/New_York"); f.dateFormat = "HH:mm:ss.SSS"; return f.string(from: Date()) }
func say(_ s: String) { print(ts(), s) }

// MARK: descriptor (USB HID Usage Tables)
let kbdDesc: [UInt8] = [0x05,0x01,0x09,0x06,0xA1,0x01,0x85,0x01,
  0x05,0x07,0x19,0xE0,0x29,0xE7,0x15,0x00,0x25,0x01,0x75,0x01,0x95,0x08,0x81,0x02,
  0x95,0x01,0x75,0x08,0x81,0x01,
  0x95,0x05,0x75,0x01,0x05,0x08,0x19,0x01,0x29,0x05,0x91,0x02,
  0x95,0x01,0x75,0x03,0x91,0x01,
  0x95,0x06,0x75,0x08,0x15,0x00,0x25,0x65,0x05,0x07,0x19,0x00,0x29,0x65,0x81,0x00,
  0xC0]
let mouseDesc: [UInt8] = [0x05,0x01,0x09,0x02,0xA1,0x01,0x85,0x02,0x09,0x01,0xA1,0x00,
  0x05,0x09,0x19,0x01,0x29,0x03,0x15,0x00,0x25,0x01,0x95,0x03,0x75,0x01,0x81,0x02,
  0x95,0x01,0x75,0x05,0x81,0x03,
  0x05,0x01,0x09,0x30,0x09,0x31,0x16,0x01,0x80,0x26,0xFF,0x7F,0x75,0x10,0x95,0x02,0x81,0x06,
  0x09,0x38,0x15,0x81,0x25,0x7F,0x75,0x08,0x95,0x01,0x81,0x06,
  0x05,0x0C,0x0A,0x38,0x02,0x15,0x81,0x25,0x7F,0x75,0x08,0x95,0x01,0x81,0x06,
  0x75,0x08,0x95,0x01,0x81,0x03,
  0xC0,0xC0]
let consumerDesc: [UInt8] = [0x05,0x0C,0x09,0x01,0xA1,0x01,0x85,0x03,
  0x15,0x00,0x26,0xFF,0x03,0x19,0x00,0x2A,0xFF,0x03,0x75,0x10,0x95,0x01,0x81,0x00,
  0x75,0x08,0x95,0x06,0x81,0x03,
  0xC0]
let absDesc: [UInt8] = [0x05,0x01,0x09,0x02,0xA1,0x01,0x85,0x04,0x09,0x01,0xA1,0x00,
  0x05,0x09,0x19,0x01,0x29,0x03,0x15,0x00,0x25,0x01,0x95,0x03,0x75,0x01,0x81,0x02,
  0x95,0x01,0x75,0x05,0x81,0x03,
  0x05,0x01,0x09,0x30,0x09,0x31,0x15,0x00,0x26,0xFF,0x7F,0x75,0x10,0x95,0x02,0x81,0x02,
  0x75,0x08,0x95,0x03,0x81,0x03,
  0xC0,0xC0]
let useAbs = env["ABS"] != "0"
let reportMap = kbdDesc + mouseDesc + consumerDesc + (useAbs ? absDesc : [])

// MARK: SDP record (128-bit HID class: the 16-bit form returns a stale leaked record)
func u16(_ v: Int) -> [String: Any] { ["DataElementType": 1, "DataElementSize": 2, "DataElementValue": v] }
func u8(_ v: Int) -> [String: Any] { ["DataElementType": 1, "DataElementSize": 1, "DataElementValue": v] }
func bool(_ v: Bool) -> [String: Any] { ["DataElementType": 5, "DataElementSize": 1, "DataElementValue": v ? 1 : 0] }
let hid128 = IOBluetoothSDPUUID(bytes: [0x00,0x00,0x11,0x24,0x00,0x00,0x10,0x00,0x80,0x00,0x00,0x80,0x5F,0x9B,0x34,0xFB] as [UInt8], length: 16)
let l2capU = IOBluetoothSDPUUID(uuid16: 0x0100)!, hidpU = IOBluetoothSDPUUID(uuid16: 0x0011)!
let record: [String: Any] = [
  "0001 - ServiceClassIDList": [hid128],
  "0004 - ProtocolDescriptorList": [[l2capU, u16(0x0011)], [hidpU]],
  "0005 - BrowseGroupList": [IOBluetoothSDPUUID(uuid16: 0x1002)!],
  "0006 - LanguageBaseAttributeIDList": [u16(0x656e), u16(0x006a), u16(0x0100)],
  "0009 - BluetoothProfileDescriptorList": [[hid128, u16(0x0101)]],
  "000D - AdditionalProtocolDescriptorLists": [[[l2capU, u16(0x0013)], [hidpU]]],
  "0100 - ServiceName*": "Claude Keyboard", "0101 - ServiceDescription*": "Keyboard and mouse", "0102 - ProviderName*": "Claude",
  "0200 - HIDDeviceReleaseNumber": u16(0x0100), "0201 - HIDParserVersion": u16(0x0111),
  "0202 - HIDDeviceSubclass": u8(0xC0), "0203 - HIDCountryCode": u8(0x21),
  "0204 - HIDVirtualCable": bool(true), "0205 - HIDReconnectInitiate": bool(true),
  "0206 - HIDDescriptorList": [[u8(0x22), ["DataElementType": 4, "DataElementSize": reportMap.count, "DataElementValue": Data(reportMap)]]],
  "0207 - HIDLANGIDBaseList": [[u16(0x0409), u16(0x0100)]],
  "020B - HIDProfileVersion": u16(0x0100), "020C - HIDSupervisionTimeout": u16(0x0c80),
  "020D - HIDNormallyConnectable": bool(true), "020E - HIDBootDevice": bool(false),
]
let rec = IOBluetoothSDPServiceRecord.publishedServiceRecord(with: record)
var recHandle: BluetoothSDPServiceRecordHandle = 0; if let r = rec { _ = r.getHandle(&recHandle) }
say("SDP publish -> " + (rec == nil ? "REFUSED. Next: check the record dictionary types." : "handle \(String(recHandle, radix: 16)), \(rec!.attributes.count) attrs, report map \(reportMap.count) bytes, abs=\(useAbs)"))

// MARK: key tables
let named: [String: UInt8] = ["enter": 0x28, "return": 0x28, "esc": 0x29, "escape": 0x29, "backspace": 0x2A, "tab": 0x2B,
  "space": 0x2C, "capslock": 0x39, "right": 0x4F, "left": 0x50, "down": 0x51, "up": 0x52, "delete": 0x4C,
  "home": 0x4A, "end": 0x4D, "pageup": 0x4B, "pagedown": 0x4E, "f1": 0x3A, "f2": 0x3B, "f3": 0x3C, "f4": 0x3D,
  "f5": 0x3E, "f6": 0x3F, "f7": 0x40, "f8": 0x41, "f9": 0x42, "f10": 0x43, "f11": 0x44, "f12": 0x45]
let mods: [String: UInt8] = ["ctrl": 0x01, "control": 0x01, "shift": 0x02, "alt": 0x04, "opt": 0x04, "option": 0x04, "cmd": 0x08, "command": 0x08]
let unshifted = Array("1234567890-=[]\\;'`,./")
let shifted = Array("!@#$%^&*()_+{}|:\"~<>?")
let punctUsage: [UInt8] = [30,31,32,33,34,35,36,37,38,39,45,46,47,48,49,51,52,53,54,55,56]
func keycode(_ c: Character) -> (UInt8, UInt8)? {
  if c == " " { return (0, 0x2C) }
  if c == "\n" { return (0, 0x28) }
  if c == "\t" { return (0, 0x2B) }
  guard let a = c.asciiValue else { return nil }
  if a >= 97 && a <= 122 { return (0, a - 97 + 4) }
  if a >= 65 && a <= 90 { return (0x02, a - 65 + 4) }
  if let i = unshifted.firstIndex(of: c) { return (0, punctUsage[i]) }
  if let i = shifted.firstIndex(of: c) { return (0x02, punctUsage[i]) }
  return nil
}
func combo(_ s: String) -> (UInt8, UInt8)? {
  var m: UInt8 = 0, k: UInt8 = 0
  for p in s.lowercased().split(separator: "+").map(String.init) {
    if let mm = mods[p] { m |= mm } else if let n = named[p] { k = n }
    else if p.count == 1, let (mm, kk) = keycode(Character(p)) { m |= mm; k = kk } else { return nil }
  }
  return (m, k)
}
let consumer: [String: UInt16] = ["home": 0x223, "search": 0x221, "volup": 0xE9, "voldown": 0xEA, "mute": 0xE2,
  "play": 0xCD, "next": 0xB5, "prev": 0xB6, "brightup": 0x6F, "brightdown": 0x70]

// MARK: device link
class Link: NSObject, IOBluetoothL2CAPChannelDelegate {
  var ctrl: IOBluetoothL2CAPChannel?, intr: IOBluetoothL2CAPChannel?
  var addr = env["ADDR"] ?? ""
  var leds: UInt8 = 0, lastSetProtocol = "", buttons: UInt8 = 0
  var lastAbs: (Double, Double) = (0, 0)   // the host's stored absolute X/Y; resending it unchanged does not move the pointer
  var absKnown = false                       // false until an absolute move went out on this link (a button report before that clicks at the top-left corner)
  // outgoing queue: (report payload incl. id, minimum gap after the previous report)
  var outq: [([UInt8], Double)] = [], lastSent = Date.distantPast, sent = 0, eagain = 0, fdSet = -1, pumping = false
  @objc func incoming(_ n: IOBluetoothUserNotification, channel: IOBluetoothL2CAPChannel) {
    say("incoming PSM \(channel.psm) (IOBluetooth closes these; the Mac connects out instead)")
  }
  func l2capChannelData(_ c: IOBluetoothL2CAPChannel!, data: UnsafeMutableRawPointer!, length: Int) {
    let b = [UInt8](Data(bytes: data, count: length))
    let hex = b.map { String(format: "%02x", $0) }.joined()
    if c.psm == 0x13 { if b.count >= 3 && b[0] == 0xA2 { leds = b[2] }; say("from device (interrupt): \(hex)"); return }
    say("from device (control): \(hex)")
    guard let t = b.first else { return }
    var reply: [UInt8]
    switch t >> 4 {
    case 0x5, 0x7, 0x9: reply = [0x00]; if t >> 4 == 0x7 { lastSetProtocol = (t & 1) == 1 ? "report" : "boot" }
    case 0x6: reply = [0xA0, 0x01]
    case 0x8: reply = [0xA0, 0x00]
    case 0x4: reply = [0xA1] + [b.count > 1 ? b[1] : 1] + [UInt8](repeating: 0, count: 8)
    case 0x1: say("HID_CONTROL \(t & 0x0f) from device"); return
    default: reply = [0x03]
    }
    let e = c.writeSync(&reply, length: UInt16(reply.count))
    if e != 0 { say("control reply failed \(e)") }
  }
  func l2capChannelOpenComplete(_ c: IOBluetoothL2CAPChannel!, status: IOReturn) {}
  func l2capChannelClosed(_ c: IOBluetoothL2CAPChannel!) {
    say("channel PSM \(c.psm) closed by the device or the stack. Next command reconnects.")
    if c === ctrl { ctrl = nil }; if c === intr { intr = nil }; fdSet = -1; absKnown = false; buttons = 0
  }
  var up: Bool { ctrl != nil && intr != nil }
  func connect(_ a: String? = nil) -> String {
    if let a = a, !a.isEmpty { addr = a }
    guard !addr.isEmpty, let d = IOBluetoothDevice(addressString: addr) else { return "err no address. Next: connect AA-BB-CC-DD-EE-FF or set ADDR" }
    if up { return "ok already connected" }
    ctrl?.close(); intr?.close(); ctrl = nil; intr = nil
    // A link this process did not open (the device's own, left from pairing or from an earlier daemon) can't carry
    // our channels: IOBluetooth closes them at once and the next openConnection() loops. Drop it first.
    if d.isConnected() {
      say("dropping a leftover link to \(addr) before connecting")
      d.closeConnection()
      let until = Date().addingTimeInterval(4)
      while d.isConnected() && Date() < until { RunLoop.current.run(until: Date().addingTimeInterval(0.1)) }
      RunLoop.current.run(until: Date().addingTimeInterval(1.0))
    }
    let r0 = d.openConnection()
    if r0 != 0 { return "err baseband \(r0). Next: is the device on, awake and within range?" }
    for psm: BluetoothL2CAPPSM in [0x11, 0x13] {
      var ch: IOBluetoothL2CAPChannel? = nil
      let r = d.openL2CAPChannelSync(&ch, withPSM: psm, delegate: self)
      guard r == 0, let c = ch else {
        ctrl?.close(); ctrl = nil
        return "err PSM \(psm) refused (\(r)). Next: retry once; if it repeats, forget the Mac on the device and pair again (DISC=1)"
      }
      if psm == 0x11 { ctrl = c } else { intr = c }
    }
    absKnown = false; buttons = 0
    return "ok connected to \(d.name ?? addr)"
  }
  func socketFD() -> Int32 {
    guard let cb = intr?.value(forKey: "cbChannel") as? NSObject else { return -1 }
    return Int32((cb.value(forKey: "socketFD") as? Int) ?? -1)
  }
  func enqueue(_ payload: [UInt8], gap: Double) { outq.append((payload, gap)); if !pumping { pumping = true; pump() } }
  func pump() {
    guard !outq.isEmpty else { pumping = false; return }
    guard up else { say("dropped \(outq.count) queued reports: no link"); outq.removeAll(); pumping = false; return }
    let fd = socketFD()
    if fd >= 0 && fdSet != Int(fd) {
      var want: Int32 = 10, low: Int32 = 1
      setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &want, 4); setsockopt(fd, SOL_SOCKET, SO_SNDLOWAT, &low, 4)
      _ = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK); fdSet = Int(fd)
    }
    let (payload, gap) = outq[0]
    let wait = gap - Date().timeIntervalSince(lastSent)
    if wait > 0.0005 { DispatchQueue.main.asyncAfter(deadline: .now() + wait) { self.pump() }; return }
    let frame: [UInt8] = [0xA1] + payload
    let n = frame.withUnsafeBytes { Darwin.write(fd, $0.baseAddress, frame.count) }
    if n == frame.count { outq.removeFirst(); sent += 1; lastSent = Date() }
    else if n < 0 && errno == EAGAIN { eagain += 1 }
    else { say("report write \(n) errno \(errno): dropping it, not replaying"); outq.removeFirst() }
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.003) { self.pump() }
  }
  // report builders, all 9 payload bytes (id + 8)
  func kbd(_ m: UInt8, _ k: UInt8) -> [UInt8] { [0x01, m, 0, k, 0, 0, 0, 0, 0] }
  func mouse(_ dx: Int, _ dy: Int, wheel: Int = 0, pan: Int = 0) -> [UInt8] {
    let x = UInt16(bitPattern: Int16(max(-32767, min(32767, dx)))), y = UInt16(bitPattern: Int16(max(-32767, min(32767, dy))))
    return [0x02, buttons, UInt8(x & 0xff), UInt8(x >> 8), UInt8(y & 0xff), UInt8(y >> 8), UInt8(bitPattern: Int8(max(-127, min(127, wheel)))), UInt8(bitPattern: Int8(max(-127, min(127, pan)))), 0]
  }
  // A button change. iPadOS ignores buttons in the relative report when an absolute pointer is present, so the
  // button goes in the absolute report with X/Y unchanged: the click lands where the pointer is now.
  func btn() -> [UInt8] { useAbs ? absr(lastAbs.0, lastAbs.1) : mouse(0, 0) }
  func cons(_ u: UInt16) -> [UInt8] { [0x03, UInt8(u & 0xff), UInt8(u >> 8), 0, 0, 0, 0, 0, 0] }
  func absr(_ x: Double, _ y: Double) -> [UInt8] {
    let xi = UInt16(max(0, min(32767, x * 32767))), yi = UInt16(max(0, min(32767, y * 32767)))
    return [0x04, buttons, UInt8(xi & 0xff), UInt8(xi >> 8), UInt8(yi & 0xff), UInt8(yi >> 8), 0, 0, 0]
  }
}
let link = Link()
// A host ignores an absolute report whose X and Y equal the previous absolute report, even if relative moves
// went elsewhere since. So every absolute move sends a neighbour value first (1/32767 of the screen away).
func absGo(_ x: Double, _ y: Double, gap: Double) {
  let d = 1.0 / 32767
  link.lastAbs = (x, y); link.absKnown = true
  link.enqueue(link.absr(x < 0.5 ? x + d : x - d, y), gap: gap); link.enqueue(link.absr(x, y), gap: 0.008)
}
var notes: [IOBluetoothUserNotification] = []
for psm: BluetoothL2CAPPSM in [0x11, 0x13] {
  if let n = IOBluetoothL2CAPChannel.register(forChannelOpenNotifications: link, selector: #selector(Link.incoming(_:channel:)), withPSM: psm, direction: kIOBluetoothUserNotificationChannelDirectionIncoming) { notes.append(n) }
}
let fw = dlopen("/System/Library/Frameworks/IOBluetooth.framework/IOBluetooth", RTLD_NOW)
let setDisc = unsafeBitCast(dlsym(fw, "IOBluetoothPreferenceSetDiscoverableState")!, to: (@convention(c) (Int32) -> Void).self)
var discOn = env["DISC"] == "1"
if discOn { setDisc(1); say("discoverable on (first pairing: tap this Mac in the device's Bluetooth settings)") }
var stepCounts = Int(env["STEP"] ?? "6") ?? 6, stepGap = (Double(env["STEPMS"] ?? "8") ?? 8) / 1000

// MARK: commands
let pinShape = try! NSRegularExpression(pattern: "^\\s*\\d{4,8}\\s*$")
var hold = 0.03, gap = 0.03
func run(_ line: String) -> (String, Double) {
  let parts = line.split(separator: " ", maxSplits: 1).map(String.init)
  let cmd = parts.first ?? ""
  let needsLink: Set<String> = ["type", "type!", "key", "media", "move", "corner", "click", "dblclick", "down", "up", "scroll", "hscroll", "drag", "abs", "abstap", "absdrag", "wheel"]
  if needsLink.contains(cmd) && !link.up {
    let r = link.connect()
    say("auto-connect: \(r)")
    if !link.up { return ("err not connected (\(r))", 0) }
    link.lastSent = Date().addingTimeInterval(0.6)   // let the device finish SET_PROTOCOL first
  }
  return runAfterConnect(line)
}
func unescape(_ s: String) -> String {
  var out = "", esc = false
  for ch in s {
    if esc { out.append(ch == "n" ? "\n" : ch == "t" ? "\t" : ch); esc = false }
    else if ch == "\\" { esc = true } else { out.append(ch) }
  }
  return out
}
func runAfterConnect(_ line: String) -> (String, Double) {
  let parts = line.split(separator: " ", maxSplits: 1).map(String.init)
  let cmd = parts.first ?? "", arg = parts.count > 1 ? parts[1] : ""
  let nums = arg.split(separator: " ").compactMap { Double($0) }
  if useAbs && !link.absKnown && ["click", "dblclick", "down", "up", "drag"].contains(cmd) {
    return ("err no pointer position on this link yet, so a click would land in the top-left corner. Next: abs X Y (or abstap X Y) first.", 0)
  }
  switch cmd {
  case "connect": return (link.connect(arg), 0.5)
  case "type", "type!":
    let text = unescape(arg)
    if cmd == "type" && pinShape.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) != nil {
      return ("err refused: 4-8 digits looks like a passcode. A person types passcodes. (Use type! only if the user asked.)", 0)
    }
    var bad = 0
    for ch in text {
      guard let (m, k) = keycode(ch) else { bad += 1; continue }
      link.enqueue(link.kbd(m, k), gap: gap); link.enqueue(link.kbd(0, 0), gap: hold)
    }
    return (bad == 0 ? "ok typed \(text.count) chars" : "ok typed \(text.count - bad), skipped \(bad) non-ASCII chars", 0)
  case "key":
    for c in arg.split(separator: " ").map(String.init) {
      guard let (m, k) = combo(c) else { return ("err unknown key \(c). Names: cmd shift alt ctrl + a-z 0-9 punctuation \(named.keys.sorted().joined(separator: " "))", 0) }
      link.enqueue(link.kbd(m, k), gap: gap); link.enqueue(link.kbd(0, 0), gap: 0.06)
    }
    return ("ok", 0)
  case "media":
    guard let u = consumer[arg] else { return ("err unknown media key. Names: \(consumer.keys.sorted().joined(separator: " "))", 0) }
    link.enqueue(link.cons(u), gap: gap); link.enqueue(link.cons(0), gap: 0.08)
    return ("ok", 0)
  case "move", "drag":
    guard nums.count == 2 else { return ("err usage: \(cmd) DX DY", 0) }
    if cmd == "drag" { link.buttons = 1; link.enqueue(link.btn(), gap: gap); if useAbs { link.buttons = 0 } }
    var rx = Int(nums[0]), ry = Int(nums[1])
    while rx != 0 || ry != 0 {
      let sx = max(-stepCounts, min(stepCounts, rx)), sy = max(-stepCounts, min(stepCounts, ry))
      link.enqueue(link.mouse(sx, sy), gap: stepGap); rx -= sx; ry -= sy
    }
    if cmd == "drag" { link.buttons = 0; link.enqueue(link.btn(), gap: 0.05) }
    return ("ok", 0)
  case "corner":
    let sx = arg.contains("l") ? -1 : 1, sy = arg.contains("t") ? -1 : 1
    for _ in 0..<60 { link.enqueue(link.mouse(sx * 120, sy * 120), gap: 0.004) }
    return ("ok pointer pushed to \(arg.isEmpty ? "br" : arg) corner", 0)
  case "click", "dblclick":
    let b: UInt8 = arg.hasPrefix("r") ? 2 : 1
    for _ in 0..<(cmd == "dblclick" ? 2 : 1) {
      link.buttons = b; link.enqueue(link.btn(), gap: gap)
      link.buttons = 0; link.enqueue(link.btn(), gap: 0.06)
    }
    return ("ok", 0)
  case "down": link.buttons = 1; link.enqueue(link.btn(), gap: gap); if useAbs { link.buttons = 0 }; return ("ok", 0)
  case "up": link.buttons = 0; link.enqueue(link.btn(), gap: gap); return ("ok", 0)
  case "wheel":   // wheel V COUNT GAP_MS: COUNT reports of wheel value V (measurement and tuning)
    guard nums.count == 3 else { return ("err usage: wheel V COUNT GAP_MS", 0) }
    for _ in 0..<Int(nums[1]) { link.enqueue(link.mouse(0, 0, wheel: Int(nums[0])), gap: nums[2] / 1000) }
    return ("ok", 0)
  case "scroll", "hscroll":
    var n = Int(nums.first ?? 0)
    // One notch per report, 30 ms apart: hosts accelerate on report rate, and a big value in one report moves almost nothing.
    while n != 0 { let s = n > 0 ? 1 : -1; link.enqueue(cmd == "scroll" ? link.mouse(0, 0, wheel: s) : link.mouse(0, 0, pan: s), gap: 0.03); n -= s }
    return ("ok", 0)
  case "abs", "abstap":
    guard useAbs, nums.count >= 2 else { return ("err usage: \(cmd) X Y with 0..1 (needs ABS on)", 0) }
    absGo(nums[0], nums[1], gap: gap)
    if cmd == "abstap" {
      let holdS = nums.count > 2 ? max(0.06, nums[2]) : 0.06
      link.buttons = arg.hasSuffix(" r") ? 2 : 1; link.enqueue(link.absr(nums[0], nums[1]), gap: 0.05)
      link.buttons = 0; link.enqueue(link.absr(nums[0], nums[1]), gap: holdS)
    }
    return ("ok", 0)
  case "absdrag":
    guard useAbs, nums.count == 4 else { return ("err usage: absdrag X1 Y1 X2 Y2 with 0..1 (needs ABS on)", 0) }
    absGo(nums[0], nums[1], gap: gap)
    link.buttons = 1; link.enqueue(link.absr(nums[0], nums[1]), gap: 0.05)
    for i in 1...24 { let f = Double(i) / 24; link.enqueue(link.absr(nums[0] + (nums[2] - nums[0]) * f, nums[1] + (nums[3] - nums[1]) * f), gap: 0.012) }
    link.buttons = 0; link.enqueue(link.absr(nums[2], nums[3]), gap: 0.08)
    return ("ok", 0)
  case "step":
    if nums.count == 2 { stepCounts = Int(nums[0]); stepGap = nums[1] / 1000 }
    return ("ok step \(stepCounts) counts every \(Int(stepGap * 1000)) ms", 0)
  case "speed": if nums.count == 2 { hold = nums[0]; gap = nums[1] }; return ("ok hold \(hold) gap \(gap)", 0)
  case "sleep": return ("ok", nums.first ?? 0.5)
  case "status": return ("ok link=\(link.up) addr=\(link.addr) protocol=\(link.lastSetProtocol) leds=\(link.leds) sent=\(link.sent) eagain=\(link.eagain) queued=\(link.outq.count) disc=\(discOn ? 1 : 0)", 0)
  case "disc": discOn = arg == "1"; setDisc(discOn ? 1 : 0); return ("ok discoverable \(discOn ? 1 : 0)", 0)
  case "close": link.ctrl?.close(); link.intr?.close(); return ("ok", 0.3)
  case "quit": shutdown(); return ("ok", 0)
  default: return ("err unknown command \(cmd)", 0)
  }
}
func shutdown() {
  link.ctrl?.close(); link.intr?.close(); rec?.remove(); setDisc(0)
  say("shutdown: channels closed, SDP record removed, discoverable off"); exit(0)
}
var sigSources: [DispatchSourceSignal] = []
for s in [SIGTERM, SIGINT] {
  signal(s, SIG_IGN)
  let src = DispatchSource.makeSignalSource(signal: s, queue: .main); src.setEventHandler { shutdown() }; src.resume()
  sigSources.append(src)
}

let cmdPath = env["CMD"] ?? "hid5.cmd"
// Fast path for real-time use (games): one datagram per action on a Unix socket next to the command file,
// handled the moment it arrives, no file poll, no command queue, no "done" line.
//   press X Y [MODE] [UP_MS] : MODE 1 = move+button in one report, 2 = move report then button 8 ms later (default 1)
//   down X Y | up X Y | move X Y
// Each datagram logs "fast <cmd> <recv wall time>" so callers can measure the daemon's share.
var fastSrc: DispatchSourceRead? = nil
func fastPath(_ cmdFile: String) {
  let path = (cmdFile as NSString).deletingLastPathComponent.isEmpty ? "hid5.sock" : (cmdFile as NSString).deletingLastPathComponent + "/hid5.sock"
  unlink(path)
  let fd = socket(AF_UNIX, SOCK_DGRAM, 0)
  var addr = sockaddr_un(); addr.sun_family = sa_family_t(AF_UNIX)
  _ = withUnsafeMutableBytes(of: &addr.sun_path) { buf in path.utf8CString.withUnsafeBytes { src in memcpy(buf.baseAddress, src.baseAddress, min(buf.count - 1, src.count)) } }
  let ok = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) } }
  if ok != 0 { say("fast path: bind \(path) failed errno \(errno)"); return }
  let src = DispatchSource.makeReadSource(fileDescriptor: fd, queue: .main)
  src.setEventHandler {
    var b = [UInt8](repeating: 0, count: 256)
    let n = recv(fd, &b, 255, 0); if n <= 0 { return }
    let t = Date().timeIntervalSince1970
    let parts = String(decoding: b[0..<n], as: UTF8.self).split(separator: " ").map(String.init)
    guard parts.count >= 3, let x = Double(parts[1]), let y = Double(parts[2]), link.up, useAbs else { say("fast refused: \(parts.first ?? "") (needs link, ABS and X Y)"); return }
    let mode = parts.count > 3 ? Int(parts[3]) ?? 1 : 1, upMs = parts.count > 4 ? Double(parts[4]) ?? 30 : 30
    link.lastAbs = (x, y); link.absKnown = true
    switch parts[0] {
    case "press":
      if mode >= 2 { let g = mode == 2 ? 0.008 : Double(mode) / 1000.0  // mode 3+ = gap in ms (3 -> 3 ms)
        link.buttons = 0; link.enqueue(link.absr(x, y), gap: 0); link.buttons = 1; link.enqueue(link.absr(x, y), gap: g) }
      else { link.buttons = 1; link.enqueue(link.absr(x, y), gap: 0) }
      link.buttons = 0; link.enqueue(link.absr(x, y), gap: upMs / 1000)
    case "down": link.buttons = 1; link.enqueue(link.absr(x, y), gap: 0)
    case "up": link.buttons = 0; link.enqueue(link.absr(x, y), gap: 0)
    case "move": link.buttons = 0; link.enqueue(link.absr(x, y), gap: 0)
    default: say("fast refused: unknown \(parts[0])"); return
    }
    say(String(format: "fast %@ %.6f", parts[0], t))
  }
  src.resume(); fastSrc = src
  say("fast path on \(path)")
}
fastPath(cmdPath)
if !FileManager.default.fileExists(atPath: cmdPath) { FileManager.default.createFile(atPath: cmdPath, contents: Data()) }
var lines: [String] = [], busy = false
func next() {
  guard !busy, !lines.isEmpty else { return }
  busy = true
  var line = lines.removeFirst().trimmingCharacters(in: .whitespaces)
  var tag = ""
  if line.hasPrefix("#"), let sp = line.firstIndex(of: " ") { tag = String(line[..<sp]); line = String(line[line.index(after: sp)...]) }
  let (result, delay) = run(line)
  // wait for the report queue to drain, then for the command's own delay
  func finish() {
    if link.pumping { DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) { finish() }; return }
    DispatchQueue.main.asyncAfter(deadline: .now() + delay) { say("done \(tag.isEmpty ? "-" : tag) \(line.prefix(40)) -> \(result)"); busy = false; next() }
  }
  finish()
}
// The command file only grows; the daemon remembers how far it has read, so no line is lost to a race.
// Lines written before this start are stale and are skipped.
var cmdOffset: UInt64 = ((try? FileManager.default.attributesOfItem(atPath: cmdPath)[.size]) as? UInt64) ?? 0, cmdPartial = ""
Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
  guard let fh = FileHandle(forReadingAtPath: cmdPath) else { return }
  defer { try? fh.close() }
  let size = (try? fh.seekToEnd()) ?? 0
  if size < cmdOffset { cmdOffset = 0 }          // the file was replaced
  guard size > cmdOffset else { return }
  try? fh.seek(toOffset: cmdOffset)
  guard let d = try? fh.readToEnd(), let s = String(data: d, encoding: .utf8) else { return }
  cmdOffset += UInt64(d.count)
  var parts = (cmdPartial + s).components(separatedBy: "\n")
  cmdPartial = parts.removeLast()                 // an unfinished line waits for its newline
  for raw in parts where !raw.trimmingCharacters(in: .whitespaces).isEmpty {
    let bare = raw.split(separator: " ").filter { !$0.hasPrefix("#") }.joined(separator: " ")
    if bare == "flush" {
      let dropped = lines.count + link.outq.count
      lines.removeAll(); link.outq.removeAll(); link.buttons = 0
      if link.up { link.enqueue(link.mouse(0, 0), gap: 0); link.enqueue(link.kbd(0, 0), gap: 0.01) }
      say("done \(raw.hasPrefix("#") ? String(raw.split(separator: " ")[0]) : "-") flush -> ok dropped \(dropped) queued items, buttons and keys released")
      continue
    }
    lines.append(raw)
  }
  next()
}
say("ready pid \(getpid())")
if !link.addr.isEmpty && env["AUTOCONNECT"] != "0" { say("connect: \(link.connect())") }
RunLoop.main.run()
